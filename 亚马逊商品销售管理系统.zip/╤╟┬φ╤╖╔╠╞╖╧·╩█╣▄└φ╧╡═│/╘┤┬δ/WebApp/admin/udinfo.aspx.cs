﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp.admin
{
    public partial class udinfo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["adid"] == null) return;
                string nowuid = Session["adid"].ToString();

                Ctl.BLL.userinfo dal = new Ctl.BLL.userinfo();
                Ctl.Model.userinfo model = new Ctl.Model.userinfo();
                model = dal.GetModel(int.Parse(nowuid));
                if (model != null)
                {
                    txtulog.Value = model.ulog;
                    txtuname.Value = model.uname;
                    txtusex.SelectedValue = model.usex;
                    txtuidentid.Value = model.uidentid;
                    txtutel.Value = model.utel;
                    txtuemail.Value = model.uemail;
                    txtuaddress.Value = model.uaddress;

                    txtudept.Value = model.udept;
                    txtupost.Value = model.upost;
                    if (model.urole==9)
                    {
                        txtudept.Disabled = false;
                        txtupost.Disabled = false ;

                    }
                }
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (Session["adid"] == null) return;
            string nowuid = Session["adid"].ToString();

            Ctl.BLL.userinfo dal = new Ctl.BLL.userinfo();
            Ctl.Model.userinfo model = new Ctl.Model.userinfo();

            string ulog = txtulog.Value;
            string uname = txtuname.Value;
            string usex = txtusex.SelectedValue;

            string uidentid = txtuidentid.Value;
            string utel = txtutel.Value;
            string uemail = txtuemail.Value;
            string uaddress = txtuaddress.Value;
            string toUrl = "window.location.href='udinfo.aspx';";
            if (string.IsNullOrEmpty(nowuid))
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('信息获取失败!'); " + toUrl + "</script>");
                return;
            }

            model = dal.GetModel(int.Parse(nowuid));
            if (model != null)
            {
                model.uname = uname;
                model.usex = usex;
                model.uidentid = uidentid;
                model.utel = utel;
                model.uemail = uemail;
                model.uaddress = uaddress;
                if (!dal.Update(model))
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('操作失败!'); " + toUrl + "</script>");
                    return;
                }
                Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('保存成功!'); " + toUrl + "</script>");
            }
        }

    }
}

