﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp.admin.gproc
{
    public partial class details : System.Web.UI.Page
    {
        Ctl.BLL.vwgproc bll = new Ctl.BLL.vwgproc();
        Ctl.Model.vwgproc model = new Ctl.Model.vwgproc();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["id"] == null || Request.QueryString["id"] == "") return;
                hidid.Value = Request.QueryString["id"];

                model = bll.GetModel(int.Parse(Request.QueryString["id"]));

                if (model != null)
                {
                    sppname.InnerText = model.pname;
                    spptype.InnerText = model.ptype;
                    spptname.InnerText = model.ptname;
                    sppmodel.InnerText = model.pmodel;
                    sppno.InnerText = model.pno;
                    sppnum.InnerText = model.pnum.ToString();
                    sppkhid.InnerText = model.kname.ToString();

                }
            }
        }

        /// <summary>
        /// 返回
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnreturn_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
