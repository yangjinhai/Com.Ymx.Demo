﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp.admin.gproc
{
    public partial class opt : System.Web.UI.Page
    {
        Ctl.BLL.gproc bll = new Ctl.BLL.gproc();
        Ctl.Model.gproc model = new Ctl.Model.gproc();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
				//LoadDdl();
                if (Request.QueryString["id"] == null || Request.QueryString["id"] == "") return;
                hidid.Value = Request.QueryString["id"];

                model=bll.GetModel(int.Parse(Request.QueryString["id"]));
                
				if(model != null){
                    sptzg.InnerText = "修改";
					                	txtpname.Value = model.pname;
                	txtptype.Value = model.ptype;
                	txtptname.Value = model.ptname;
                	txtpmodel.Value = model.pmodel;
                	txtpno.Value = model.pno;
                	txtpnum.Value = model.pnum.ToString();
                	txtpkhid.Value = model.pkhid.ToString();
                	txtpdesc.Value = model.pdesc;
                	txtprek.Value = model.prek;
                	txtpaddtime.Value = model.paddtime;
                	txtpadduid.Value = model.padduid.ToString();
                	txtpadduname.Value = model.padduname;
                	txtpby.Value = model.pby;
                	txtpbyv.Value = model.pbyv.ToString();

				}
            }
        }

        /// <summary>
        /// 绑定下拉框
        /// </summary>
        private void LoadDdl()
        {
            //ddli_type.Items.Clear();
            DataSet ds = new DataSet();
			//ds=new Ctl.BLL.tb_user().GetList("");
            //ddli_type.DataTextField = "u_name";
            //ddli_type.DataValueField = "u_id";
            //ddli_type.DataSource = ds;
            //ddli_type.DataBind();

            //ddli_type.Items.Insert(0, new ListItem("--请选择--", ""));
            //ddli_type.SelectedIndex = 0;
        }

        

        /// <summary>
        /// 提交
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnok_Click(object sender, EventArgs e)
        {
            string optid = hidid.Value;

                        string pname = this.txtpname.Value;
            string ptype = this.txtptype.Value;
            string ptname = this.txtptname.Value;
            string pmodel = this.txtpmodel.Value;
            string pno = this.txtpno.Value;
            string pnum = this.txtpnum.Value;
            string pkhid = this.txtpkhid.Value;
            string pdesc = this.txtpdesc.Value;
            string prek = this.txtprek.Value;
            string paddtime = this.txtpaddtime.Value;
            string padduid = this.txtpadduid.Value;
            string padduname = this.txtpadduname.Value;
            string pby = this.txtpby.Value;
            string pbyv = this.txtpbyv.Value;
   
			model = new Ctl.Model.gproc();
            //string sqlwh = " ulog='" + ulog + "' ";
            if (!string.IsNullOrEmpty(optid))
            {
            //    sqlwh += " and uid!=" + optid;
                model = bll.GetModel(int.Parse(optid));
            }
            //DataTable dtEx = bll.GetList(sqlwh).Tables[0];
            //if (dtEx.Rows.Count > 0)
            //{
            //    Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('重复，请更换!');</script>");
            //    return;
            //}
                        model.pname = pname;
            model.ptype = ptype;
            model.ptname = ptname;
            model.pmodel = pmodel;
            model.pno = pno;
            model.pnum = int.Parse(pnum);
            model.pkhid = int.Parse(pkhid);
            model.pdesc = pdesc;
            model.prek = prek;
            model.paddtime = paddtime;
            if(Session["adid"]!=null)
            model.padduid = int.Parse(Session["adid"].ToString());
            if(Session["adname"]!=null)
            model.padduname = Session["adname"].ToString();
            model.pby = pby;
            model.pbyv = int.Parse(pbyv);


            bool b = false;
            if (optid != "")
            {
                b = bll.Update(model);
            }
            else
            {
                //model.uaddtime = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm");
                b = bll.Add(model) > 0 ? true : false;
            }
            if (b)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('操作成功');window.location.href='list.aspx';</script>");
            }
            else
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('操作失败，稍候重试!');</script>");
                return;
            }
        }

        /// <summary>
        /// 返回
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnreturn_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
