﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp.admin.xishouck
{
    public partial class check : System.Web.UI.Page
    {
        Ctl.BLL.xishou bll = new Ctl.BLL.xishou();
        Ctl.Model.xishou model = new Ctl.Model.xishou();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["id"] == null || Request.QueryString["id"] == "") return;
                hidid.Value = Request.QueryString["id"];

                Ctl.Model.vwxishou model = new Ctl.BLL.vwxishou().GetModel(int.Parse(Request.QueryString["id"]));

                if (model != null)
                {
                    spxno.InnerText = model.xno;
                    spxstime.InnerText = model.xstime;
                    spxspid.InnerText = model.pname.ToString();
                    spxspnum.InnerText = model.xspnum.ToString();
                    spxspprice.InnerText = model.xspprice.ToString();
                    spxspsum.InnerText = model.xspsum.ToString();
                    spxsgykhid.InnerText = model.mkname.ToString();
                    spxsuname.InnerText = model.xsuname;
                    spxsrek.InnerText = model.xsrek;
                    spxsadduname.InnerText = model.xsadduname;
                    spxsaddtime.InnerText = model.xsaddtime;
                    //spxsckzt.InnerText = getzt(model.xsckzt.ToString());


                    //if (model.xsckzt > 1)
                    //{
                    //    spxsckadduname.InnerText = model.xsckadduname;
                    //    spxsckaddtime.InnerText = model.xsckaddtime;
                    //}
                    //else
                    //{
                    //    spxsckadduname.InnerText = "--";
                    //    spxsckaddtime.InnerText = "--";
                    //}

                }
            }
        }



        /// <summary>
        /// 提交
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnok_Click(object sender, EventArgs e)
        {
            string optid = hidid.Value;

            string xsckzt = this.txtxsckzt.SelectedValue;

            model = new Ctl.Model.xishou();
            //string sqlwh = " ulog='" + ulog + "' ";
            if (!string.IsNullOrEmpty(optid))
            {
                //    sqlwh += " and uid!=" + optid;
                model = bll.GetModel(int.Parse(optid));
            }
            //DataTable dtEx = bll.GetList(sqlwh).Tables[0];
            //if (dtEx.Rows.Count > 0)
            //{
            //    Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('重复，请更换!');</script>");
            //    return;
            //}





            bool b = false;
            model.xsckzt = int.Parse(xsckzt);
            if (Session["adid"] != null)
                model.xsckadduid = int.Parse(Session["adid"].ToString());
            if (Session["adname"] != null)
                model.xsckadduname = Session["adname"].ToString();
            model.xsckaddtime = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm");

            Ctl.Model.gproc molp = new Ctl.BLL.gproc().GetModel(int.Parse(model.xspid.ToString()));
            if (model.xsckzt == 3)
            {
                if (model.xspnum > molp.pnum)
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('很遗憾，库存不足!');</script>");
                    return;
                }
            }

            b = bll.Update(model);
            if (b)
            {
                if (model.xsckzt == 3)
                {
                    molp.pnum -= model.xspnum;
                    new Ctl.BLL.gproc().Update(molp);
                }

                Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('操作成功');window.location.href='list.aspx';</script>");
            }
            else
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('操作失败，稍候重试!');</script>");
                return;
            }
        }

        /// <summary>
        /// 返回
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnreturn_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
