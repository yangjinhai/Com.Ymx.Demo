﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp.admin.xishouck
{
    public partial class details : System.Web.UI.Page
    {
        Ctl.BLL.xishou bll = new Ctl.BLL.xishou();
        Ctl.Model.xishou model = new Ctl.Model.xishou();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["id"] == null || Request.QueryString["id"] == "") return;
                hidid.Value = Request.QueryString["id"];

                Ctl.Model.vwxishou model = new Ctl.BLL.vwxishou().GetModel(int.Parse(Request.QueryString["id"]));

                if (model != null)
                {
                    spxno.InnerText = model.xno;
                    spxstime.InnerText = model.xstime;
                    spxspid.InnerText = model.ptname.ToString();
                    spxspnum.InnerText = model.xspnum.ToString();
                    spxspprice.InnerText = model.xspprice.ToString();
                    spxspsum.InnerText = model.xspsum.ToString();
                    spxsgykhid.InnerText = model.mkname.ToString();
                    spxsuname.InnerText = model.xsuname;
                    spxsrek.InnerText = model.xsrek;
                    spxsadduname.InnerText = model.xsadduname;
                    spxsaddtime.InnerText = model.xsaddtime;
                    spxsckzt.InnerText = getzt(model.xsckzt.ToString());
                    spxsckadduname.InnerText = model.xsckadduname;
                    spxsckaddtime.InnerText = model.xsckaddtime;

                }
            }
        }
        public string getzt(string _zt)
        {
            string re = "";
            switch (_zt)
            {
                case "1": re = "待审"; break;
                case "2": re = "不予通过"; break;
                case "3": re = "审核通过"; break;
            }
            return re;
        }

        /// <summary>
        /// 返回
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnreturn_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
