﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace WebApp.admin.xishouck
{
    public partial class list : System.Web.UI.Page
    {
        Ctl.BLL.xishou dal = new Ctl.BLL.xishou();
        Ctl.Model.xishou model = new Ctl.Model.xishou();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                InitData();
            }
        }

        /// <summary>
        /// 加载数据
        /// </summary>
        private void InitData()
        {
            DataSet ds = null;
            string sql1 = "xsckzt=1 and ";

            if (txtkey.Value != "")
            {
                sql1 += " (";
                sql1 += " xno like '%" + txtkey.Value + "%'  or ";
                sql1 += " xstime like '%" + txtkey.Value + "%'  or ";
                sql1 += " xsuname like '%" + txtkey.Value + "%'  or ";
                sql1 += " xsrek like '%" + txtkey.Value + "%'  or ";
                sql1 += " xsadduname like '%" + txtkey.Value + "%'  or ";
                sql1 += " xsaddtime like '%" + txtkey.Value + "%'  or ";
                sql1 += " xsckadduname like '%" + txtkey.Value + "%'  or ";
                sql1 += " xsckaddtime like '%" + txtkey.Value + "%'  or ";
                sql1 += " xsckrek like '%" + txtkey.Value + "%' ";

                sql1 += ") and ";
            }

            if (!string.IsNullOrEmpty(sql1)) sql1 = sql1.Substring(0, sql1.Length - 4);

            ds = new Ctl.BLL.vwxishou().GetList(0, sql1, "xid desc");
            gv.DataSource = ds;
            gv.DataBind();
        }

        /// <summary>
        /// 分页提取
        /// </summary>
        /// <param name="pageno"></param>
        private void ToPage(int pageno)
        {
            gv.PageIndex = pageno;
            InitData();
        }

        /// <summary>
        /// 分页跳转
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            ToPage(e.NewPageIndex);
        }

        /// <summary>
        /// 搜索
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            InitData();
        }

        /// <summary>
        /// 列表操作
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gv_RowCommand(object sender, GridViewCommandEventArgs e)
        {

            if (e.CommandName == "del")
            {
                string opid = e.CommandArgument.ToString();
                
            }

        }
        public string getzt(string _zt)
        {
            string re = "";
            switch (_zt)
            {
                case "1": re = "待审"; break;
                case "2": re = "不予通过"; break;
                case "3": re = "审核通过"; break;
            }
            return re;
        }
    }
}
