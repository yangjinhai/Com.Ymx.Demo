﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace WebApp.admin.xishou
{
    public partial class listed : System.Web.UI.Page
    {
        Ctl.BLL.xishou dal = new Ctl.BLL.xishou();
        Ctl.Model.xishou model = new Ctl.Model.xishou();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                InitData();
            }
        }

        /// <summary>
        /// 加载数据
        /// </summary>
        private void InitData()
        {
            DataSet ds = null;
            if (Session["adid"] == null) return;
            string nowuid = Session["adid"].ToString();
            string sql1 = "xsckzt=3 and xsadduid= " + nowuid + " and ";

            if (txtkey.Value != "")
            {
                sql1 += " (";
                sql1 += " xno like '%" + txtkey.Value + "%'  or ";
                sql1 += " xstime like '%" + txtkey.Value + "%'  or ";
                sql1 += " xsuname like '%" + txtkey.Value + "%'  or ";
                sql1 += " xsrek like '%" + txtkey.Value + "%'  or ";
                sql1 += " xsadduname like '%" + txtkey.Value + "%'  or ";
                sql1 += " xsaddtime like '%" + txtkey.Value + "%'  or ";
                sql1 += " xsckadduname like '%" + txtkey.Value + "%'  or ";
                sql1 += " xsckaddtime like '%" + txtkey.Value + "%'  or ";
                sql1 += " xsckrek like '%" + txtkey.Value + "%' ";

                sql1 += ") and ";
            }

            if (!string.IsNullOrEmpty(sql1)) sql1 = sql1.Substring(0, sql1.Length - 4);

            ds = new Ctl.BLL.vwxishou().GetList(0, sql1, "xid desc");
            gv.DataSource = ds;
            gv.DataBind();
        }

        /// <summary>
        /// 分页提取
        /// </summary>
        /// <param name="pageno"></param>
        private void ToPage(int pageno)
        {
            gv.PageIndex = pageno;
            InitData();
        }

        /// <summary>
        /// 分页跳转
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            ToPage(e.NewPageIndex);
        }

        /// <summary>
        /// 搜索
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            InitData();
        }

        /// <summary>
        /// 列表操作
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gv_RowCommand(object sender, GridViewCommandEventArgs e)
        {

            if (e.CommandName == "del")
            {
                string opid = e.CommandArgument.ToString();
                //DataTable dt = new Ctl.BLL.gproc().GetList("ppaid=" + opid).Tables[0];
                //if (dt.Rows.Count>0)
                //{
                //    Maticsoft.Common.MessageBox.Show(this, "该数据下存在数据，暂不支持删除"); return;
                //}
                if (dal.Delete(int.Parse(opid)))
                {
                    Maticsoft.Common.MessageBox.ShowAndRedirect(this, "删除成功", "list.aspx" + Request.Url.Query);
                }
                else
                {
                    Maticsoft.Common.MessageBox.Show(this, "失败，请稍候重试"); return;
                }
            }

        }
        public string getzt(string _zt)
        {
            string re = "";
            switch (_zt)
            {
                case "1": re = "待审"; break;
                case "2": re = "不予通过"; break;
                case "3": re = "审核通过"; break;
            }
            return re;
        }
    }
}
