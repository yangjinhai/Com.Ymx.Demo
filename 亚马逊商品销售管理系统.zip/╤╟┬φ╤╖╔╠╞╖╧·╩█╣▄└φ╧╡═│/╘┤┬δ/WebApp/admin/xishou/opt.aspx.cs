﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp.admin.xishou
{
    public partial class opt : System.Web.UI.Page
    {
        Ctl.BLL.xishou bll = new Ctl.BLL.xishou();
        Ctl.Model.xishou model = new Ctl.Model.xishou();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadDdl0();
                LoadDdl();
                if (Request.QueryString["id"] == null || Request.QueryString["id"] == "") { };
                hidid.Value = Request.QueryString["id"];
                if (!string.IsNullOrWhiteSpace(hidid.Value))
                {
                    model = bll.GetModel(int.Parse(Request.QueryString["id"]));

                    if (model != null)
                    {
                        sptzg.InnerText = "修改";
                        txtxno.Value = model.xno;
                        txtxstime.Value = model.xstime;
                        txtxspid.SelectedValue = model.xspid.ToString();
                        txtxspnum.Value = model.xspnum.ToString();
                        txtxspprice.Value = model.xspprice.ToString();
                        txtxspsum.Value = model.xspsum.ToString();
                        txtxsgykhid.SelectedValue = model.xsgykhid.ToString();
                        txtxsuname.Value = model.xsuname;
                        txtxsrek.Value = model.xsrek;


                    }
                }
                else
                {
                    txtxno.Value = System.DateTime.Now.ToString("yyMMddHHmmssfff");

                    if (Session["adname"] != null)
                        txtxsuname.Value = Session["adname"].ToString();
                }
            }
        }
        /// <summary>
        /// 绑定下拉框
        /// </summary>
        private void LoadDdl0()
        {
            txtxspid.Items.Clear();
            DataSet ds = new DataSet();
            ds = new Ctl.BLL.gproc().GetList("pnum>0");
            txtxspid.DataTextField = "pname";
            txtxspid.DataValueField = "pid";
            txtxspid.DataSource = ds;
            txtxspid.DataBind();

            txtxspid.Items.Insert(0, new ListItem("--请选择--", ""));
            txtxspid.SelectedIndex = 0;
        }

        /// <summary>
        /// 绑定下拉框
        /// </summary>
        private void LoadDdl()
        {
            txtxsgykhid.Items.Clear();
            DataSet ds = new DataSet();
            ds = new Ctl.BLL.kehu().GetList("ktype=2");
            txtxsgykhid.DataTextField = "kname";
            txtxsgykhid.DataValueField = "kid";
            txtxsgykhid.DataSource = ds;
            txtxsgykhid.DataBind();

            txtxsgykhid.Items.Insert(0, new ListItem("--请选择--", ""));
            txtxsgykhid.SelectedIndex = 0;
        }



        /// <summary>
        /// 提交
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnok_Click(object sender, EventArgs e)
        {
            string optid = hidid.Value;

            string xno = this.txtxno.Value;
            string xstime = this.txtxstime.Value;
            string xspid = this.txtxspid.SelectedValue;
            string xspnum = this.txtxspnum.Value;
            string xspprice = this.txtxspprice.Value;
            string xspsum = this.txtxspsum.Value;
            string xsgykhid = this.txtxsgykhid.SelectedValue;
            string xsuname = this.txtxsuname.Value;
            string xsrek = this.txtxsrek.Value;


            model = new Ctl.Model.xishou();
            //string sqlwh = " ulog='" + ulog + "' ";
            if (!string.IsNullOrEmpty(optid))
            {
                //    sqlwh += " and uid!=" + optid;
                model = bll.GetModel(int.Parse(optid));
            }
            //DataTable dtEx = bll.GetList(sqlwh).Tables[0];
            //if (dtEx.Rows.Count > 0)
            //{
            //    Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('重复，请更换!');</script>");
            //    return;
            //}
            model.xno = xno;
            model.xstime = xstime;
            model.xspid = int.Parse(xspid);
            model.xspnum = int.Parse(xspnum);
            model.xspprice = int.Parse(xspprice);
            model.xspsum = int.Parse(xspsum);
            model.xsgykhid = int.Parse(xsgykhid);
            model.xsuname = xsuname;
            model.xsrek = xsrek;



            bool b = false;
            if (optid != "")
            {
                model.xsckzt = 1;
                model.xsaddtime = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm");

                model.xsckadduid = 0;
                model.xsckadduname = "";
                model.xsckaddtime = "";

                b = bll.Update(model);
            }
            else
            {
                if (Session["adid"] != null)
                    model.xsadduid = int.Parse(Session["adid"].ToString());
                if (Session["adname"] != null)
                    model.xsadduname = Session["adname"].ToString();
                model.xsaddtime = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm");
                model.xsckzt = 1;

                b = bll.Add(model) > 0 ? true : false;
            }
            if (b)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('操作成功');window.location.href='list.aspx';</script>");
            }
            else
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('操作失败，稍候重试!');</script>");
                return;
            }
        }

        /// <summary>
        /// 返回
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnreturn_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
