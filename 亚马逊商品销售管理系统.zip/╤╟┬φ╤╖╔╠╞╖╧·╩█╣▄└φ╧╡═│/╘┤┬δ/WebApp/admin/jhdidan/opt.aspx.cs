﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp.admin.jhdidan
{
    public partial class opt : System.Web.UI.Page
    {
        Ctl.BLL.jhdidan bll = new Ctl.BLL.jhdidan();
        Ctl.Model.jhdidan model = new Ctl.Model.jhdidan();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadDdl();
                if (Request.QueryString["id"] == null || Request.QueryString["id"] == "") { };
                hidid.Value = Request.QueryString["id"];

                if (!string.IsNullOrWhiteSpace(hidid.Value))
                {
                    model = bll.GetModel(int.Parse(Request.QueryString["id"]));

                    if (model != null)
                    {
                        sptzg.InnerText = "修改";
                        txtjno.Value = model.jno;
                        txtjctime.Value = model.jctime;
                        txtjspname.Value = model.jspname;
                        txtjsptype.SelectedValue = model.jsptype;
                        txtjsptname.SelectedValue = model.jsptname;
                        txtjspmodel.Value = model.jspmodel;
                        txtjspno.Value = model.jspno;
                        txtjspnum.Value = model.jspnum.ToString();
                        txtjspprice.Value = model.jspprice.ToString();
                        txtjspsum.Value = model.jspsum.ToString();
                        txtjgykhid.SelectedValue = model.jgykhid.ToString();
                        txtjcguname.Value = model.jcguname;
                        txtjcgrek.Value = model.jcgrek;

                    }
                }
                else
                {
                    txtjno.Value = System.DateTime.Now.ToString("yyMMddHHmmssfff");

                    if (Session["adname"] != null)
                        txtjcguname.Value = Session["adname"].ToString();
                }
               
            }
        }

        /// <summary>
        /// 绑定下拉框
        /// </summary>
        private void LoadDdl()
        {
            txtjgykhid.Items.Clear();
            DataSet ds = new DataSet();
            ds = new Ctl.BLL.kehu().GetList("ktype=1");
            txtjgykhid.DataTextField = "kname";
            txtjgykhid.DataValueField = "kid";
            txtjgykhid.DataSource = ds;
            txtjgykhid.DataBind();

            txtjgykhid.Items.Insert(0, new ListItem("--请选择--", ""));
            txtjgykhid.SelectedIndex = 0;
        }



        /// <summary>
        /// 提交
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnok_Click(object sender, EventArgs e)
        {
            string optid = hidid.Value;

            string jno = this.txtjno.Value;
            string jctime = this.txtjctime.Value;
            string jspname = this.txtjspname.Value;
            string jsptype = this.txtjsptype.SelectedValue;
            string jsptname = this.txtjsptname.SelectedValue;
            string jspmodel = this.txtjspmodel.Value;
            string jspno = this.txtjspno.Value;
            string jspnum = this.txtjspnum.Value;
            string jspprice = this.txtjspprice.Value;
            string jspsum = this.txtjspsum.Value;
            string jgykhid = this.txtjgykhid.SelectedValue;
            string jcguname = this.txtjcguname.Value;
            string jcgrek = this.txtjcgrek.Value;
            

            model = new Ctl.Model.jhdidan();
            //string sqlwh = " ulog='" + ulog + "' ";
            if (!string.IsNullOrEmpty(optid))
            {
                //    sqlwh += " and uid!=" + optid;
                model = bll.GetModel(int.Parse(optid));
            }
            //DataTable dtEx = bll.GetList(sqlwh).Tables[0];
            //if (dtEx.Rows.Count > 0)
            //{
            //    Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('重复，请更换!');</script>");
            //    return;
            //}
            model.jno = jno;
            model.jctime = jctime;
            model.jspname = jspname;
            model.jsptype = jsptype;
            model.jsptname = jsptname;
            model.jspmodel = jspmodel;
            model.jspno = jspno;
            model.jspnum = int.Parse(jspnum);
            model.jspprice = int.Parse(jspprice);
            model.jspsum = int.Parse(jspsum);
            model.jgykhid = int.Parse(jgykhid);
            model.jcguname = jcguname;
            model.jcgrek = jcgrek;
           


            bool b = false;
            if (optid != "")
            {
                model.jckzt = 1;
                model.jcaddtime = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm");

                model.jckadduid = 0;
                model.jckadduname = "";
                model.jckaddtime = "";
                b = bll.Update(model);
            }
            else
            {

                if (Session["adid"] != null)
                    model.jcadduid = int.Parse(Session["adid"].ToString());
                if (Session["adname"] != null)
                    model.jcadduname = Session["adname"].ToString();
                
                model.jckzt = 1;
                model.jcaddtime = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm");
                b = bll.Add(model) > 0 ? true : false;
            }
            if (b)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('操作成功');window.location.href='list.aspx';</script>");
            }
            else
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('操作失败，稍候重试!');</script>");
                return;
            }
        }

        /// <summary>
        /// 返回
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnreturn_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
