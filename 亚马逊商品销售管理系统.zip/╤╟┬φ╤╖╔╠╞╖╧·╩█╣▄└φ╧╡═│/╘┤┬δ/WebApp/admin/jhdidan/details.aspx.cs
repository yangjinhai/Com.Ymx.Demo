﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp.admin.jhdidan
{
    public partial class details : System.Web.UI.Page
    {
        Ctl.BLL.vwjhdidan bll = new Ctl.BLL.vwjhdidan();
        Ctl.Model.vwjhdidan model = new Ctl.Model.vwjhdidan();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["id"] == null || Request.QueryString["id"] == "") return;
                hidid.Value = Request.QueryString["id"];

                model = bll.GetModel(int.Parse(Request.QueryString["id"]));

                if (model != null)
                {
                    spjno.InnerText = model.jno;
                    spjctime.InnerText = model.jctime;
                    spjspname.InnerText = model.jspname;
                    spjsptype.InnerText = model.jsptype;
                    spjsptname.InnerText = model.jsptname;
                    spjspmodel.InnerText = model.jspmodel;
                    spjspno.InnerText = model.jspno;
                    spjspnum.InnerText = model.jspnum.ToString();
                    spjspprice.InnerText = model.jspprice.ToString();
                    spjspsum.InnerText = model.jspsum.ToString();
                    spjgykhid.InnerText = model.kname.ToString();
                    spjcguname.InnerText = model.jcguname;
                    spjcgrek.InnerText = model.jcgrek;
                    spjcadduname.InnerText = model.jcadduname;
                    spjcaddtime.InnerText = model.jcaddtime;
                    spjckzt.InnerText = getzt(model.jckzt.ToString());

                    if (model.jckzt>1)
                    {
                        spjckadduname.InnerText = model.jckadduname;
                        spjckaddtime.InnerText = model.jckaddtime;
                    }
                    else
                    {
                        spjckadduname.InnerText = "--";
                        spjckaddtime.InnerText = "--";
                    }
                    

                }
            }
        }
        public string getzt(string _zt)
        {
            string re = "";
            switch (_zt)
            {
                case "1": re = "待审"; break;
                case "2": re = "不予通过"; break;
                case "3": re = "审核通过"; break;
            }
            return re;
        }

        /// <summary>
        /// 返回
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnreturn_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
