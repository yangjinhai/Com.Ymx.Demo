﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace WebApp.admin.jhdidan
{
    public partial class list : System.Web.UI.Page
    {
        Ctl.BLL.jhdidan dal = new Ctl.BLL.jhdidan();
        Ctl.Model.jhdidan model = new Ctl.Model.jhdidan();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                InitData();
            }
        }

        /// <summary>
        /// 加载数据
        /// </summary>
        private void InitData()
        {
            DataSet ds = null;
            if (Session["adid"] == null) return;
            string nowuid = Session["adid"].ToString();
            string sql1 = "jckzt<3 and jcadduid= " + nowuid + " and ";

            if (txtkey.Value != "")
            {
                sql1 += " (";
                sql1 += " jno like '%" + txtkey.Value + "%'  or ";
                sql1 += " jctime like '%" + txtkey.Value + "%'  or ";
                sql1 += " jspname like '%" + txtkey.Value + "%'  or ";
                sql1 += " jsptype like '%" + txtkey.Value + "%'  or ";
                sql1 += " jsptname like '%" + txtkey.Value + "%'  or ";
                sql1 += " jspmodel like '%" + txtkey.Value + "%'  or ";
                sql1 += " jspno like '%" + txtkey.Value + "%'  or ";
                sql1 += " jcguname like '%" + txtkey.Value + "%'  or ";
                sql1 += " jcgrek like '%" + txtkey.Value + "%'  or ";
                sql1 += " jcadduname like '%" + txtkey.Value + "%'  or ";
                sql1 += " jcaddtime like '%" + txtkey.Value + "%'  or ";
                sql1 += " jckadduname like '%" + txtkey.Value + "%'  or ";
                sql1 += " jckaddtime like '%" + txtkey.Value + "%'  or ";
                sql1 += " jckrek like '%" + txtkey.Value + "%'  ";

                sql1 += ") and ";
            }

            if (!string.IsNullOrEmpty(sql1)) sql1 = sql1.Substring(0, sql1.Length - 4);

            ds = new Ctl.BLL.vwjhdidan().GetList(0, sql1, "jid desc");
            gv.DataSource = ds;
            gv.DataBind();
        }

        /// <summary>
        /// 分页提取
        /// </summary>
        /// <param name="pageno"></param>
        private void ToPage(int pageno)
        {
            gv.PageIndex = pageno;
            InitData();
        }

        /// <summary>
        /// 分页跳转
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            ToPage(e.NewPageIndex);
        }

        /// <summary>
        /// 搜索
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            InitData();
        }

        /// <summary>
        /// 列表操作
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gv_RowCommand(object sender, GridViewCommandEventArgs e)
        {

            if (e.CommandName == "del")
            {
                string opid = e.CommandArgument.ToString();
                
                //DataTable dt = new Ctl.BLL.gproc().GetList("ppaid=" + opid).Tables[0];
                //if (dt.Rows.Count>0)
                //{
                //    Maticsoft.Common.MessageBox.Show(this, "该数据下存在数据，暂不支持删除"); return;
                //}
                if (dal.Delete(int.Parse(opid)))
                {
                    Maticsoft.Common.MessageBox.ShowAndRedirect(this, "删除成功", "list.aspx" + Request.Url.Query);
                }
                else
                {
                    Maticsoft.Common.MessageBox.Show(this, "失败，请稍候重试"); return;
                }
            }

        }
        public string getzt(string _zt)
        {
            string re = "";
            switch (_zt)
            {
                case "1": re = "待审"; break;
                case "2": re = "不予通过"; break;
                case "3": re = "审核通过"; break;
            }
            return re;
        }
    }
}
