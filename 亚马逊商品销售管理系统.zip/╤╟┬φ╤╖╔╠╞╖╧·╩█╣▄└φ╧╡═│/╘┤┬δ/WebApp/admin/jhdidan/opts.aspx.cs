﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp.admin.jhdidan
{
    public partial class opts : System.Web.UI.Page
    {
        Ctl.BLL.jhdidan bll = new Ctl.BLL.jhdidan();
        Ctl.Model.jhdidan model = new Ctl.Model.jhdidan();
       
        protected void Page_Load(object sender, EventArgs e)
        {

            ///模板
            if (!IsPostBack)
            {
                if (Request.QueryString["id"] == null || Request.QueryString["id"] == "") { };
                hidid.Value = Request.QueryString["id"];

                if (!string.IsNullOrWhiteSpace(hidid.Value))
                {
                    model = bll.GetModel(int.Parse(Request.QueryString["id"]));

                    if (model != null)
                    {
                        
                        txtjno.Value = model.jno;
                        txtjctime.Value = model.jctime;
                        txtjspname.Value = model.jspname;
                        txtjsptype.Value = model.jsptype;
                        txtjsptname.Value = model.jsptname;
                        txtjspmodel.Value = model.jspmodel;
                        txtjspno.Value = model.jspno;
                        txtjspnum.Value = model.jspnum.ToString();
                        txtjspprice.Value = model.jspprice.ToString();
                        txtjspsum.Value = model.jspsum.ToString();
                        txtjgykhid.Value = model.jgykhid.ToString();
                        txtjcguname.Value = model.jcguname;
                        txtjcgrek.Value = model.jcgrek;

                    }
                }
                else
                {
                    txtjno.Value = System.DateTime.Now.ToString("yyMMddHHmmssfff");
                    if (Session["adname"] != null)
                        txtjcguname.Value = Session["adname"].ToString();
                }

            }



            Ctl.Model.jhdidan modelone = new Ctl.Model.jhdidan();
            if (!IsPostBack)
            {
                if (Request.QueryString["id"] == null || Request.QueryString["id"] == "") { };
                hidids.Value = Request.QueryString["id"];

                if (!string.IsNullOrWhiteSpace(hidids.Value))
                {
                    modelone = bll.GetModel(int.Parse(Request.QueryString["id"]));

                    if (modelone != null)
                    {

                        onetxtjno.Value = modelone.jno;
                        onetxtjctime.Value = modelone.jctime;
                        onetxtjspname.Value = modelone.jspname;
                        onetxtjsptype.Value = modelone.jsptype;
                        onetxtjsptname.Value = modelone.jsptname;
                        onetxtjspmodel.Value = modelone.jspmodel;
                        onetxtjspno.Value = modelone.jspno;
                        onetxtjspnum.Value = modelone.jspnum.ToString();
                        onetxtjspprice.Value = modelone.jspprice.ToString();
                        onetxtjspsum.Value = modelone.jspsum.ToString();
                        onetxtjgykhid.Value = modelone.jgykhid.ToString();
                        onetxtjcguname.Value = modelone.jcguname;
                        onetxtjcgrek.Value = modelone.jcgrek;

                    }
                }
                else
                {
                    onetxtjno.Value = System.DateTime.Now.ToString("yyMMddHHmmssfff");
                    if (Session["adname"] != null)
                        onetxtjcguname.Value = Session["adname"].ToString();
                }

            }

        }





        /// <summary>
        /// /点击事件的方法
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnok_Click(object sender, EventArgs e)
        {

            string optid = hidid.Value;
            string jno = this.txtjno.Value;
            string jctime = this.txtjctime.Value;
            string jspname = this.txtjspname.Value;
            string jsptype = this.txtjsptype.Value;
            string jsptname = this.txtjsptname.Value;
            string jspmodel = this.txtjspmodel.Value;
            string jspno = this.txtjspno.Value;
            string jspnum = this.txtjspnum.Value;
            string jspprice = this.txtjspprice.Value;
            string jspsum = this.txtjspsum.Value;
            string jgykhid = this.txtjgykhid.Value;
            string jcguname = this.txtjcguname.Value;
            string jcgrek = this.txtjcgrek.Value;

            ///one
            string oneoptid = hidids.Value;
            string onejno = this.onetxtjno.Value;
            string onejctime = this.onetxtjctime.Value;
            string onejspname = this.onetxtjspname.Value;
            string onejsptype = this.onetxtjsptype.Value;
            string onejsptname = this.onetxtjsptname.Value;
            string onejspmodel = this.onetxtjspmodel.Value;
            string onejspno = this.onetxtjspno.Value;
            string onejspnum = this.onetxtjspnum.Value;
            string onejspprice = this.onetxtjspprice.Value;
            string onejspsum = this.onetxtjspsum.Value;
            string onejgykhid = this.onetxtjgykhid.Value;
            string onejcguname = this.onetxtjcguname.Value;
            string onejcgrek = this.onetxtjcgrek.Value;


            ////模板
            model = new Ctl.Model.jhdidan();
            //string sqlwh = " ulog='" + ulog + "' ";
            if (!string.IsNullOrEmpty(optid))
            {
                //    sqlwh += " and uid!=" + optid;
                model = bll.GetModel(int.Parse(optid));
            }
            //DataTable dtEx = bll.GetList(sqlwh).Tables[0];
            //if (dtEx.Rows.Count > 0)
            //{
            //    Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('重复，请更换!');</script>");
            //    return;
            //}
            model.jno = jno;
            model.jctime = jctime;
            model.jspname = jspname;
            model.jsptype = jsptype;
            model.jsptname = jsptname;
            model.jspmodel = jspmodel;
            model.jspno = jspno;
            model.jspnum = int.Parse(jspnum);
            model.jspprice = int.Parse(jspprice);
            model.jspsum = int.Parse(jspsum);
            model.jgykhid = int.Parse(jgykhid);
            model.jcguname = jcguname;
            model.jcgrek = jcgrek;


            ///one
            Ctl.Model.jhdidan modelone = new Ctl.Model.jhdidan();
            modelone = new Ctl.Model.jhdidan();
            //string sqlwh = " ulog='" + ulog + "' ";
            if (!string.IsNullOrEmpty(oneoptid))
            {
                //    sqlwh += " and uid!=" + optid;
                modelone = bll.GetModel(int.Parse(oneoptid));
            }
            //DataTable dtEx = bll.GetList(sqlwh).Tables[0];
            //if (dtEx.Rows.Count > 0)
            //{
            //    Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('重复，请更换!');</script>");
            //    return;
            //}
            modelone.jno = onejno;
            modelone.jctime = onejctime;
            modelone.jspname = onejspname;
            modelone.jsptype = onejsptype;
            modelone.jsptname = onejsptname;
            modelone.jspmodel = onejspmodel;
            modelone.jspno = onejspno;
            modelone.jspnum = int.Parse(onejspnum);
            modelone.jspprice = int.Parse(onejspprice);
            modelone.jspsum = int.Parse(onejspsum);
            modelone.jgykhid = int.Parse(onejgykhid);
            modelone.jcguname = onejcguname;
            modelone.jcgrek = onejcgrek;




            ////模板
            bool b = false;
            if (optid != "")
            {
                model.jckzt = 1;
                model.jcaddtime = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm");

                model.jckadduid = 0;
                model.jckadduname = "";
                model.jckaddtime = "";
                b = bll.Update(model);
            }
            else
            {

                if (Session["adid"] != null)
                    model.jcadduid = int.Parse(Session["adid"].ToString());
                if (Session["adname"] != null)
                    model.jcadduname = Session["adname"].ToString();

                model.jckzt = 1;
                model.jcaddtime = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm");
                b = bll.Add(model) > 0 ? true : false;
            }


            
            if (b)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('操作成功');window.location.href='list.aspx';</script>");
            }
            else
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('操作失败，稍候重试!');</script>");
                return;
            }


            bool a = false;
            if (oneoptid != "")
            {
                modelone.jckzt = 1;
                modelone.jcaddtime = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm");

                modelone.jckadduid = 1;
                modelone.jckadduname = "";
                modelone.jckaddtime = "";
                a = bll.Update(modelone);
            }
            else
            {

                if (Session["adid"] != null)
                    modelone.jcadduid = int.Parse(Session["adid"].ToString());
                if (Session["adname"] != null)
                    modelone.jcadduname = Session["adname"].ToString();

                modelone.jckzt = 1;
                modelone.jcaddtime = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm");
                a = bll.Add(modelone) > 0 ? true : false;
            }



            if (a)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('操作成功');window.location.href='list.aspx';</script>");
            }
            else
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('操作失败，稍候重试!');</script>");
                return;
            }


        }

    }
}