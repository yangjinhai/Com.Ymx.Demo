﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp.admin
{
    public partial class udpwd : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (Session["adid"] == null) return;
            string nowuid = Session["adid"].ToString();

            Ctl.BLL.userinfo dal = new Ctl.BLL.userinfo();
            Ctl.Model.userinfo model = new Ctl.Model.userinfo();

            string oldpwd = txtLogPwd.Value;
            string newpwd = txtLogPwdNew.Value;
            string newpwdsec = txtLogPwdNewSec.Value;
            string toUrl = "window.location.href='udpwd.aspx';";
            if (newpwd != newpwdsec)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('两次密码不一致!'); " + toUrl + "</script>");
                return;
            }
            if (string.IsNullOrEmpty(nowuid))
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('信息获取失败!'); " + toUrl + "</script>");
                return;
            }

            model = dal.GetModel(int.Parse(nowuid));
            if (model!=null)
            {
                if (oldpwd != model.upwd)
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('原密码不正确!'); " + toUrl + "</script>");
                    return;
                }
                else
                {
                    model.upwd = newpwdsec;
                    if (!dal.Update(model))
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('操作失败!'); " + toUrl + "</script>");
                        return;
                    }
                    CleaerData();
                    Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('保存成功!'); " + toUrl + "</script>");
                }
            }
        }

        private void CleaerData()
        {
            this.txtLogPwd.Value = this.txtLogPwdNew.Value = this.txtLogPwdNewSec.Value = "";
        }
    }
}
