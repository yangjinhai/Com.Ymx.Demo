﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp.admin
{
    public partial class logout : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Session["adid"] = null;
                Session["adlog"] = null;
                Session["adname"] = null;
                Session["adrole"] = null;
                Response.Redirect("login.aspx");
            }
            catch (Exception)
            { Response.Redirect("login.aspx"); }
        }
    }
}
