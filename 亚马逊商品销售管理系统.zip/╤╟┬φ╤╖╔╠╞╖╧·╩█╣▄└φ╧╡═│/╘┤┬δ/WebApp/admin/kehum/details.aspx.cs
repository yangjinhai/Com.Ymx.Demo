﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp.admin.kehum
{
    public partial class details : System.Web.UI.Page
    {
        Ctl.BLL.kehu bll = new Ctl.BLL.kehu();
        Ctl.Model.kehu model = new Ctl.Model.kehu();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["id"] == null || Request.QueryString["id"] == "") return;
                hidid.Value = Request.QueryString["id"];

                model = bll.GetModel(int.Parse(Request.QueryString["id"]));

                if (model != null)
                {
                    spkname.InnerText = model.kname;
                    spktel.InnerText = model.ktel;
                    spkaddress.InnerText = model.kaddress;
                    //spkfax.InnerText = model.kfax;
                    spkemail.InnerText = model.kemail;
                    spkdesc.InnerText = model.kdesc;
                    spkaddtime.InnerText = model.kaddtime;
                    spkadduname.InnerText = model.kadduname;

                }
            }
        }

        /// <summary>
        /// 返回
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnreturn_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
