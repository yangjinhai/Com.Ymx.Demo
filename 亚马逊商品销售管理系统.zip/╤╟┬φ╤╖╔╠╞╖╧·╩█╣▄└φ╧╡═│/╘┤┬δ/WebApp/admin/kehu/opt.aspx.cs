﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp.admin.kehu
{
    public partial class opt : System.Web.UI.Page
    {
        Ctl.BLL.kehu bll = new Ctl.BLL.kehu();
        Ctl.Model.kehu model = new Ctl.Model.kehu();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //LoadDdl();
                if (Request.QueryString["id"] == null || Request.QueryString["id"] == "") return;
                hidid.Value = Request.QueryString["id"];

                model = bll.GetModel(int.Parse(Request.QueryString["id"]));

                if (model != null)
                {
                    sptzg.InnerText = "修改";
                    txtkname.Value = model.kname;
                    txtkuser.Value = model.kuser;
                    txtktel.Value = model.ktel;
                    txtkaddress.Value = model.kaddress;
                    txtkfax.Value = model.kfax;
                    txtkemail.Value = model.kemail;
                    txtkdesc.Value = model.kdesc;

                }
            }
        }

        /// <summary>
        /// 绑定下拉框
        /// </summary>
        private void LoadDdl()
        {
            
        }



        /// <summary>
        /// 提交
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnok_Click(object sender, EventArgs e)
        {
            string optid = hidid.Value;

            string kname = this.txtkname.Value;
            string kuser = this.txtkuser.Value;
            string ktel = this.txtktel.Value;
            string kaddress = this.txtkaddress.Value;
            string kfax = this.txtkfax.Value;
            string kemail = this.txtkemail.Value;
            string kdesc = this.txtkdesc.Value;

            model = new Ctl.Model.kehu();
            string sqlwh = " kname='" + kname + "' ";
            if (!string.IsNullOrEmpty(optid))
            {
                sqlwh += " and kid!=" + optid;
                model = bll.GetModel(int.Parse(optid));
            }
            DataTable dtEx = bll.GetList(sqlwh).Tables[0];
            if (dtEx.Rows.Count > 0)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('客户名称已存在，请更换!');</script>");
                return;
            }
            model.kname = kname;
            model.kuser = kuser;
            model.ktel = ktel;
            model.kaddress = kaddress;
            model.kfax = kfax;
            model.kemail = kemail;
            model.kdesc = kdesc;


            bool b = false;
            if (optid != "")
            {
                b = bll.Update(model);
            }
            else
            {
                if (Session["adid"] != null)
                    model.kadduid = int.Parse(Session["adid"].ToString());
                if (Session["adname"] != null)
                    model.kadduname = Session["adname"].ToString();
                model.ktype = 1;
                model.kaddtime = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm");
                b = bll.Add(model) > 0 ? true : false;
            }
            if (b)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('操作成功');window.location.href='list.aspx';</script>");
            }
            else
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('操作失败，稍候重试!');</script>");
                return;
            }
        }

        /// <summary>
        /// 返回
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnreturn_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
