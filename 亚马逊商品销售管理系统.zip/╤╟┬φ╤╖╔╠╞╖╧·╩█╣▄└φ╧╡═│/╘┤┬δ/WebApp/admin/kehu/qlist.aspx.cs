﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace WebApp.admin.kehu
{
    public partial class qlist : System.Web.UI.Page
    {
        Ctl.BLL.kehu dal = new Ctl.BLL.kehu();
        Ctl.Model.kehu model = new Ctl.Model.kehu();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                InitData();
            }
        }

        /// <summary>
        /// 加载数据
        /// </summary>
        private void InitData()
        {
            DataSet ds = null;
            string sql1 = "ktype=1 and ";

            if (txtkey.Value != "")
            {
                sql1 += " (";
                sql1 += " kname like '%" + txtkey.Value + "%'  or ";
                sql1 += " kuser like '%" + txtkey.Value + "%'  or ";
                sql1 += " ktel like '%" + txtkey.Value + "%'  or ";
                sql1 += " kaddress like '%" + txtkey.Value + "%'  or ";
                sql1 += " kfax like '%" + txtkey.Value + "%'  or ";
                sql1 += " kemail like '%" + txtkey.Value + "%'  or ";
                sql1 += " kdesc like '%" + txtkey.Value + "%'  or ";
                sql1 += " kaddtime like '%" + txtkey.Value + "%'  or ";
                sql1 += " kadduname like '%" + txtkey.Value + "%' ";

                sql1 += ") and ";
            }

            if (!string.IsNullOrEmpty(sql1)) sql1 = sql1.Substring(0, sql1.Length - 4);

            ds = new Ctl.BLL.kehu().GetList(0, sql1, "kid desc");
            gv.DataSource = ds;
            gv.DataBind();
        }

        /// <summary>
        /// 分页提取
        /// </summary>
        /// <param name="pageno"></param>
        private void ToPage(int pageno)
        {
            gv.PageIndex = pageno;
            InitData();
        }

        /// <summary>
        /// 分页跳转
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            ToPage(e.NewPageIndex);
        }

        /// <summary>
        /// 搜索
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            InitData();
        }

        /// <summary>
        /// 列表操作
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gv_RowCommand(object sender, GridViewCommandEventArgs e)
        {

            if (e.CommandName == "del")
            {
                string opid = e.CommandArgument.ToString();
                
            }

        }
    }
}
