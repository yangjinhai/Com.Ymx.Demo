﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp.admin.userinfo
{
    public partial class details : System.Web.UI.Page
    {
        Ctl.BLL.userinfo bll = new Ctl.BLL.userinfo();
        Ctl.Model.userinfo model = new Ctl.Model.userinfo();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["id"] == null || Request.QueryString["id"] == "") return;
                hidid.Value = Request.QueryString["id"];

                model = bll.GetModel(int.Parse(Request.QueryString["id"]));

                if (model != null)
                {
                    spulog.InnerText = model.ulog;
                    spuname.InnerText = model.uname;
                    spusex.InnerText = model.usex;
                    spudept.InnerText = model.udept;
                    spupost.InnerText = model.upost;
                    spuidentid.InnerText = model.uidentid;
                    sputel.InnerText = model.utel;
                    spuemail.InnerText = model.uemail;
                    spuaddress.InnerText = model.uaddress;
                    spurole.InnerText = getzt(model.urole.ToString());
                    spuaddtime.InnerText = model.uaddtime;

                }
            }
        }
        public string getzt(string _zt)
        {
            string re = "";
            switch (_zt)
            {
                case "1": re = "采购员"; break;
                case "2": re = "库管员"; break;
                case "3": re = "销售员"; break;
            }
            return re;
        }

        /// <summary>
        /// 返回
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnreturn_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
