﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace WebApp.admin.userinfo
{
    public partial class list : System.Web.UI.Page
    {
        Ctl.BLL.userinfo dal = new Ctl.BLL.userinfo();
        Ctl.Model.userinfo model = new Ctl.Model.userinfo();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                InitData();
            }
        }

        /// <summary>
        /// 加载数据
        /// </summary>
        private void InitData()
        {
            DataSet ds = null;
            string sql1 = "urole<9 and ";

            if (txtkey.Value != "")
            {
                sql1 += " (";
                sql1 += " ulog like '%" + txtkey.Value + "%'  or ";
                sql1 += " uname like '%" + txtkey.Value + "%'  or ";
                sql1 += " usex like '%" + txtkey.Value + "%'  or ";
                sql1 += " udept like '%" + txtkey.Value + "%'  or ";
                sql1 += " upost like '%" + txtkey.Value + "%'  or ";
                sql1 += " uidentid like '%" + txtkey.Value + "%'  or ";
                sql1 += " utel like '%" + txtkey.Value + "%'  or ";
                sql1 += " uemail like '%" + txtkey.Value + "%'  or ";
                sql1 += " uaddress like '%" + txtkey.Value + "%'  or ";
                sql1 += " uaddtime like '%" + txtkey.Value + "%' ";

                sql1 += ") and ";
            }

            if (!string.IsNullOrEmpty(sql1)) sql1 = sql1.Substring(0, sql1.Length - 4);

            ds = new Ctl.BLL.userinfo().GetList(0, sql1, "uid desc");
            gv.DataSource = ds;
            gv.DataBind();
        }

        /// <summary>
        /// 分页提取
        /// </summary>
        /// <param name="pageno"></param>
        private void ToPage(int pageno)
        {
            gv.PageIndex = pageno;
            InitData();
        }

        /// <summary>
        /// 分页跳转
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            ToPage(e.NewPageIndex);
        }

        /// <summary>
        /// 搜索
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            InitData();
        }

        /// <summary>
        /// 列表操作
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gv_RowCommand(object sender, GridViewCommandEventArgs e)
        {

            if (e.CommandName == "del")
            {
                string opid = e.CommandArgument.ToString();
               
                if (dal.Delete(int.Parse(opid)))
                {
                    Maticsoft.Common.MessageBox.ShowAndRedirect(this, "删除成功", "list.aspx" + Request.Url.Query);
                }
                else
                {
                    Maticsoft.Common.MessageBox.Show(this, "失败，请稍候重试"); return;
                }
            }

        }

        public string getzt(string _zt)
        {
            string re = "";
            switch (_zt)
            {
                case "1": re = "采购员"; break;
                case "2": re = "库管员"; break;
                case "3": re = "销售员"; break;
            }
            return re;
        }
    }
}
