﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp.admin.userinfo
{
    public partial class opt : System.Web.UI.Page
    {
        Ctl.BLL.userinfo bll = new Ctl.BLL.userinfo();
        Ctl.Model.userinfo model = new Ctl.Model.userinfo();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //LoadDdl();
                if (Request.QueryString["id"] == null || Request.QueryString["id"] == "") return;
                hidid.Value = Request.QueryString["id"];

                model = bll.GetModel(int.Parse(Request.QueryString["id"]));

                if (model != null)
                {
                    sptzg.InnerText = "修改";
                    txtulog.Value = model.ulog;
                    txtupwd.Value = model.upwd;
                    txtuname.Value = model.uname;
                    txtusex.SelectedValue = model.usex;
                    txtudept.Value = model.udept;
                    txtupost.Value = model.upost;
                    txtuidentid.Value = model.uidentid;
                    txtutel.Value = model.utel;
                    txtuemail.Value = model.uemail;
                    txtuaddress.Value = model.uaddress;
                    txturole.SelectedValue = model.urole.ToString();

                }
            }
        }

        /// <summary>
        /// 绑定下拉框
        /// </summary>
        private void LoadDdl()
        {
            //ddli_type.Items.Clear();
            DataSet ds = new DataSet();
            //ds=new Ctl.BLL.tb_user().GetList("");
            //ddli_type.DataTextField = "u_name";
            //ddli_type.DataValueField = "u_id";
            //ddli_type.DataSource = ds;
            //ddli_type.DataBind();

            //ddli_type.Items.Insert(0, new ListItem("--请选择--", ""));
            //ddli_type.SelectedIndex = 0;
        }



        /// <summary>
        /// 提交
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnok_Click(object sender, EventArgs e)
        {
            string optid = hidid.Value;

            string ulog = this.txtulog.Value;
            string upwd = this.txtupwd.Value;
            string uname = this.txtuname.Value;
            string usex = this.txtusex.SelectedValue;
            string udept = this.txtudept.Value;
            string upost = this.txtupost.Value;
            string uidentid = this.txtuidentid.Value;
            string utel = this.txtutel.Value;
            string uemail = this.txtuemail.Value;
            string uaddress = this.txtuaddress.Value;
            string urole = this.txturole.SelectedValue;

            model = new Ctl.Model.userinfo();
            string sqlwh = " ulog='" + ulog + "' ";
            if (!string.IsNullOrEmpty(optid))
            {
                sqlwh += " and uid!=" + optid;
                model = bll.GetModel(int.Parse(optid));
            }
            DataTable dtEx = bll.GetList(sqlwh).Tables[0];
            if (dtEx.Rows.Count > 0)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('账号重复，请更换!');</script>");
                return;
            }
            model.ulog = ulog;
            model.upwd = upwd;
            model.uname = uname;
            model.usex = usex;
            model.udept = udept;
            model.upost = upost;
            model.uidentid = uidentid;
            model.utel = utel;
            model.uemail = uemail;
            model.uaddress = uaddress;
            model.urole = int.Parse(urole);


            bool b = false;
            if (optid != "")
            {
                b = bll.Update(model);
            }
            else
            {
                model.uaddtime = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm");
                b = bll.Add(model) > 0 ? true : false;
            }
            if (b)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('操作成功');window.location.href='list.aspx';</script>");
            }
            else
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('操作失败，稍候重试!');</script>");
                return;
            }
        }

        /// <summary>
        /// 返回
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnreturn_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
