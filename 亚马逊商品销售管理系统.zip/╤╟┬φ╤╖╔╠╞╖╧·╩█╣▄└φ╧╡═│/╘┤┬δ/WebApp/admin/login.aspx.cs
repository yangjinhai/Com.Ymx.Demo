﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace WebApp.admin
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string loginname = this.txtlog.Value.Trim();
            string logpwd = this.txtpwd.Value.Trim();
            string logincode = this.txtcode.Value.Trim();

            #region Exsit Null
            if (string.IsNullOrEmpty(loginname))
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('账号不能为空');</script>");
                return;
            }
            if (string.IsNullOrEmpty(logpwd))
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('密码不能为空');</script>");
                return;
            }
            if (string.IsNullOrEmpty(logincode))
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('验证码不能为空');</script>");
                return;
            } 
            #endregion

            #region Exsit Vcode
            if (Session["ValidateNumber"] == null)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('验证码失效，刷新页面重试！');location.href='login.aspx';</script>");
                return;
            }
            string vcode = Session["ValidateNumber"].ToString();
            if (logincode != vcode)
            {
                this.txtcode.Value = "";
                Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('请输入正确的验证码');</script>");
                return;
            } 
            #endregion
			
            #region Exsit AutoUr
			DataTable dtEx = new Ctl.BLL.userinfo().GetList(" urole in(9)  ").Tables[0];
            if (dtEx.Rows.Count==0)
            {
                Ctl.Model.userinfo molu = new Ctl.Model.userinfo();
                molu.uaddress = "朝阳区大同路测试28号";
                molu.uaddtime = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm");
                molu.uemail = "admin@qq.com";
                molu.uidentid = "168587199501251725";
                molu.ulog = "admin";
                molu.uname = "管理员";
                molu.upwd = "000000";
                molu.udept = "信息部";
                molu.upost = "信管员";
                molu.urole = 9;
                molu.usex = "男";
                molu.utel = "13512345678";
                new Ctl.BLL.userinfo().Add(molu);
            }
            #endregion

            Ctl.BLL.userinfo dalu = new Ctl.BLL.userinfo();
            DataTable dt = dalu.GetList(" ulog='" + loginname + "' and upwd='" + logpwd + "'  ").Tables[0];
            if (dt.Rows.Count == 0)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('账号或密码不正确');</script>");
                return;
            }
            Session["adid"] = dt.Rows[0]["uid"];
            Session["adlog"] = dt.Rows[0]["ulog"];
            Session["adname"] = dt.Rows[0]["uname"];
            Session["adrole"] = dt.Rows[0]["urole"];
            dt.Dispose();
            Response.Redirect("/admin/main.aspx");
        }
    }
}
