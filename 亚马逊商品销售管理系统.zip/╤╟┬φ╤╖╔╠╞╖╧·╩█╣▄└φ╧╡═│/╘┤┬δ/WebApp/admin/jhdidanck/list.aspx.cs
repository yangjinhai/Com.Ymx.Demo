﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace WebApp.admin.jhdidanck
{
    public partial class list : System.Web.UI.Page
    {
        Ctl.BLL.jhdidan dal = new Ctl.BLL.jhdidan();
        Ctl.Model.jhdidan model = new Ctl.Model.jhdidan();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                InitData();
            }
        }

        /// <summary>
        /// 加载数据
        /// </summary>
        private void InitData()
        {
            DataSet ds = null;
            string sql1 = "jckzt=1 and ";

            if (txtkey.Value != "")
            {
                sql1 += " (";
                sql1 += " jno like '%" + txtkey.Value + "%'  or ";
                sql1 += " jctime like '%" + txtkey.Value + "%'  or ";
                sql1 += " jspname like '%" + txtkey.Value + "%'  or ";
                sql1 += " jsptype like '%" + txtkey.Value + "%'  or ";
                sql1 += " jsptname like '%" + txtkey.Value + "%'  or ";
                sql1 += " jspmodel like '%" + txtkey.Value + "%'  or ";
                sql1 += " jspno like '%" + txtkey.Value + "%'  or ";
                sql1 += " jcguname like '%" + txtkey.Value + "%'  or ";
                sql1 += " jcgrek like '%" + txtkey.Value + "%'  or ";
                sql1 += " jcadduname like '%" + txtkey.Value + "%'  or ";
                sql1 += " jcaddtime like '%" + txtkey.Value + "%'  or ";
                sql1 += " jckadduname like '%" + txtkey.Value + "%'  or ";
                sql1 += " jckaddtime like '%" + txtkey.Value + "%'  or ";
                sql1 += " jckrek like '%" + txtkey.Value + "%' ";

                sql1 += ") and ";
            }

            if (!string.IsNullOrEmpty(sql1)) sql1 = sql1.Substring(0, sql1.Length - 4);

            ds = new Ctl.BLL.vwjhdidan().GetList(0, sql1, "jid desc");
            gv.DataSource = ds;
            gv.DataBind();
        }

        /// <summary>
        /// 分页提取
        /// </summary>
        /// <param name="pageno"></param>
        private void ToPage(int pageno)
        {
            gv.PageIndex = pageno;
            InitData();
        }

        /// <summary>
        /// 分页跳转
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            ToPage(e.NewPageIndex);
        }

        /// <summary>
        /// 搜索
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            InitData();
        }

        /// <summary>
        /// 列表操作
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gv_RowCommand(object sender, GridViewCommandEventArgs e)
        {

            if (e.CommandName == "del")
            {
                string opid = e.CommandArgument.ToString();
                
            }

        }
        public string getzt(string _zt)
        {
            string re = "";
            switch (_zt)
            {
                case "1": re = "待审"; break;
                case "2": re = "不予通过"; break;
                case "3": re = "审核通过"; break;
            }
            return re;
        }
    }
}
