﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp.admin.jhdidanck
{
    public partial class check : System.Web.UI.Page
    {
        Ctl.BLL.jhdidan bll = new Ctl.BLL.jhdidan();
        Ctl.Model.jhdidan model = new Ctl.Model.jhdidan();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["id"] == null || Request.QueryString["id"] == "") return;
                hidid.Value = Request.QueryString["id"];

                Ctl.Model.vwjhdidan model = new Ctl.BLL.vwjhdidan().GetModel(int.Parse(Request.QueryString["id"]));

                if (model != null)
                {
                    spjno.InnerText = model.jno;
                    spjctime.InnerText = model.jctime;
                    spjspname.InnerText = model.jspname;
                    spjsptype.InnerText = model.jsptype;
                    spjsptname.InnerText = model.jsptname;
                    spjspmodel.InnerText = model.jspmodel;
                    spjspno.InnerText = model.jspno;
                    spjspnum.InnerText = model.jspnum.ToString();
                    spjspprice.InnerText = model.jspprice.ToString();
                    spjspsum.InnerText = model.jspsum.ToString();
                    spjgykhid.InnerText = model.kname.ToString();
                    spjcguname.InnerText = model.jcguname;
                    spjcgrek.InnerText = model.jcgrek;
                    spjcadduname.InnerText = model.jcadduname;
                    spjcaddtime.InnerText = model.jcaddtime;

                }
            }
        }



        /// <summary>
        /// 提交
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnok_Click(object sender, EventArgs e)
        {
            string optid = hidid.Value;

            string jckzt = this.txtjckzt.SelectedValue;

            model = new Ctl.Model.jhdidan();
            model = bll.GetModel(int.Parse(optid));
            
            model.jckzt = int.Parse(jckzt);
            if (Session["adid"] != null)
                model.jckadduid = int.Parse(Session["adid"].ToString());
            if (Session["adname"] != null)
                model.jckadduname = Session["adname"].ToString();
            model.jckaddtime = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm");


            bool b = bll.Update(model);
            if (b)
            {
                if (model.jckzt==3)
                {
                    DataTable dt = new Ctl.BLL.gproc().GetList("pname='" + model.jspname + "' and ptype='" + model.jsptype + "' and ptname='" + model.jsptname + "' and pmodel='" + model.jspmodel + "' and pkhid=" + model.jgykhid + "").Tables[0];
                    if (dt.Rows.Count>0)
                    {
                        Ctl.Model.gproc molp = new Ctl.BLL.gproc().GetModel(int.Parse(dt.Rows[0]["pid"].ToString()));
                        molp.pnum += model.jspnum;
                        new Ctl.BLL.gproc().Update(molp);
                    }
                    else
                    {
                        Ctl.Model.gproc molp = new Ctl.Model.gproc();
                        molp.paddtime = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm");
                        molp.padduid = model.jckadduid;
                        molp.padduname = model.jckadduname;
                        molp.pkhid = model.jgykhid;
                        
                        molp.pmodel = model.jspmodel;
                        molp.pname = model.jspname;
                        molp.pno = model.jspno;
                        molp.pnum = model.jspnum;
                        molp.ptname = model.jsptname;
                        molp.ptype = model.jsptype;
                        new Ctl.BLL.gproc().Add(molp);
                    }
                }

                Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('操作成功');window.location.href='listed.aspx';</script>");
            }
            else
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('操作失败，稍候重试!');</script>");
                return;
            }
        }

        /// <summary>
        /// 返回
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnreturn_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
