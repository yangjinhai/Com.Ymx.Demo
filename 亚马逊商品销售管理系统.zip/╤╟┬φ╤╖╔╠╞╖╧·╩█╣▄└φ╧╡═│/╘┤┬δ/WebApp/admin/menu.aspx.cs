﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp.admin
{
    public partial class menu : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                 if (Session["adid"] == null) return;
                string nowuid = Session["adid"].ToString();

                Ctl.BLL.userinfo dal = new Ctl.BLL.userinfo();
                Ctl.Model.userinfo model = new Ctl.Model.userinfo();
                model = dal.GetModel(int.Parse(nowuid));
                if (model != null)
                {
                    if (model.urole==9)
                    {
                        liyggl01.Visible = true;
                        liyggl01a.Visible = true;

                        lixxcx01.Visible = true;
                        lixxcx01a.Visible = true;

                        libbtj01.Visible = true;
                        libbtj01a.Visible = true;
                    }
                    else if (model.urole==1)
                    {
                        likhgl01.Visible = true;
                        likhgl01a.Visible = true;

                        lijcgl01.Visible = true;
                        lijcgl01a.Visible = true;
                    }
                    else if (model.urole == 2)
                    {
                        likcgl01.Visible = true;
                        likcgl01a.Visible = true;
                    }
                    else if (model.urole == 3)
                    {
                        lixsgl01.Visible = true;
                        lixsgl01a.Visible = true;

                        likhgl02.Visible = true;
                        likhgl02a.Visible = true;
                    }
                }
            }
        }
    }
}
