﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp.admin
{
    public partial class top : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           if (!IsPostBack)
            {
                if (Session["adid"] == null)
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>window.parent.alert('网络超时，请重新登录');window.parent.location.href='login.aspx';</script>");
                    return;
                }
                splog.InnerText = Session["adlog"].ToString();
                spname.InnerText = Session["adname"].ToString();
            }
        }
    }
}
