using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using Maticsoft.DBUtility;

namespace Ctl.DAL
{
    /// <summary>
    /// 数据访问类:jhdidan
    /// </summary>
    public partial class jhdidan
    {
        public jhdidan()
        { }
        #region  Method

        /// <summary>
        /// 得到最大ID
        /// </summary>
        public int GetMaxId()
        {
            return DbHelperSQL.GetMaxID("jid", "jhdidan");
        }


        /// <summary>
        /// 是否存在该记录
        /// </summary>
        public bool Exists(int pkId)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) from jhdidan");
            strSql.Append(" where jid=" + pkId + " ");
            return DbHelperSQL.Exists(strSql.ToString());
        }


        /// <summary>
        /// 增加一条数据
        /// </summary>
        public int Add(Ctl.Model.jhdidan model)
        {
            StringBuilder strSql = new StringBuilder();
            StringBuilder strSql1 = new StringBuilder();
            StringBuilder strSql2 = new StringBuilder();
            if (model.jno != null)
            {
                strSql1.Append("jno,");
                strSql2.Append("'" + model.jno + "',");
            }
            if (model.jctime != null)
            {
                strSql1.Append("jctime,");
                strSql2.Append("'" + model.jctime + "',");
            }
            if (model.jspname != null)
            {
                strSql1.Append("jspname,");
                strSql2.Append("'" + model.jspname + "',");
            }
            if (model.jsptype != null)
            {
                strSql1.Append("jsptype,");
                strSql2.Append("'" + model.jsptype + "',");
            }
            if (model.jsptname != null)
            {
                strSql1.Append("jsptname,");
                strSql2.Append("'" + model.jsptname + "',");
            }
            if (model.jspmodel != null)
            {
                strSql1.Append("jspmodel,");
                strSql2.Append("'" + model.jspmodel + "',");
            }
            if (model.jspno != null)
            {
                strSql1.Append("jspno,");
                strSql2.Append("'" + model.jspno + "',");
            }
            if (model.jspnum != null)
            {
                strSql1.Append("jspnum,");
                strSql2.Append("" + model.jspnum + ",");
            }
            if (model.jspprice != null)
            {
                strSql1.Append("jspprice,");
                strSql2.Append("" + model.jspprice + ",");
            }
            if (model.jspsum != null)
            {
                strSql1.Append("jspsum,");
                strSql2.Append("" + model.jspsum + ",");
            }
            if (model.jgykhid != null)
            {
                strSql1.Append("jgykhid,");
                strSql2.Append("" + model.jgykhid + ",");
            }
            if (model.jcguname != null)
            {
                strSql1.Append("jcguname,");
                strSql2.Append("'" + model.jcguname + "',");
            }
            if (model.jcgrek != null)
            {
                strSql1.Append("jcgrek,");
                strSql2.Append("'" + model.jcgrek + "',");
            }
            if (model.jcadduid != null)
            {
                strSql1.Append("jcadduid,");
                strSql2.Append("" + model.jcadduid + ",");
            }
            if (model.jcadduname != null)
            {
                strSql1.Append("jcadduname,");
                strSql2.Append("'" + model.jcadduname + "',");
            }
            if (model.jcaddtime != null)
            {
                strSql1.Append("jcaddtime,");
                strSql2.Append("'" + model.jcaddtime + "',");
            }
            if (model.jckzt != null)
            {
                strSql1.Append("jckzt,");
                strSql2.Append("" + model.jckzt + ",");
            }
            if (model.jckadduid != null)
            {
                strSql1.Append("jckadduid,");
                strSql2.Append("" + model.jckadduid + ",");
            }
            if (model.jckadduname != null)
            {
                strSql1.Append("jckadduname,");
                strSql2.Append("'" + model.jckadduname + "',");
            }
            if (model.jckaddtime != null)
            {
                strSql1.Append("jckaddtime,");
                strSql2.Append("'" + model.jckaddtime + "',");
            }
            if (model.jckrek != null)
            {
                strSql1.Append("jckrek,");
                strSql2.Append("'" + model.jckrek + "',");
            }
            if (model.jcby != null)
            {
                strSql1.Append("jcby,");
                strSql2.Append("'" + model.jcby + "',");
            }
            if (model.jcbyv != null)
            {
                strSql1.Append("jcbyv,");
                strSql2.Append("" + model.jcbyv + ",");
            }

            strSql.Append("insert into jhdidan(");
            strSql.Append(strSql1.ToString().Remove(strSql1.Length - 1));
            strSql.Append(")");
            strSql.Append(" values (");
            strSql.Append(strSql2.ToString().Remove(strSql2.Length - 1));
            strSql.Append(")");
            strSql.Append(";select @@IDENTITY");
            object obj = DbHelperSQL.GetSingle(strSql.ToString());
            if (obj == null)
            {
                return 0;
            }
            else
            {
                return Convert.ToInt32(obj);
            }
        }

        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool Update(Ctl.Model.jhdidan model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update jhdidan set ");
            if (model.jno != null)
            {
                strSql.Append("jno='" + model.jno + "',");
            }
            else
            {
                strSql.Append("jno= null ,");
            }
            if (model.jctime != null)
            {
                strSql.Append("jctime='" + model.jctime + "',");
            }
            else
            {
                strSql.Append("jctime= null ,");
            }
            if (model.jspname != null)
            {
                strSql.Append("jspname='" + model.jspname + "',");
            }
            else
            {
                strSql.Append("jspname= null ,");
            }
            if (model.jsptype != null)
            {
                strSql.Append("jsptype='" + model.jsptype + "',");
            }
            else
            {
                strSql.Append("jsptype= null ,");
            }
            if (model.jsptname != null)
            {
                strSql.Append("jsptname='" + model.jsptname + "',");
            }
            else
            {
                strSql.Append("jsptname= null ,");
            }
            if (model.jspmodel != null)
            {
                strSql.Append("jspmodel='" + model.jspmodel + "',");
            }
            else
            {
                strSql.Append("jspmodel= null ,");
            }
            if (model.jspno != null)
            {
                strSql.Append("jspno='" + model.jspno + "',");
            }
            else
            {
                strSql.Append("jspno= null ,");
            }
            if (model.jspnum != null)
            {
                strSql.Append("jspnum=" + model.jspnum + ",");
            }
            else
            {
                strSql.Append("jspnum= null ,");
            }
            if (model.jspprice != null)
            {
                strSql.Append("jspprice=" + model.jspprice + ",");
            }
            else
            {
                strSql.Append("jspprice= null ,");
            }
            if (model.jspsum != null)
            {
                strSql.Append("jspsum=" + model.jspsum + ",");
            }
            else
            {
                strSql.Append("jspsum= null ,");
            }
            if (model.jgykhid != null)
            {
                strSql.Append("jgykhid=" + model.jgykhid + ",");
            }
            else
            {
                strSql.Append("jgykhid= null ,");
            }
            if (model.jcguname != null)
            {
                strSql.Append("jcguname='" + model.jcguname + "',");
            }
            else
            {
                strSql.Append("jcguname= null ,");
            }
            if (model.jcgrek != null)
            {
                strSql.Append("jcgrek='" + model.jcgrek + "',");
            }
            else
            {
                strSql.Append("jcgrek= null ,");
            }
            if (model.jcadduid != null)
            {
                strSql.Append("jcadduid=" + model.jcadduid + ",");
            }
            else
            {
                strSql.Append("jcadduid= null ,");
            }
            if (model.jcadduname != null)
            {
                strSql.Append("jcadduname='" + model.jcadduname + "',");
            }
            else
            {
                strSql.Append("jcadduname= null ,");
            }
            if (model.jcaddtime != null)
            {
                strSql.Append("jcaddtime='" + model.jcaddtime + "',");
            }
            else
            {
                strSql.Append("jcaddtime= null ,");
            }
            if (model.jckzt != null)
            {
                strSql.Append("jckzt=" + model.jckzt + ",");
            }
            else
            {
                strSql.Append("jckzt= null ,");
            }
            if (model.jckadduid != null)
            {
                strSql.Append("jckadduid=" + model.jckadduid + ",");
            }
            else
            {
                strSql.Append("jckadduid= null ,");
            }
            if (model.jckadduname != null)
            {
                strSql.Append("jckadduname='" + model.jckadduname + "',");
            }
            else
            {
                strSql.Append("jckadduname= null ,");
            }
            if (model.jckaddtime != null)
            {
                strSql.Append("jckaddtime='" + model.jckaddtime + "',");
            }
            else
            {
                strSql.Append("jckaddtime= null ,");
            }
            if (model.jckrek != null)
            {
                strSql.Append("jckrek='" + model.jckrek + "',");
            }
            else
            {
                strSql.Append("jckrek= null ,");
            }
            if (model.jcby != null)
            {
                strSql.Append("jcby='" + model.jcby + "',");
            }
            else
            {
                strSql.Append("jcby= null ,");
            }
            if (model.jcbyv != null)
            {
                strSql.Append("jcbyv=" + model.jcbyv + ",");
            }
            else
            {
                strSql.Append("jcbyv= null ,");
            }

            int n = strSql.ToString().LastIndexOf(",");
            strSql.Remove(n, 1);
            strSql.Append(" where jid=" + model.jid + "");
            int rowsAffected = DbHelperSQL.ExecuteSql(strSql.ToString());
            if (rowsAffected > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 删除一条数据
        /// </summary>
        public bool Delete(int pkId)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from jhdidan ");
            strSql.Append(" where jid=" + pkId + "");
            int rowsAffected = DbHelperSQL.ExecuteSql(strSql.ToString());
            if (rowsAffected > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 批量删除数据
        /// </summary>
        public bool DeleteList(string idlist)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from jhdidan ");
            strSql.Append(" where jid in (" + idlist + ")  ");
            int rows = DbHelperSQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Ctl.Model.jhdidan GetModel(int pkId)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select  top 1  ");
            strSql.Append(" jid,jno,jctime,jspname,jsptype,jsptname,jspmodel,jspno,jspnum,jspprice,jspsum,jgykhid,jcguname,jcgrek,jcadduid,jcadduname,jcaddtime,jckzt,jckadduid,jckadduname,jckaddtime,jckrek,jcby,jcbyv ");
            strSql.Append(" from jhdidan ");
            strSql.Append(" where jid=" + pkId + "");
            Ctl.Model.jhdidan model = new Ctl.Model.jhdidan();
            DataSet ds = DbHelperSQL.Query(strSql.ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Ctl.Model.jhdidan DataRowToModel(DataRow row)
        {
            Ctl.Model.jhdidan model = new Ctl.Model.jhdidan();
            if (row != null)
            {
                if (row["jid"] != null && row["jid"].ToString() != "")
                {
                    model.jid = int.Parse(row["jid"].ToString());
                }
                if (row["jno"] != null)
                {
                    model.jno = row["jno"].ToString();
                }
                if (row["jctime"] != null)
                {
                    model.jctime = row["jctime"].ToString();
                }
                if (row["jspname"] != null)
                {
                    model.jspname = row["jspname"].ToString();
                }
                if (row["jsptype"] != null)
                {
                    model.jsptype = row["jsptype"].ToString();
                }
                if (row["jsptname"] != null)
                {
                    model.jsptname = row["jsptname"].ToString();
                }
                if (row["jspmodel"] != null)
                {
                    model.jspmodel = row["jspmodel"].ToString();
                }
                if (row["jspno"] != null)
                {
                    model.jspno = row["jspno"].ToString();
                }
                if (row["jspnum"] != null && row["jspnum"].ToString() != "")
                {
                    model.jspnum = int.Parse(row["jspnum"].ToString());
                }
                if (row["jspprice"] != null && row["jspprice"].ToString() != "")
                {
                    model.jspprice = int.Parse(row["jspprice"].ToString());
                }
                if (row["jspsum"] != null && row["jspsum"].ToString() != "")
                {
                    model.jspsum = int.Parse(row["jspsum"].ToString());
                }
                if (row["jgykhid"] != null && row["jgykhid"].ToString() != "")
                {
                    model.jgykhid = int.Parse(row["jgykhid"].ToString());
                }
                if (row["jcguname"] != null)
                {
                    model.jcguname = row["jcguname"].ToString();
                }
                if (row["jcgrek"] != null)
                {
                    model.jcgrek = row["jcgrek"].ToString();
                }
                if (row["jcadduid"] != null && row["jcadduid"].ToString() != "")
                {
                    model.jcadduid = int.Parse(row["jcadduid"].ToString());
                }
                if (row["jcadduname"] != null)
                {
                    model.jcadduname = row["jcadduname"].ToString();
                }
                if (row["jcaddtime"] != null)
                {
                    model.jcaddtime = row["jcaddtime"].ToString();
                }
                if (row["jckzt"] != null && row["jckzt"].ToString() != "")
                {
                    model.jckzt = int.Parse(row["jckzt"].ToString());
                }
                if (row["jckadduid"] != null && row["jckadduid"].ToString() != "")
                {
                    model.jckadduid = int.Parse(row["jckadduid"].ToString());
                }
                if (row["jckadduname"] != null)
                {
                    model.jckadduname = row["jckadduname"].ToString();
                }
                if (row["jckaddtime"] != null)
                {
                    model.jckaddtime = row["jckaddtime"].ToString();
                }
                if (row["jckrek"] != null)
                {
                    model.jckrek = row["jckrek"].ToString();
                }
                if (row["jcby"] != null)
                {
                    model.jcby = row["jcby"].ToString();
                }
                if (row["jcbyv"] != null && row["jcbyv"].ToString() != "")
                {
                    model.jcbyv = int.Parse(row["jcbyv"].ToString());
                }

            }
            return model;
        }

        /// <summary>
        /// 获得数据列表
        /// </summary>
        public DataSet GetList(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select jid,jno,jctime,jspname,jsptype,jsptname,jspmodel,jspno,jspnum,jspprice,jspsum,jgykhid,jcguname,jcgrek,jcadduid,jcadduname,jcaddtime,jckzt,jckadduid,jckadduname,jckaddtime,jckrek,jcby,jcbyv ");
            strSql.Append(" FROM jhdidan ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            return DbHelperSQL.Query(strSql.ToString());
        }

        /// <summary>
        /// 获得前几行数据
        /// </summary>
        public DataSet GetList(int Top, string strWhere, string filedOrder)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select ");
            if (Top > 0)
            {
                strSql.Append(" top " + Top.ToString());
            }
            strSql.Append(" jid,jno,jctime,jspname,jsptype,jsptname,jspmodel,jspno,jspnum,jspprice,jspsum,jgykhid,jcguname,jcgrek,jcadduid,jcadduname,jcaddtime,jckzt,jckadduid,jckadduname,jckaddtime,jckrek,jcby,jcbyv ");
            strSql.Append(" FROM jhdidan ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            strSql.Append(" order by " + filedOrder);
            return DbHelperSQL.Query(strSql.ToString());
        }
        public DataSet GetListTJ(int Top, string strWhere, string filedOrder)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select ");
            if (Top > 0)
            {
                strSql.Append(" top " + Top.ToString());
            }
            strSql.Append("  SUBSTRING(jcaddtime,0,11) rq,sum(jspnum) sl,SUM(jspsum) je from jhdidan  ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            strSql.Append(" group by SUBSTRING(jcaddtime,0,11)  order by SUBSTRING(jcaddtime,0,11) desc ");
            return DbHelperSQL.Query(strSql.ToString());
        }
        public DataSet GetListTJ2(int Top, string strWhere, string filedOrder)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select ");
            if (Top > 0)
            {
                strSql.Append(" top " + Top.ToString());
            }
            strSql.Append("  SUBSTRING(jckaddtime,0,11) rq,sum(jspnum) sl,SUM(jspsum) je from jhdidan where jckzt=3  ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" and " + strWhere);
            }
            strSql.Append(" group by SUBSTRING(jckaddtime,0,11)  order by SUBSTRING(jckaddtime,0,11) desc ");
            return DbHelperSQL.Query(strSql.ToString());
        }
        public DataSet GetListTJ3(int Top, string strWhere, string filedOrder)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select ");
            if (Top > 0)
            {
                strSql.Append(" top " + Top.ToString());
            }
            strSql.Append("  SUBSTRING(xsckaddtime,0,11) rq,sum(xspnum) sl,SUM(xspsum) je from xishou  ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            strSql.Append(" group by SUBSTRING(xsckaddtime,0,11)  order by SUBSTRING(xsckaddtime,0,11) desc ");
            return DbHelperSQL.Query(strSql.ToString());
        }
        public DataSet GetListTJ4(int Top, string strWhere, string filedOrder)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select ");
            if (Top > 0)
            {
                strSql.Append(" top " + Top.ToString());
            }
            strSql.Append("  gdate rq,COUNT(case when gstatus='待处理' then 1 end) dcls,COUNT(case when gstatus='处理中' then 1 end) clzs,COUNT(case when gstatus='已处理' then 1 end) ycls from guzhang  ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            strSql.Append(" group by gdate  order by gdate desc ");
            return DbHelperSQL.Query(strSql.ToString());
        }

        /// <summary>
        /// 获取记录总数
        /// </summary>
        public int GetRecordCount(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) FROM jhdidan ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            object obj = DbHelperSQL.GetSingle(strSql.ToString());
            if (obj == null)
            {
                return 0;
            }
            else
            {
                return Convert.ToInt32(obj);
            }
        }
        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("SELECT * FROM ( ");
            strSql.Append(" SELECT ROW_NUMBER() OVER (");
            if (!string.IsNullOrEmpty(orderby.Trim()))
            {
                strSql.Append("order by T." + orderby);
            }
            else
            {
                strSql.Append("order by T.jid desc");
            }
            strSql.Append(")AS Row, T.*  from jhdidan T ");
            if (!string.IsNullOrEmpty(strWhere.Trim()))
            {
                strSql.Append(" WHERE " + strWhere);
            }
            strSql.Append(" ) TT");
            strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
            return DbHelperSQL.Query(strSql.ToString());
        }

        /*
        */

        #endregion  Method
        #region  MethodEx

        #endregion  MethodEx
    }
}

