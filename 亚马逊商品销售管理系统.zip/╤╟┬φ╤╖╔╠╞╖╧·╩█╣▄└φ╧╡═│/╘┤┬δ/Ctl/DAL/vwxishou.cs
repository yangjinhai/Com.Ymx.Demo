using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using Maticsoft.DBUtility;

namespace Ctl.DAL
{
	/// <summary>
	/// 数据访问类:vwxishou
	/// </summary>
	public partial class vwxishou
	{
		public vwxishou()
		{}
		#region  Method

		/// <summary>
		/// 得到最大ID
		/// </summary>
		public int GetMaxId()
		{
		    return DbHelperSQL.GetMaxID("xid", "vwxishou"); 
		}


		/// <summary>
		/// 是否存在该记录
		/// </summary>
		public bool Exists(int pkId)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) from vwxishou");
			strSql.Append(" where xid="+pkId+" ");
			return DbHelperSQL.Exists(strSql.ToString());
		}
        
        
		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Ctl.Model.vwxishou GetModel(int pkId)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select  top 1  ");
			strSql.Append(" xid,xno,xstime,xspid,xspnum,xspprice,xspsum,xsgykhid,xsuname,xsrek,xsadduid,xsadduname,xsaddtime,xsckzt,xsckadduid,xsckadduname,xsckaddtime,xsckrek,xscby,xscbyv,pid,pname,ptype,ptname,pmodel,pno,pnum,pkhid,pdesc,prek,paddtime,padduid,padduname,pby,pbyv,kid,kname,kuser,ktel,kaddress,kfax,kemail,kdesc,kaddtime,kadduid,kadduname,kstatus,ktype,krek,kby,kbyv,mkid,mkname,mkuser,mktel,mkaddress,mkfax,mkemail,mkdesc,mkaddtime,mkadduid,mkadduname,mkstatus,mktype,mkrek,mkby,mkbyv ");
			strSql.Append(" from vwxishou ");
			strSql.Append(" where xid="+pkId+"" );
			Ctl.Model.vwxishou model=new Ctl.Model.vwxishou();
			DataSet ds=DbHelperSQL.Query(strSql.ToString());
			if(ds.Tables[0].Rows.Count>0)
			{
				return DataRowToModel(ds.Tables[0].Rows[0]);
			}
			else
			{
				return null;
			}
		}

		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Ctl.Model.vwxishou DataRowToModel(DataRow row)
		{
			Ctl.Model.vwxishou model=new Ctl.Model.vwxishou();
			if (row != null)
			{
                if (row["xid"] != null && row["xid"].ToString() != "")
                {
                    model.xid = int.Parse(row["xid"].ToString());
                }
                if (row["xno"] != null)
                {
                    model.xno = row["xno"].ToString();
                }
                if (row["xstime"] != null)
                {
                    model.xstime = row["xstime"].ToString();
                }
                if (row["xspid"] != null && row["xspid"].ToString() != "")
                {
                    model.xspid = int.Parse(row["xspid"].ToString());
                }
                if (row["xspnum"] != null && row["xspnum"].ToString() != "")
                {
                    model.xspnum = int.Parse(row["xspnum"].ToString());
                }
                if (row["xspprice"] != null && row["xspprice"].ToString() != "")
                {
                    model.xspprice = int.Parse(row["xspprice"].ToString());
                }
                if (row["xspsum"] != null && row["xspsum"].ToString() != "")
                {
                    model.xspsum = int.Parse(row["xspsum"].ToString());
                }
                if (row["xsgykhid"] != null && row["xsgykhid"].ToString() != "")
                {
                    model.xsgykhid = int.Parse(row["xsgykhid"].ToString());
                }
                if (row["xsuname"] != null)
                {
                    model.xsuname = row["xsuname"].ToString();
                }
                if (row["xsrek"] != null)
                {
                    model.xsrek = row["xsrek"].ToString();
                }
                if (row["xsadduid"] != null && row["xsadduid"].ToString() != "")
                {
                    model.xsadduid = int.Parse(row["xsadduid"].ToString());
                }
                if (row["xsadduname"] != null)
                {
                    model.xsadduname = row["xsadduname"].ToString();
                }
                if (row["xsaddtime"] != null)
                {
                    model.xsaddtime = row["xsaddtime"].ToString();
                }
                if (row["xsckzt"] != null && row["xsckzt"].ToString() != "")
                {
                    model.xsckzt = int.Parse(row["xsckzt"].ToString());
                }
                if (row["xsckadduid"] != null && row["xsckadduid"].ToString() != "")
                {
                    model.xsckadduid = int.Parse(row["xsckadduid"].ToString());
                }
                if (row["xsckadduname"] != null)
                {
                    model.xsckadduname = row["xsckadduname"].ToString();
                }
                if (row["xsckaddtime"] != null)
                {
                    model.xsckaddtime = row["xsckaddtime"].ToString();
                }
                if (row["xsckrek"] != null)
                {
                    model.xsckrek = row["xsckrek"].ToString();
                }
                if (row["xscby"] != null)
                {
                    model.xscby = row["xscby"].ToString();
                }
                if (row["xscbyv"] != null && row["xscbyv"].ToString() != "")
                {
                    model.xscbyv = int.Parse(row["xscbyv"].ToString());
                }
                if (row["pid"] != null && row["pid"].ToString() != "")
                {
                    model.pid = int.Parse(row["pid"].ToString());
                }
                if (row["pname"] != null)
                {
                    model.pname = row["pname"].ToString();
                }
                if (row["ptype"] != null)
                {
                    model.ptype = row["ptype"].ToString();
                }
                if (row["ptname"] != null)
                {
                    model.ptname = row["ptname"].ToString();
                }
                if (row["pmodel"] != null)
                {
                    model.pmodel = row["pmodel"].ToString();
                }
                if (row["pno"] != null)
                {
                    model.pno = row["pno"].ToString();
                }
                if (row["pnum"] != null && row["pnum"].ToString() != "")
                {
                    model.pnum = int.Parse(row["pnum"].ToString());
                }
                if (row["pkhid"] != null && row["pkhid"].ToString() != "")
                {
                    model.pkhid = int.Parse(row["pkhid"].ToString());
                }
                if (row["pdesc"] != null)
                {
                    model.pdesc = row["pdesc"].ToString();
                }
                if (row["prek"] != null)
                {
                    model.prek = row["prek"].ToString();
                }
                if (row["paddtime"] != null)
                {
                    model.paddtime = row["paddtime"].ToString();
                }
                if (row["padduid"] != null && row["padduid"].ToString() != "")
                {
                    model.padduid = int.Parse(row["padduid"].ToString());
                }
                if (row["padduname"] != null)
                {
                    model.padduname = row["padduname"].ToString();
                }
                if (row["pby"] != null)
                {
                    model.pby = row["pby"].ToString();
                }
                if (row["pbyv"] != null && row["pbyv"].ToString() != "")
                {
                    model.pbyv = int.Parse(row["pbyv"].ToString());
                }
                if (row["kid"] != null && row["kid"].ToString() != "")
                {
                    model.kid = int.Parse(row["kid"].ToString());
                }
                if (row["kname"] != null)
                {
                    model.kname = row["kname"].ToString();
                }
                if (row["kuser"] != null)
                {
                    model.kuser = row["kuser"].ToString();
                }
                if (row["ktel"] != null)
                {
                    model.ktel = row["ktel"].ToString();
                }
                if (row["kaddress"] != null)
                {
                    model.kaddress = row["kaddress"].ToString();
                }
                if (row["kfax"] != null)
                {
                    model.kfax = row["kfax"].ToString();
                }
                if (row["kemail"] != null)
                {
                    model.kemail = row["kemail"].ToString();
                }
                if (row["kdesc"] != null)
                {
                    model.kdesc = row["kdesc"].ToString();
                }
                if (row["kaddtime"] != null)
                {
                    model.kaddtime = row["kaddtime"].ToString();
                }
                if (row["kadduid"] != null && row["kadduid"].ToString() != "")
                {
                    model.kadduid = int.Parse(row["kadduid"].ToString());
                }
                if (row["kadduname"] != null)
                {
                    model.kadduname = row["kadduname"].ToString();
                }
                if (row["kstatus"] != null && row["kstatus"].ToString() != "")
                {
                    model.kstatus = int.Parse(row["kstatus"].ToString());
                }
                if (row["ktype"] != null && row["ktype"].ToString() != "")
                {
                    model.ktype = int.Parse(row["ktype"].ToString());
                }
                if (row["krek"] != null)
                {
                    model.krek = row["krek"].ToString();
                }
                if (row["kby"] != null)
                {
                    model.kby = row["kby"].ToString();
                }
                if (row["kbyv"] != null && row["kbyv"].ToString() != "")
                {
                    model.kbyv = int.Parse(row["kbyv"].ToString());
                }
                if (row["mkid"] != null && row["mkid"].ToString() != "")
                {
                    model.mkid = int.Parse(row["mkid"].ToString());
                }
                if (row["mkname"] != null)
                {
                    model.mkname = row["mkname"].ToString();
                }
                if (row["mkuser"] != null)
                {
                    model.mkuser = row["mkuser"].ToString();
                }
                if (row["mktel"] != null)
                {
                    model.mktel = row["mktel"].ToString();
                }
                if (row["mkaddress"] != null)
                {
                    model.mkaddress = row["mkaddress"].ToString();
                }
                if (row["mkfax"] != null)
                {
                    model.mkfax = row["mkfax"].ToString();
                }
                if (row["mkemail"] != null)
                {
                    model.mkemail = row["mkemail"].ToString();
                }
                if (row["mkdesc"] != null)
                {
                    model.mkdesc = row["mkdesc"].ToString();
                }
                if (row["mkaddtime"] != null)
                {
                    model.mkaddtime = row["mkaddtime"].ToString();
                }
                if (row["mkadduid"] != null && row["mkadduid"].ToString() != "")
                {
                    model.mkadduid = int.Parse(row["mkadduid"].ToString());
                }
                if (row["mkadduname"] != null)
                {
                    model.mkadduname = row["mkadduname"].ToString();
                }
                if (row["mkstatus"] != null && row["mkstatus"].ToString() != "")
                {
                    model.mkstatus = int.Parse(row["mkstatus"].ToString());
                }
                if (row["mktype"] != null && row["mktype"].ToString() != "")
                {
                    model.mktype = int.Parse(row["mktype"].ToString());
                }
                if (row["mkrek"] != null)
                {
                    model.mkrek = row["mkrek"].ToString();
                }
                if (row["mkby"] != null)
                {
                    model.mkby = row["mkby"].ToString();
                }
                if (row["mkbyv"] != null && row["mkbyv"].ToString() != "")
                {
                    model.mkbyv = int.Parse(row["mkbyv"].ToString());
                }

			}
			return model;
		}

		/// <summary>
		/// 获得数据列表
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select xid,xno,xstime,xspid,xspnum,xspprice,xspsum,xsgykhid,xsuname,xsrek,xsadduid,xsadduname,xsaddtime,xsckzt,xsckadduid,xsckadduname,xsckaddtime,xsckrek,xscby,xscbyv,pid,pname,ptype,ptname,pmodel,pno,pnum,pkhid,pdesc,prek,paddtime,padduid,padduname,pby,pbyv,kid,kname,kuser,ktel,kaddress,kfax,kemail,kdesc,kaddtime,kadduid,kadduname,kstatus,ktype,krek,kby,kbyv,mkid,mkname,mkuser,mktel,mkaddress,mkfax,mkemail,mkdesc,mkaddtime,mkadduid,mkadduname,mkstatus,mktype,mkrek,mkby,mkbyv ");
			strSql.Append(" FROM vwxishou ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获得前几行数据
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select ");
			if(Top>0)
			{
				strSql.Append(" top "+Top.ToString());
			}
			strSql.Append(" xid,xno,xstime,xspid,xspnum,xspprice,xspsum,xsgykhid,xsuname,xsrek,xsadduid,xsadduname,xsaddtime,xsckzt,xsckadduid,xsckadduname,xsckaddtime,xsckrek,xscby,xscbyv,pid,pname,ptype,ptname,pmodel,pno,pnum,pkhid,pdesc,prek,paddtime,padduid,padduname,pby,pbyv,kid,kname,kuser,ktel,kaddress,kfax,kemail,kdesc,kaddtime,kadduid,kadduname,kstatus,ktype,krek,kby,kbyv,mkid,mkname,mkuser,mktel,mkaddress,mkfax,mkemail,mkdesc,mkaddtime,mkadduid,mkadduname,mkstatus,mktype,mkrek,mkby,mkbyv ");
			strSql.Append(" FROM vwxishou ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			strSql.Append(" order by " + filedOrder);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获取记录总数
		/// </summary>
		public int GetRecordCount(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) FROM vwxishou ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			object obj = DbHelperSQL.GetSingle(strSql.ToString());
			if (obj == null)
			{
				return 0;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("SELECT * FROM ( ");
			strSql.Append(" SELECT ROW_NUMBER() OVER (");
			if (!string.IsNullOrEmpty(orderby.Trim()))
			{
				strSql.Append("order by T." + orderby );
			}
			else
			{
				strSql.Append("order by T.xid desc");
			}
			strSql.Append(")AS Row, T.*  from vwxishou T ");
			if (!string.IsNullOrEmpty(strWhere.Trim()))
			{
				strSql.Append(" WHERE " + strWhere);
			}
			strSql.Append(" ) TT");
			strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/*
		*/

		#endregion  Method
		#region  MethodEx

		#endregion  MethodEx
	}
}

