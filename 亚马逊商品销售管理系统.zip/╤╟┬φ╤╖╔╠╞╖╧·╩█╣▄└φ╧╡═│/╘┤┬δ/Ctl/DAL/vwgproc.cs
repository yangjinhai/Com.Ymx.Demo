using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using Maticsoft.DBUtility;

namespace Ctl.DAL
{
	/// <summary>
	/// 数据访问类:vwgproc
	/// </summary>
	public partial class vwgproc
	{
		public vwgproc()
		{}
		#region  Method

		/// <summary>
		/// 得到最大ID
		/// </summary>
		public int GetMaxId()
		{
		    return DbHelperSQL.GetMaxID("pid", "vwgproc"); 
		}


		/// <summary>
		/// 是否存在该记录
		/// </summary>
		public bool Exists(int pkId)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) from vwgproc");
			strSql.Append(" where pid="+pkId+" ");
			return DbHelperSQL.Exists(strSql.ToString());
		}
        
        
		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Ctl.Model.vwgproc GetModel(int pkId)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select  top 1  ");
			strSql.Append(" pid,pname,ptype,ptname,pmodel,pno,pnum,pkhid,pdesc,prek,paddtime,padduid,padduname,pby,pbyv,kid,kname,kuser,ktel,kaddress,kfax,kemail,kdesc,kaddtime,kadduid,kadduname,kstatus,ktype,krek,kby,kbyv ");
			strSql.Append(" from vwgproc ");
			strSql.Append(" where pid="+pkId+"" );
			Ctl.Model.vwgproc model=new Ctl.Model.vwgproc();
			DataSet ds=DbHelperSQL.Query(strSql.ToString());
			if(ds.Tables[0].Rows.Count>0)
			{
				return DataRowToModel(ds.Tables[0].Rows[0]);
			}
			else
			{
				return null;
			}
		}

		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Ctl.Model.vwgproc DataRowToModel(DataRow row)
		{
			Ctl.Model.vwgproc model=new Ctl.Model.vwgproc();
			if (row != null)
			{
                if (row["pid"] != null && row["pid"].ToString() != "")
                {
                    model.pid = int.Parse(row["pid"].ToString());
                }
                if (row["pname"] != null)
                {
                    model.pname = row["pname"].ToString();
                }
                if (row["ptype"] != null)
                {
                    model.ptype = row["ptype"].ToString();
                }
                if (row["ptname"] != null)
                {
                    model.ptname = row["ptname"].ToString();
                }
                if (row["pmodel"] != null)
                {
                    model.pmodel = row["pmodel"].ToString();
                }
                if (row["pno"] != null)
                {
                    model.pno = row["pno"].ToString();
                }
                if (row["pnum"] != null && row["pnum"].ToString() != "")
                {
                    model.pnum = int.Parse(row["pnum"].ToString());
                }
                if (row["pkhid"] != null && row["pkhid"].ToString() != "")
                {
                    model.pkhid = int.Parse(row["pkhid"].ToString());
                }
                if (row["pdesc"] != null)
                {
                    model.pdesc = row["pdesc"].ToString();
                }
                if (row["prek"] != null)
                {
                    model.prek = row["prek"].ToString();
                }
                if (row["paddtime"] != null)
                {
                    model.paddtime = row["paddtime"].ToString();
                }
                if (row["padduid"] != null && row["padduid"].ToString() != "")
                {
                    model.padduid = int.Parse(row["padduid"].ToString());
                }
                if (row["padduname"] != null)
                {
                    model.padduname = row["padduname"].ToString();
                }
                if (row["pby"] != null)
                {
                    model.pby = row["pby"].ToString();
                }
                if (row["pbyv"] != null && row["pbyv"].ToString() != "")
                {
                    model.pbyv = int.Parse(row["pbyv"].ToString());
                }
                if (row["kid"] != null && row["kid"].ToString() != "")
                {
                    model.kid = int.Parse(row["kid"].ToString());
                }
                if (row["kname"] != null)
                {
                    model.kname = row["kname"].ToString();
                }
                if (row["kuser"] != null)
                {
                    model.kuser = row["kuser"].ToString();
                }
                if (row["ktel"] != null)
                {
                    model.ktel = row["ktel"].ToString();
                }
                if (row["kaddress"] != null)
                {
                    model.kaddress = row["kaddress"].ToString();
                }
                if (row["kfax"] != null)
                {
                    model.kfax = row["kfax"].ToString();
                }
                if (row["kemail"] != null)
                {
                    model.kemail = row["kemail"].ToString();
                }
                if (row["kdesc"] != null)
                {
                    model.kdesc = row["kdesc"].ToString();
                }
                if (row["kaddtime"] != null)
                {
                    model.kaddtime = row["kaddtime"].ToString();
                }
                if (row["kadduid"] != null && row["kadduid"].ToString() != "")
                {
                    model.kadduid = int.Parse(row["kadduid"].ToString());
                }
                if (row["kadduname"] != null)
                {
                    model.kadduname = row["kadduname"].ToString();
                }
                if (row["kstatus"] != null && row["kstatus"].ToString() != "")
                {
                    model.kstatus = int.Parse(row["kstatus"].ToString());
                }
                if (row["ktype"] != null && row["ktype"].ToString() != "")
                {
                    model.ktype = int.Parse(row["ktype"].ToString());
                }
                if (row["krek"] != null)
                {
                    model.krek = row["krek"].ToString();
                }
                if (row["kby"] != null)
                {
                    model.kby = row["kby"].ToString();
                }
                if (row["kbyv"] != null && row["kbyv"].ToString() != "")
                {
                    model.kbyv = int.Parse(row["kbyv"].ToString());
                }

			}
			return model;
		}

		/// <summary>
		/// 获得数据列表
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select pid,pname,ptype,ptname,pmodel,pno,pnum,pkhid,pdesc,prek,paddtime,padduid,padduname,pby,pbyv,kid,kname,kuser,ktel,kaddress,kfax,kemail,kdesc,kaddtime,kadduid,kadduname,kstatus,ktype,krek,kby,kbyv ");
			strSql.Append(" FROM vwgproc ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获得前几行数据
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select ");
			if(Top>0)
			{
				strSql.Append(" top "+Top.ToString());
			}
			strSql.Append(" pid,pname,ptype,ptname,pmodel,pno,pnum,pkhid,pdesc,prek,paddtime,padduid,padduname,pby,pbyv,kid,kname,kuser,ktel,kaddress,kfax,kemail,kdesc,kaddtime,kadduid,kadduname,kstatus,ktype,krek,kby,kbyv ");
			strSql.Append(" FROM vwgproc ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			strSql.Append(" order by " + filedOrder);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获取记录总数
		/// </summary>
		public int GetRecordCount(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) FROM vwgproc ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			object obj = DbHelperSQL.GetSingle(strSql.ToString());
			if (obj == null)
			{
				return 0;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("SELECT * FROM ( ");
			strSql.Append(" SELECT ROW_NUMBER() OVER (");
			if (!string.IsNullOrEmpty(orderby.Trim()))
			{
				strSql.Append("order by T." + orderby );
			}
			else
			{
				strSql.Append("order by T.pid desc");
			}
			strSql.Append(")AS Row, T.*  from vwgproc T ");
			if (!string.IsNullOrEmpty(strWhere.Trim()))
			{
				strSql.Append(" WHERE " + strWhere);
			}
			strSql.Append(" ) TT");
			strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/*
		*/

		#endregion  Method
		#region  MethodEx

		#endregion  MethodEx
	}
}

