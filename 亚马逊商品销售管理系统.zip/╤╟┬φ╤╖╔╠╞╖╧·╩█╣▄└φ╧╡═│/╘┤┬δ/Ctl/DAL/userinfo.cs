using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using Maticsoft.DBUtility;

namespace Ctl.DAL
{
	/// <summary>
	/// 数据访问类:userinfo
	/// </summary>
	public partial class userinfo
	{
		public userinfo()
		{}
		#region  Method

		/// <summary>
		/// 得到最大ID
		/// </summary>
		public int GetMaxId()
		{
		    return DbHelperSQL.GetMaxID("uid", "userinfo"); 
		}


		/// <summary>
		/// 是否存在该记录
		/// </summary>
		public bool Exists(int pkId)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) from userinfo");
			strSql.Append(" where uid="+pkId+" ");
			return DbHelperSQL.Exists(strSql.ToString());
		}
        
        
		/// <summary>
		/// 增加一条数据
		/// </summary>
		public int Add(Ctl.Model.userinfo model)
		{
			StringBuilder strSql=new StringBuilder();
			StringBuilder strSql1=new StringBuilder();
			StringBuilder strSql2=new StringBuilder();
                        if (model.ulog != null)
            {
                strSql1.Append("ulog,");
                strSql2.Append("'" + model.ulog + "',");
            }
            if (model.upwd != null)
            {
                strSql1.Append("upwd,");
                strSql2.Append("'" + model.upwd + "',");
            }
            if (model.uname != null)
            {
                strSql1.Append("uname,");
                strSql2.Append("'" + model.uname + "',");
            }
            if (model.usex != null)
            {
                strSql1.Append("usex,");
                strSql2.Append("'" + model.usex + "',");
            }
            if (model.udept != null)
            {
                strSql1.Append("udept,");
                strSql2.Append("'" + model.udept + "',");
            }
            if (model.upost != null)
            {
                strSql1.Append("upost,");
                strSql2.Append("'" + model.upost + "',");
            }
            if (model.uidentid != null)
            {
                strSql1.Append("uidentid,");
                strSql2.Append("'" + model.uidentid + "',");
            }
            if (model.utel != null)
            {
                strSql1.Append("utel,");
                strSql2.Append("'" + model.utel + "',");
            }
            if (model.uemail != null)
            {
                strSql1.Append("uemail,");
                strSql2.Append("'" + model.uemail + "',");
            }
            if (model.uaddress != null)
            {
                strSql1.Append("uaddress,");
                strSql2.Append("'" + model.uaddress + "',");
            }
            if (model.urole != null)
            {
                strSql1.Append("urole,");
                strSql2.Append("" + model.urole + ",");
            }
            if (model.uaddtime != null)
            {
                strSql1.Append("uaddtime,");
                strSql2.Append("'" + model.uaddtime + "',");
            }
            if (model.urek != null)
            {
                strSql1.Append("urek,");
                strSql2.Append("'" + model.urek + "',");
            }
            if (model.uby != null)
            {
                strSql1.Append("uby,");
                strSql2.Append("'" + model.uby + "',");
            }
            if (model.ubyv != null)
            {
                strSql1.Append("ubyv,");
                strSql2.Append("" + model.ubyv + ",");
            }

			strSql.Append("insert into userinfo(");
			strSql.Append(strSql1.ToString().Remove(strSql1.Length - 1));
			strSql.Append(")");
			strSql.Append(" values (");
			strSql.Append(strSql2.ToString().Remove(strSql2.Length - 1));
			strSql.Append(")");
			strSql.Append(";select @@IDENTITY");
			object obj = DbHelperSQL.GetSingle(strSql.ToString());
			if (obj == null)
			{
				return 0;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}

		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool Update(Ctl.Model.userinfo model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("update userinfo set ");
                        if (model.ulog != null)
            {
                strSql.Append("ulog='" + model.ulog + "',");
            }
            else
            {
                strSql.Append("ulog= null ,");
            }
            if (model.upwd != null)
            {
                strSql.Append("upwd='" + model.upwd + "',");
            }
            else
            {
                strSql.Append("upwd= null ,");
            }
            if (model.uname != null)
            {
                strSql.Append("uname='" + model.uname + "',");
            }
            else
            {
                strSql.Append("uname= null ,");
            }
            if (model.usex != null)
            {
                strSql.Append("usex='" + model.usex + "',");
            }
            else
            {
                strSql.Append("usex= null ,");
            }
            if (model.udept != null)
            {
                strSql.Append("udept='" + model.udept + "',");
            }
            else
            {
                strSql.Append("udept= null ,");
            }
            if (model.upost != null)
            {
                strSql.Append("upost='" + model.upost + "',");
            }
            else
            {
                strSql.Append("upost= null ,");
            }
            if (model.uidentid != null)
            {
                strSql.Append("uidentid='" + model.uidentid + "',");
            }
            else
            {
                strSql.Append("uidentid= null ,");
            }
            if (model.utel != null)
            {
                strSql.Append("utel='" + model.utel + "',");
            }
            else
            {
                strSql.Append("utel= null ,");
            }
            if (model.uemail != null)
            {
                strSql.Append("uemail='" + model.uemail + "',");
            }
            else
            {
                strSql.Append("uemail= null ,");
            }
            if (model.uaddress != null)
            {
                strSql.Append("uaddress='" + model.uaddress + "',");
            }
            else
            {
                strSql.Append("uaddress= null ,");
            }
            if (model.urole != null)
            {
                strSql.Append("urole=" + model.urole + ",");
            }
            else
            {
                strSql.Append("urole= null ,");
            }
            if (model.uaddtime != null)
            {
                strSql.Append("uaddtime='" + model.uaddtime + "',");
            }
            else
            {
                strSql.Append("uaddtime= null ,");
            }
            if (model.urek != null)
            {
                strSql.Append("urek='" + model.urek + "',");
            }
            else
            {
                strSql.Append("urek= null ,");
            }
            if (model.uby != null)
            {
                strSql.Append("uby='" + model.uby + "',");
            }
            else
            {
                strSql.Append("uby= null ,");
            }
            if (model.ubyv != null)
            {
                strSql.Append("ubyv=" + model.ubyv + ",");
            }
            else
            {
                strSql.Append("ubyv= null ,");
            }

			int n = strSql.ToString().LastIndexOf(",");
			strSql.Remove(n, 1);
			strSql.Append(" where uid="+ model.uid+"");
			int rowsAffected=DbHelperSQL.ExecuteSql(strSql.ToString());
			if (rowsAffected > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		/// <summary>
		/// 删除一条数据
		/// </summary>
		public bool Delete(int pkId)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from userinfo ");
			strSql.Append(" where uid="+pkId+"" );
			int rowsAffected=DbHelperSQL.ExecuteSql(strSql.ToString());
			if (rowsAffected > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}		
    
        /// <summary>
		/// 批量删除数据
		/// </summary>
		public bool DeleteList(string idlist )
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from userinfo ");
			strSql.Append(" where uid in ("+idlist + ")  ");
			int rows=DbHelperSQL.ExecuteSql(strSql.ToString());
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
        

		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Ctl.Model.userinfo GetModel(int pkId)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select  top 1  ");
			strSql.Append(" uid,ulog,upwd,uname,usex,udept,upost,uidentid,utel,uemail,uaddress,urole,uaddtime,urek,uby,ubyv ");
			strSql.Append(" from userinfo ");
			strSql.Append(" where uid="+pkId+"" );
			Ctl.Model.userinfo model=new Ctl.Model.userinfo();
			DataSet ds=DbHelperSQL.Query(strSql.ToString());
			if(ds.Tables[0].Rows.Count>0)
			{
				return DataRowToModel(ds.Tables[0].Rows[0]);
			}
			else
			{
				return null;
			}
		}

		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Ctl.Model.userinfo DataRowToModel(DataRow row)
		{
			Ctl.Model.userinfo model=new Ctl.Model.userinfo();
			if (row != null)
			{
                if (row["uid"] != null && row["uid"].ToString() != "")
                {
                    model.uid = int.Parse(row["uid"].ToString());
                }
                if (row["ulog"] != null)
                {
                    model.ulog = row["ulog"].ToString();
                }
                if (row["upwd"] != null)
                {
                    model.upwd = row["upwd"].ToString();
                }
                if (row["uname"] != null)
                {
                    model.uname = row["uname"].ToString();
                }
                if (row["usex"] != null)
                {
                    model.usex = row["usex"].ToString();
                }
                if (row["udept"] != null)
                {
                    model.udept = row["udept"].ToString();
                }
                if (row["upost"] != null)
                {
                    model.upost = row["upost"].ToString();
                }
                if (row["uidentid"] != null)
                {
                    model.uidentid = row["uidentid"].ToString();
                }
                if (row["utel"] != null)
                {
                    model.utel = row["utel"].ToString();
                }
                if (row["uemail"] != null)
                {
                    model.uemail = row["uemail"].ToString();
                }
                if (row["uaddress"] != null)
                {
                    model.uaddress = row["uaddress"].ToString();
                }
                if (row["urole"] != null && row["urole"].ToString() != "")
                {
                    model.urole = int.Parse(row["urole"].ToString());
                }
                if (row["uaddtime"] != null)
                {
                    model.uaddtime = row["uaddtime"].ToString();
                }
                if (row["urek"] != null)
                {
                    model.urek = row["urek"].ToString();
                }
                if (row["uby"] != null)
                {
                    model.uby = row["uby"].ToString();
                }
                if (row["ubyv"] != null && row["ubyv"].ToString() != "")
                {
                    model.ubyv = int.Parse(row["ubyv"].ToString());
                }

			}
			return model;
		}

		/// <summary>
		/// 获得数据列表
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select uid,ulog,upwd,uname,usex,udept,upost,uidentid,utel,uemail,uaddress,urole,uaddtime,urek,uby,ubyv ");
			strSql.Append(" FROM userinfo ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获得前几行数据
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select ");
			if(Top>0)
			{
				strSql.Append(" top "+Top.ToString());
			}
			strSql.Append(" uid,ulog,upwd,uname,usex,udept,upost,uidentid,utel,uemail,uaddress,urole,uaddtime,urek,uby,ubyv ");
			strSql.Append(" FROM userinfo ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			strSql.Append(" order by " + filedOrder);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获取记录总数
		/// </summary>
		public int GetRecordCount(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) FROM userinfo ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			object obj = DbHelperSQL.GetSingle(strSql.ToString());
			if (obj == null)
			{
				return 0;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("SELECT * FROM ( ");
			strSql.Append(" SELECT ROW_NUMBER() OVER (");
			if (!string.IsNullOrEmpty(orderby.Trim()))
			{
				strSql.Append("order by T." + orderby );
			}
			else
			{
				strSql.Append("order by T.uid desc");
			}
			strSql.Append(")AS Row, T.*  from userinfo T ");
			if (!string.IsNullOrEmpty(strWhere.Trim()))
			{
				strSql.Append(" WHERE " + strWhere);
			}
			strSql.Append(" ) TT");
			strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/*
		*/

		#endregion  Method
		#region  MethodEx

		#endregion  MethodEx
	}
}

