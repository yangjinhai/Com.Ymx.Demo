using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using Maticsoft.DBUtility;

namespace Ctl.DAL
{
	/// <summary>
	/// 数据访问类:gproc
	/// </summary>
	public partial class gproc
	{
		public gproc()
		{}
		#region  Method

		/// <summary>
		/// 得到最大ID
		/// </summary>
		public int GetMaxId()
		{
		    return DbHelperSQL.GetMaxID("pid", "gproc"); 
		}


		/// <summary>
		/// 是否存在该记录
		/// </summary>
		public bool Exists(int pkId)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) from gproc");
			strSql.Append(" where pid="+pkId+" ");
			return DbHelperSQL.Exists(strSql.ToString());
		}
        
        
		/// <summary>
		/// 增加一条数据
		/// </summary>
		public int Add(Ctl.Model.gproc model)
		{
			StringBuilder strSql=new StringBuilder();
			StringBuilder strSql1=new StringBuilder();
			StringBuilder strSql2=new StringBuilder();
                        if (model.pname != null)
            {
                strSql1.Append("pname,");
                strSql2.Append("'" + model.pname + "',");
            }
            if (model.ptype != null)
            {
                strSql1.Append("ptype,");
                strSql2.Append("'" + model.ptype + "',");
            }
            if (model.ptname != null)
            {
                strSql1.Append("ptname,");
                strSql2.Append("'" + model.ptname + "',");
            }
            if (model.pmodel != null)
            {
                strSql1.Append("pmodel,");
                strSql2.Append("'" + model.pmodel + "',");
            }
            if (model.pno != null)
            {
                strSql1.Append("pno,");
                strSql2.Append("'" + model.pno + "',");
            }
            if (model.pnum != null)
            {
                strSql1.Append("pnum,");
                strSql2.Append("" + model.pnum + ",");
            }
            if (model.pkhid != null)
            {
                strSql1.Append("pkhid,");
                strSql2.Append("" + model.pkhid + ",");
            }
            if (model.pdesc != null)
            {
                strSql1.Append("pdesc,");
                strSql2.Append("'" + model.pdesc + "',");
            }
            if (model.prek != null)
            {
                strSql1.Append("prek,");
                strSql2.Append("'" + model.prek + "',");
            }
            if (model.paddtime != null)
            {
                strSql1.Append("paddtime,");
                strSql2.Append("'" + model.paddtime + "',");
            }
            if (model.padduid != null)
            {
                strSql1.Append("padduid,");
                strSql2.Append("" + model.padduid + ",");
            }
            if (model.padduname != null)
            {
                strSql1.Append("padduname,");
                strSql2.Append("'" + model.padduname + "',");
            }
            if (model.pby != null)
            {
                strSql1.Append("pby,");
                strSql2.Append("'" + model.pby + "',");
            }
            if (model.pbyv != null)
            {
                strSql1.Append("pbyv,");
                strSql2.Append("" + model.pbyv + ",");
            }

			strSql.Append("insert into gproc(");
			strSql.Append(strSql1.ToString().Remove(strSql1.Length - 1));
			strSql.Append(")");
			strSql.Append(" values (");
			strSql.Append(strSql2.ToString().Remove(strSql2.Length - 1));
			strSql.Append(")");
			strSql.Append(";select @@IDENTITY");
			object obj = DbHelperSQL.GetSingle(strSql.ToString());
			if (obj == null)
			{
				return 0;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}

		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool Update(Ctl.Model.gproc model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("update gproc set ");
                        if (model.pname != null)
            {
                strSql.Append("pname='" + model.pname + "',");
            }
            else
            {
                strSql.Append("pname= null ,");
            }
            if (model.ptype != null)
            {
                strSql.Append("ptype='" + model.ptype + "',");
            }
            else
            {
                strSql.Append("ptype= null ,");
            }
            if (model.ptname != null)
            {
                strSql.Append("ptname='" + model.ptname + "',");
            }
            else
            {
                strSql.Append("ptname= null ,");
            }
            if (model.pmodel != null)
            {
                strSql.Append("pmodel='" + model.pmodel + "',");
            }
            else
            {
                strSql.Append("pmodel= null ,");
            }
            if (model.pno != null)
            {
                strSql.Append("pno='" + model.pno + "',");
            }
            else
            {
                strSql.Append("pno= null ,");
            }
            if (model.pnum != null)
            {
                strSql.Append("pnum=" + model.pnum + ",");
            }
            else
            {
                strSql.Append("pnum= null ,");
            }
            if (model.pkhid != null)
            {
                strSql.Append("pkhid=" + model.pkhid + ",");
            }
            else
            {
                strSql.Append("pkhid= null ,");
            }
            if (model.pdesc != null)
            {
                strSql.Append("pdesc='" + model.pdesc + "',");
            }
            else
            {
                strSql.Append("pdesc= null ,");
            }
            if (model.prek != null)
            {
                strSql.Append("prek='" + model.prek + "',");
            }
            else
            {
                strSql.Append("prek= null ,");
            }
            if (model.paddtime != null)
            {
                strSql.Append("paddtime='" + model.paddtime + "',");
            }
            else
            {
                strSql.Append("paddtime= null ,");
            }
            if (model.padduid != null)
            {
                strSql.Append("padduid=" + model.padduid + ",");
            }
            else
            {
                strSql.Append("padduid= null ,");
            }
            if (model.padduname != null)
            {
                strSql.Append("padduname='" + model.padduname + "',");
            }
            else
            {
                strSql.Append("padduname= null ,");
            }
            if (model.pby != null)
            {
                strSql.Append("pby='" + model.pby + "',");
            }
            else
            {
                strSql.Append("pby= null ,");
            }
            if (model.pbyv != null)
            {
                strSql.Append("pbyv=" + model.pbyv + ",");
            }
            else
            {
                strSql.Append("pbyv= null ,");
            }

			int n = strSql.ToString().LastIndexOf(",");
			strSql.Remove(n, 1);
			strSql.Append(" where pid="+ model.pid+"");
			int rowsAffected=DbHelperSQL.ExecuteSql(strSql.ToString());
			if (rowsAffected > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		/// <summary>
		/// 删除一条数据
		/// </summary>
		public bool Delete(int pkId)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from gproc ");
			strSql.Append(" where pid="+pkId+"" );
			int rowsAffected=DbHelperSQL.ExecuteSql(strSql.ToString());
			if (rowsAffected > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}		
    
        /// <summary>
		/// 批量删除数据
		/// </summary>
		public bool DeleteList(string idlist )
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from gproc ");
			strSql.Append(" where pid in ("+idlist + ")  ");
			int rows=DbHelperSQL.ExecuteSql(strSql.ToString());
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
        

		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Ctl.Model.gproc GetModel(int pkId)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select  top 1  ");
			strSql.Append(" pid,pname,ptype,ptname,pmodel,pno,pnum,pkhid,pdesc,prek,paddtime,padduid,padduname,pby,pbyv ");
			strSql.Append(" from gproc ");
			strSql.Append(" where pid="+pkId+"" );
			Ctl.Model.gproc model=new Ctl.Model.gproc();
			DataSet ds=DbHelperSQL.Query(strSql.ToString());
			if(ds.Tables[0].Rows.Count>0)
			{
				return DataRowToModel(ds.Tables[0].Rows[0]);
			}
			else
			{
				return null;
			}
		}

		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Ctl.Model.gproc DataRowToModel(DataRow row)
		{
			Ctl.Model.gproc model=new Ctl.Model.gproc();
			if (row != null)
			{
                if (row["pid"] != null && row["pid"].ToString() != "")
                {
                    model.pid = int.Parse(row["pid"].ToString());
                }
                if (row["pname"] != null)
                {
                    model.pname = row["pname"].ToString();
                }
                if (row["ptype"] != null)
                {
                    model.ptype = row["ptype"].ToString();
                }
                if (row["ptname"] != null)
                {
                    model.ptname = row["ptname"].ToString();
                }
                if (row["pmodel"] != null)
                {
                    model.pmodel = row["pmodel"].ToString();
                }
                if (row["pno"] != null)
                {
                    model.pno = row["pno"].ToString();
                }
                if (row["pnum"] != null && row["pnum"].ToString() != "")
                {
                    model.pnum = int.Parse(row["pnum"].ToString());
                }
                if (row["pkhid"] != null && row["pkhid"].ToString() != "")
                {
                    model.pkhid = int.Parse(row["pkhid"].ToString());
                }
                if (row["pdesc"] != null)
                {
                    model.pdesc = row["pdesc"].ToString();
                }
                if (row["prek"] != null)
                {
                    model.prek = row["prek"].ToString();
                }
                if (row["paddtime"] != null)
                {
                    model.paddtime = row["paddtime"].ToString();
                }
                if (row["padduid"] != null && row["padduid"].ToString() != "")
                {
                    model.padduid = int.Parse(row["padduid"].ToString());
                }
                if (row["padduname"] != null)
                {
                    model.padduname = row["padduname"].ToString();
                }
                if (row["pby"] != null)
                {
                    model.pby = row["pby"].ToString();
                }
                if (row["pbyv"] != null && row["pbyv"].ToString() != "")
                {
                    model.pbyv = int.Parse(row["pbyv"].ToString());
                }

			}
			return model;
		}

		/// <summary>
		/// 获得数据列表
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select pid,pname,ptype,ptname,pmodel,pno,pnum,pkhid,pdesc,prek,paddtime,padduid,padduname,pby,pbyv ");
			strSql.Append(" FROM gproc ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获得前几行数据
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select ");
			if(Top>0)
			{
				strSql.Append(" top "+Top.ToString());
			}
			strSql.Append(" pid,pname,ptype,ptname,pmodel,pno,pnum,pkhid,pdesc,prek,paddtime,padduid,padduname,pby,pbyv ");
			strSql.Append(" FROM gproc ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			strSql.Append(" order by " + filedOrder);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获取记录总数
		/// </summary>
		public int GetRecordCount(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) FROM gproc ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			object obj = DbHelperSQL.GetSingle(strSql.ToString());
			if (obj == null)
			{
				return 0;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("SELECT * FROM ( ");
			strSql.Append(" SELECT ROW_NUMBER() OVER (");
			if (!string.IsNullOrEmpty(orderby.Trim()))
			{
				strSql.Append("order by T." + orderby );
			}
			else
			{
				strSql.Append("order by T.pid desc");
			}
			strSql.Append(")AS Row, T.*  from gproc T ");
			if (!string.IsNullOrEmpty(strWhere.Trim()))
			{
				strSql.Append(" WHERE " + strWhere);
			}
			strSql.Append(" ) TT");
			strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/*
		*/

		#endregion  Method
		#region  MethodEx

		#endregion  MethodEx
	}
}

