using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using Maticsoft.DBUtility;

namespace Ctl.DAL
{
	/// <summary>
	/// 数据访问类:kehu
	/// </summary>
	public partial class kehu
	{
		public kehu()
		{}
		#region  Method

		/// <summary>
		/// 得到最大ID
		/// </summary>
		public int GetMaxId()
		{
		    return DbHelperSQL.GetMaxID("kid", "kehu"); 
		}


		/// <summary>
		/// 是否存在该记录
		/// </summary>
		public bool Exists(int pkId)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) from kehu");
			strSql.Append(" where kid="+pkId+" ");
			return DbHelperSQL.Exists(strSql.ToString());
		}
        
        
		/// <summary>
		/// 增加一条数据
		/// </summary>
		public int Add(Ctl.Model.kehu model)
		{
			StringBuilder strSql=new StringBuilder();
			StringBuilder strSql1=new StringBuilder();
			StringBuilder strSql2=new StringBuilder();
                        if (model.kname != null)
            {
                strSql1.Append("kname,");
                strSql2.Append("'" + model.kname + "',");
            }
            if (model.kuser != null)
            {
                strSql1.Append("kuser,");
                strSql2.Append("'" + model.kuser + "',");
            }
            if (model.ktel != null)
            {
                strSql1.Append("ktel,");
                strSql2.Append("'" + model.ktel + "',");
            }
            if (model.kaddress != null)
            {
                strSql1.Append("kaddress,");
                strSql2.Append("'" + model.kaddress + "',");
            }
            if (model.kfax != null)
            {
                strSql1.Append("kfax,");
                strSql2.Append("'" + model.kfax + "',");
            }
            if (model.kemail != null)
            {
                strSql1.Append("kemail,");
                strSql2.Append("'" + model.kemail + "',");
            }
            if (model.kdesc != null)
            {
                strSql1.Append("kdesc,");
                strSql2.Append("'" + model.kdesc + "',");
            }
            if (model.kaddtime != null)
            {
                strSql1.Append("kaddtime,");
                strSql2.Append("'" + model.kaddtime + "',");
            }
            if (model.kadduid != null)
            {
                strSql1.Append("kadduid,");
                strSql2.Append("" + model.kadduid + ",");
            }
            if (model.kadduname != null)
            {
                strSql1.Append("kadduname,");
                strSql2.Append("'" + model.kadduname + "',");
            }
            if (model.kstatus != null)
            {
                strSql1.Append("kstatus,");
                strSql2.Append("" + model.kstatus + ",");
            }
            if (model.ktype != null)
            {
                strSql1.Append("ktype,");
                strSql2.Append("" + model.ktype + ",");
            }
            if (model.krek != null)
            {
                strSql1.Append("krek,");
                strSql2.Append("'" + model.krek + "',");
            }
            if (model.kby != null)
            {
                strSql1.Append("kby,");
                strSql2.Append("'" + model.kby + "',");
            }
            if (model.kbyv != null)
            {
                strSql1.Append("kbyv,");
                strSql2.Append("" + model.kbyv + ",");
            }

			strSql.Append("insert into kehu(");
			strSql.Append(strSql1.ToString().Remove(strSql1.Length - 1));
			strSql.Append(")");
			strSql.Append(" values (");
			strSql.Append(strSql2.ToString().Remove(strSql2.Length - 1));
			strSql.Append(")");
			strSql.Append(";select @@IDENTITY");
			object obj = DbHelperSQL.GetSingle(strSql.ToString());
			if (obj == null)
			{
				return 0;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}

		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool Update(Ctl.Model.kehu model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("update kehu set ");
                        if (model.kname != null)
            {
                strSql.Append("kname='" + model.kname + "',");
            }
            else
            {
                strSql.Append("kname= null ,");
            }
            if (model.kuser != null)
            {
                strSql.Append("kuser='" + model.kuser + "',");
            }
            else
            {
                strSql.Append("kuser= null ,");
            }
            if (model.ktel != null)
            {
                strSql.Append("ktel='" + model.ktel + "',");
            }
            else
            {
                strSql.Append("ktel= null ,");
            }
            if (model.kaddress != null)
            {
                strSql.Append("kaddress='" + model.kaddress + "',");
            }
            else
            {
                strSql.Append("kaddress= null ,");
            }
            if (model.kfax != null)
            {
                strSql.Append("kfax='" + model.kfax + "',");
            }
            else
            {
                strSql.Append("kfax= null ,");
            }
            if (model.kemail != null)
            {
                strSql.Append("kemail='" + model.kemail + "',");
            }
            else
            {
                strSql.Append("kemail= null ,");
            }
            if (model.kdesc != null)
            {
                strSql.Append("kdesc='" + model.kdesc + "',");
            }
            else
            {
                strSql.Append("kdesc= null ,");
            }
            if (model.kaddtime != null)
            {
                strSql.Append("kaddtime='" + model.kaddtime + "',");
            }
            else
            {
                strSql.Append("kaddtime= null ,");
            }
            if (model.kadduid != null)
            {
                strSql.Append("kadduid=" + model.kadduid + ",");
            }
            else
            {
                strSql.Append("kadduid= null ,");
            }
            if (model.kadduname != null)
            {
                strSql.Append("kadduname='" + model.kadduname + "',");
            }
            else
            {
                strSql.Append("kadduname= null ,");
            }
            if (model.kstatus != null)
            {
                strSql.Append("kstatus=" + model.kstatus + ",");
            }
            else
            {
                strSql.Append("kstatus= null ,");
            }
            if (model.ktype != null)
            {
                strSql.Append("ktype=" + model.ktype + ",");
            }
            else
            {
                strSql.Append("ktype= null ,");
            }
            if (model.krek != null)
            {
                strSql.Append("krek='" + model.krek + "',");
            }
            else
            {
                strSql.Append("krek= null ,");
            }
            if (model.kby != null)
            {
                strSql.Append("kby='" + model.kby + "',");
            }
            else
            {
                strSql.Append("kby= null ,");
            }
            if (model.kbyv != null)
            {
                strSql.Append("kbyv=" + model.kbyv + ",");
            }
            else
            {
                strSql.Append("kbyv= null ,");
            }

			int n = strSql.ToString().LastIndexOf(",");
			strSql.Remove(n, 1);
			strSql.Append(" where kid="+ model.kid+"");
			int rowsAffected=DbHelperSQL.ExecuteSql(strSql.ToString());
			if (rowsAffected > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		/// <summary>
		/// 删除一条数据
		/// </summary>
		public bool Delete(int pkId)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from kehu ");
			strSql.Append(" where kid="+pkId+"" );
			int rowsAffected=DbHelperSQL.ExecuteSql(strSql.ToString());
			if (rowsAffected > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}		
    
        /// <summary>
		/// 批量删除数据
		/// </summary>
		public bool DeleteList(string idlist )
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from kehu ");
			strSql.Append(" where kid in ("+idlist + ")  ");
			int rows=DbHelperSQL.ExecuteSql(strSql.ToString());
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
        

		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Ctl.Model.kehu GetModel(int pkId)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select  top 1  ");
			strSql.Append(" kid,kname,kuser,ktel,kaddress,kfax,kemail,kdesc,kaddtime,kadduid,kadduname,kstatus,ktype,krek,kby,kbyv ");
			strSql.Append(" from kehu ");
			strSql.Append(" where kid="+pkId+"" );
			Ctl.Model.kehu model=new Ctl.Model.kehu();
			DataSet ds=DbHelperSQL.Query(strSql.ToString());
			if(ds.Tables[0].Rows.Count>0)
			{
				return DataRowToModel(ds.Tables[0].Rows[0]);
			}
			else
			{
				return null;
			}
		}

		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Ctl.Model.kehu DataRowToModel(DataRow row)
		{
			Ctl.Model.kehu model=new Ctl.Model.kehu();
			if (row != null)
			{
                if (row["kid"] != null && row["kid"].ToString() != "")
                {
                    model.kid = int.Parse(row["kid"].ToString());
                }
                if (row["kname"] != null)
                {
                    model.kname = row["kname"].ToString();
                }
                if (row["kuser"] != null)
                {
                    model.kuser = row["kuser"].ToString();
                }
                if (row["ktel"] != null)
                {
                    model.ktel = row["ktel"].ToString();
                }
                if (row["kaddress"] != null)
                {
                    model.kaddress = row["kaddress"].ToString();
                }
                if (row["kfax"] != null)
                {
                    model.kfax = row["kfax"].ToString();
                }
                if (row["kemail"] != null)
                {
                    model.kemail = row["kemail"].ToString();
                }
                if (row["kdesc"] != null)
                {
                    model.kdesc = row["kdesc"].ToString();
                }
                if (row["kaddtime"] != null)
                {
                    model.kaddtime = row["kaddtime"].ToString();
                }
                if (row["kadduid"] != null && row["kadduid"].ToString() != "")
                {
                    model.kadduid = int.Parse(row["kadduid"].ToString());
                }
                if (row["kadduname"] != null)
                {
                    model.kadduname = row["kadduname"].ToString();
                }
                if (row["kstatus"] != null && row["kstatus"].ToString() != "")
                {
                    model.kstatus = int.Parse(row["kstatus"].ToString());
                }
                if (row["ktype"] != null && row["ktype"].ToString() != "")
                {
                    model.ktype = int.Parse(row["ktype"].ToString());
                }
                if (row["krek"] != null)
                {
                    model.krek = row["krek"].ToString();
                }
                if (row["kby"] != null)
                {
                    model.kby = row["kby"].ToString();
                }
                if (row["kbyv"] != null && row["kbyv"].ToString() != "")
                {
                    model.kbyv = int.Parse(row["kbyv"].ToString());
                }

			}
			return model;
		}

		/// <summary>
		/// 获得数据列表
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select kid,kname,kuser,ktel,kaddress,kfax,kemail,kdesc,kaddtime,kadduid,kadduname,kstatus,ktype,krek,kby,kbyv ");
			strSql.Append(" FROM kehu ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获得前几行数据
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select ");
			if(Top>0)
			{
				strSql.Append(" top "+Top.ToString());
			}
			strSql.Append(" kid,kname,kuser,ktel,kaddress,kfax,kemail,kdesc,kaddtime,kadduid,kadduname,kstatus,ktype,krek,kby,kbyv ");
			strSql.Append(" FROM kehu ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			strSql.Append(" order by " + filedOrder);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获取记录总数
		/// </summary>
		public int GetRecordCount(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) FROM kehu ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			object obj = DbHelperSQL.GetSingle(strSql.ToString());
			if (obj == null)
			{
				return 0;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("SELECT * FROM ( ");
			strSql.Append(" SELECT ROW_NUMBER() OVER (");
			if (!string.IsNullOrEmpty(orderby.Trim()))
			{
				strSql.Append("order by T." + orderby );
			}
			else
			{
				strSql.Append("order by T.kid desc");
			}
			strSql.Append(")AS Row, T.*  from kehu T ");
			if (!string.IsNullOrEmpty(strWhere.Trim()))
			{
				strSql.Append(" WHERE " + strWhere);
			}
			strSql.Append(" ) TT");
			strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/*
		*/

		#endregion  Method
		#region  MethodEx

		#endregion  MethodEx
	}
}

