using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using Maticsoft.DBUtility;

namespace Ctl.DAL
{
	/// <summary>
	/// 数据访问类:guzhang
	/// </summary>
	public partial class guzhang
	{
		public guzhang()
		{}
		#region  Method

		/// <summary>
		/// 得到最大ID
		/// </summary>
		public int GetMaxId()
		{
		    return DbHelperSQL.GetMaxID("gid", "guzhang"); 
		}


		/// <summary>
		/// 是否存在该记录
		/// </summary>
		public bool Exists(int pkId)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) from guzhang");
			strSql.Append(" where gid="+pkId+" ");
			return DbHelperSQL.Exists(strSql.ToString());
		}
        
        
		/// <summary>
		/// 增加一条数据
		/// </summary>
		public int Add(Ctl.Model.guzhang model)
		{
			StringBuilder strSql=new StringBuilder();
			StringBuilder strSql1=new StringBuilder();
			StringBuilder strSql2=new StringBuilder();
                        if (model.goid != null)
            {
                strSql1.Append("goid,");
                strSql2.Append("" + model.goid + ",");
            }
            if (model.gtype != null)
            {
                strSql1.Append("gtype,");
                strSql2.Append("'" + model.gtype + "',");
            }
            if (model.gdesc != null)
            {
                strSql1.Append("gdesc,");
                strSql2.Append("'" + model.gdesc + "',");
            }
            if (model.gdate != null)
            {
                strSql1.Append("gdate,");
                strSql2.Append("'" + model.gdate + "',");
            }
            if (model.gclfun != null)
            {
                strSql1.Append("gclfun,");
                strSql2.Append("'" + model.gclfun + "',");
            }
            if (model.gstatus != null)
            {
                strSql1.Append("gstatus,");
                strSql2.Append("'" + model.gstatus + "',");
            }
            if (model.gadduid != null)
            {
                strSql1.Append("gadduid,");
                strSql2.Append("" + model.gadduid + ",");
            }
            if (model.gadduname != null)
            {
                strSql1.Append("gadduname,");
                strSql2.Append("'" + model.gadduname + "',");
            }
            if (model.gaddtime != null)
            {
                strSql1.Append("gaddtime,");
                strSql2.Append("'" + model.gaddtime + "',");
            }
            if (model.grek != null)
            {
                strSql1.Append("grek,");
                strSql2.Append("'" + model.grek + "',");
            }
            if (model.gby != null)
            {
                strSql1.Append("gby,");
                strSql2.Append("'" + model.gby + "',");
            }
            if (model.gbyv != null)
            {
                strSql1.Append("gbyv,");
                strSql2.Append("" + model.gbyv + ",");
            }

			strSql.Append("insert into guzhang(");
			strSql.Append(strSql1.ToString().Remove(strSql1.Length - 1));
			strSql.Append(")");
			strSql.Append(" values (");
			strSql.Append(strSql2.ToString().Remove(strSql2.Length - 1));
			strSql.Append(")");
			strSql.Append(";select @@IDENTITY");
			object obj = DbHelperSQL.GetSingle(strSql.ToString());
			if (obj == null)
			{
				return 0;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}

		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool Update(Ctl.Model.guzhang model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("update guzhang set ");
                        if (model.goid != null)
            {
                strSql.Append("goid=" + model.goid + ",");
            }
            else
            {
                strSql.Append("goid= null ,");
            }
            if (model.gtype != null)
            {
                strSql.Append("gtype='" + model.gtype + "',");
            }
            else
            {
                strSql.Append("gtype= null ,");
            }
            if (model.gdesc != null)
            {
                strSql.Append("gdesc='" + model.gdesc + "',");
            }
            else
            {
                strSql.Append("gdesc= null ,");
            }
            if (model.gdate != null)
            {
                strSql.Append("gdate='" + model.gdate + "',");
            }
            else
            {
                strSql.Append("gdate= null ,");
            }
            if (model.gclfun != null)
            {
                strSql.Append("gclfun='" + model.gclfun + "',");
            }
            else
            {
                strSql.Append("gclfun= null ,");
            }
            if (model.gstatus != null)
            {
                strSql.Append("gstatus='" + model.gstatus + "',");
            }
            else
            {
                strSql.Append("gstatus= null ,");
            }
            if (model.gadduid != null)
            {
                strSql.Append("gadduid=" + model.gadduid + ",");
            }
            else
            {
                strSql.Append("gadduid= null ,");
            }
            if (model.gadduname != null)
            {
                strSql.Append("gadduname='" + model.gadduname + "',");
            }
            else
            {
                strSql.Append("gadduname= null ,");
            }
            if (model.gaddtime != null)
            {
                strSql.Append("gaddtime='" + model.gaddtime + "',");
            }
            else
            {
                strSql.Append("gaddtime= null ,");
            }
            if (model.grek != null)
            {
                strSql.Append("grek='" + model.grek + "',");
            }
            else
            {
                strSql.Append("grek= null ,");
            }
            if (model.gby != null)
            {
                strSql.Append("gby='" + model.gby + "',");
            }
            else
            {
                strSql.Append("gby= null ,");
            }
            if (model.gbyv != null)
            {
                strSql.Append("gbyv=" + model.gbyv + ",");
            }
            else
            {
                strSql.Append("gbyv= null ,");
            }

			int n = strSql.ToString().LastIndexOf(",");
			strSql.Remove(n, 1);
			strSql.Append(" where gid="+ model.gid+"");
			int rowsAffected=DbHelperSQL.ExecuteSql(strSql.ToString());
			if (rowsAffected > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		/// <summary>
		/// 删除一条数据
		/// </summary>
		public bool Delete(int pkId)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from guzhang ");
			strSql.Append(" where gid="+pkId+"" );
			int rowsAffected=DbHelperSQL.ExecuteSql(strSql.ToString());
			if (rowsAffected > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}		
    
        /// <summary>
		/// 批量删除数据
		/// </summary>
		public bool DeleteList(string idlist )
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from guzhang ");
			strSql.Append(" where gid in ("+idlist + ")  ");
			int rows=DbHelperSQL.ExecuteSql(strSql.ToString());
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
        

		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Ctl.Model.guzhang GetModel(int pkId)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select  top 1  ");
			strSql.Append(" gid,goid,gtype,gdesc,gdate,gclfun,gstatus,gadduid,gadduname,gaddtime,grek,gby,gbyv ");
			strSql.Append(" from guzhang ");
			strSql.Append(" where gid="+pkId+"" );
			Ctl.Model.guzhang model=new Ctl.Model.guzhang();
			DataSet ds=DbHelperSQL.Query(strSql.ToString());
			if(ds.Tables[0].Rows.Count>0)
			{
				return DataRowToModel(ds.Tables[0].Rows[0]);
			}
			else
			{
				return null;
			}
		}

		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Ctl.Model.guzhang DataRowToModel(DataRow row)
		{
			Ctl.Model.guzhang model=new Ctl.Model.guzhang();
			if (row != null)
			{
                if (row["gid"] != null && row["gid"].ToString() != "")
                {
                    model.gid = int.Parse(row["gid"].ToString());
                }
                if (row["goid"] != null && row["goid"].ToString() != "")
                {
                    model.goid = int.Parse(row["goid"].ToString());
                }
                if (row["gtype"] != null)
                {
                    model.gtype = row["gtype"].ToString();
                }
                if (row["gdesc"] != null)
                {
                    model.gdesc = row["gdesc"].ToString();
                }
                if (row["gdate"] != null)
                {
                    model.gdate = row["gdate"].ToString();
                }
                if (row["gclfun"] != null)
                {
                    model.gclfun = row["gclfun"].ToString();
                }
                if (row["gstatus"] != null)
                {
                    model.gstatus = row["gstatus"].ToString();
                }
                if (row["gadduid"] != null && row["gadduid"].ToString() != "")
                {
                    model.gadduid = int.Parse(row["gadduid"].ToString());
                }
                if (row["gadduname"] != null)
                {
                    model.gadduname = row["gadduname"].ToString();
                }
                if (row["gaddtime"] != null)
                {
                    model.gaddtime = row["gaddtime"].ToString();
                }
                if (row["grek"] != null)
                {
                    model.grek = row["grek"].ToString();
                }
                if (row["gby"] != null)
                {
                    model.gby = row["gby"].ToString();
                }
                if (row["gbyv"] != null && row["gbyv"].ToString() != "")
                {
                    model.gbyv = int.Parse(row["gbyv"].ToString());
                }

			}
			return model;
		}

		/// <summary>
		/// 获得数据列表
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select gid,goid,gtype,gdesc,gdate,gclfun,gstatus,gadduid,gadduname,gaddtime,grek,gby,gbyv ");
			strSql.Append(" FROM guzhang ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获得前几行数据
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select ");
			if(Top>0)
			{
				strSql.Append(" top "+Top.ToString());
			}
			strSql.Append(" gid,goid,gtype,gdesc,gdate,gclfun,gstatus,gadduid,gadduname,gaddtime,grek,gby,gbyv ");
			strSql.Append(" FROM guzhang ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			strSql.Append(" order by " + filedOrder);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获取记录总数
		/// </summary>
		public int GetRecordCount(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) FROM guzhang ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			object obj = DbHelperSQL.GetSingle(strSql.ToString());
			if (obj == null)
			{
				return 0;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("SELECT * FROM ( ");
			strSql.Append(" SELECT ROW_NUMBER() OVER (");
			if (!string.IsNullOrEmpty(orderby.Trim()))
			{
				strSql.Append("order by T." + orderby );
			}
			else
			{
				strSql.Append("order by T.gid desc");
			}
			strSql.Append(")AS Row, T.*  from guzhang T ");
			if (!string.IsNullOrEmpty(strWhere.Trim()))
			{
				strSql.Append(" WHERE " + strWhere);
			}
			strSql.Append(" ) TT");
			strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/*
		*/

		#endregion  Method
		#region  MethodEx

		#endregion  MethodEx
	}
}

