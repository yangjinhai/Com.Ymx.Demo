using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using Maticsoft.DBUtility;

namespace Ctl.DAL
{
	/// <summary>
	/// 数据访问类:xishou
	/// </summary>
	public partial class xishou
	{
		public xishou()
		{}
		#region  Method

		/// <summary>
		/// 得到最大ID
		/// </summary>
		public int GetMaxId()
		{
		    return DbHelperSQL.GetMaxID("xid", "xishou"); 
		}


		/// <summary>
		/// 是否存在该记录
		/// </summary>
		public bool Exists(int pkId)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) from xishou");
			strSql.Append(" where xid="+pkId+" ");
			return DbHelperSQL.Exists(strSql.ToString());
		}
        
        
		/// <summary>
		/// 增加一条数据
		/// </summary>
		public int Add(Ctl.Model.xishou model)
		{
			StringBuilder strSql=new StringBuilder();
			StringBuilder strSql1=new StringBuilder();
			StringBuilder strSql2=new StringBuilder();
                        if (model.xno != null)
            {
                strSql1.Append("xno,");
                strSql2.Append("'" + model.xno + "',");
            }
            if (model.xstime != null)
            {
                strSql1.Append("xstime,");
                strSql2.Append("'" + model.xstime + "',");
            }
            if (model.xspid != null)
            {
                strSql1.Append("xspid,");
                strSql2.Append("" + model.xspid + ",");
            }
            if (model.xspnum != null)
            {
                strSql1.Append("xspnum,");
                strSql2.Append("" + model.xspnum + ",");
            }
            if (model.xspprice != null)
            {
                strSql1.Append("xspprice,");
                strSql2.Append("" + model.xspprice + ",");
            }
            if (model.xspsum != null)
            {
                strSql1.Append("xspsum,");
                strSql2.Append("" + model.xspsum + ",");
            }
            if (model.xsgykhid != null)
            {
                strSql1.Append("xsgykhid,");
                strSql2.Append("" + model.xsgykhid + ",");
            }
            if (model.xsuname != null)
            {
                strSql1.Append("xsuname,");
                strSql2.Append("'" + model.xsuname + "',");
            }
            if (model.xsrek != null)
            {
                strSql1.Append("xsrek,");
                strSql2.Append("'" + model.xsrek + "',");
            }
            if (model.xsadduid != null)
            {
                strSql1.Append("xsadduid,");
                strSql2.Append("" + model.xsadduid + ",");
            }
            if (model.xsadduname != null)
            {
                strSql1.Append("xsadduname,");
                strSql2.Append("'" + model.xsadduname + "',");
            }
            if (model.xsaddtime != null)
            {
                strSql1.Append("xsaddtime,");
                strSql2.Append("'" + model.xsaddtime + "',");
            }
            if (model.xsckzt != null)
            {
                strSql1.Append("xsckzt,");
                strSql2.Append("" + model.xsckzt + ",");
            }
            if (model.xsckadduid != null)
            {
                strSql1.Append("xsckadduid,");
                strSql2.Append("" + model.xsckadduid + ",");
            }
            if (model.xsckadduname != null)
            {
                strSql1.Append("xsckadduname,");
                strSql2.Append("'" + model.xsckadduname + "',");
            }
            if (model.xsckaddtime != null)
            {
                strSql1.Append("xsckaddtime,");
                strSql2.Append("'" + model.xsckaddtime + "',");
            }
            if (model.xsckrek != null)
            {
                strSql1.Append("xsckrek,");
                strSql2.Append("'" + model.xsckrek + "',");
            }
            if (model.xscby != null)
            {
                strSql1.Append("xscby,");
                strSql2.Append("'" + model.xscby + "',");
            }
            if (model.xscbyv != null)
            {
                strSql1.Append("xscbyv,");
                strSql2.Append("" + model.xscbyv + ",");
            }

			strSql.Append("insert into xishou(");
			strSql.Append(strSql1.ToString().Remove(strSql1.Length - 1));
			strSql.Append(")");
			strSql.Append(" values (");
			strSql.Append(strSql2.ToString().Remove(strSql2.Length - 1));
			strSql.Append(")");
			strSql.Append(";select @@IDENTITY");
			object obj = DbHelperSQL.GetSingle(strSql.ToString());
			if (obj == null)
			{
				return 0;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}

		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool Update(Ctl.Model.xishou model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("update xishou set ");
                        if (model.xno != null)
            {
                strSql.Append("xno='" + model.xno + "',");
            }
            else
            {
                strSql.Append("xno= null ,");
            }
            if (model.xstime != null)
            {
                strSql.Append("xstime='" + model.xstime + "',");
            }
            else
            {
                strSql.Append("xstime= null ,");
            }
            if (model.xspid != null)
            {
                strSql.Append("xspid=" + model.xspid + ",");
            }
            else
            {
                strSql.Append("xspid= null ,");
            }
            if (model.xspnum != null)
            {
                strSql.Append("xspnum=" + model.xspnum + ",");
            }
            else
            {
                strSql.Append("xspnum= null ,");
            }
            if (model.xspprice != null)
            {
                strSql.Append("xspprice=" + model.xspprice + ",");
            }
            else
            {
                strSql.Append("xspprice= null ,");
            }
            if (model.xspsum != null)
            {
                strSql.Append("xspsum=" + model.xspsum + ",");
            }
            else
            {
                strSql.Append("xspsum= null ,");
            }
            if (model.xsgykhid != null)
            {
                strSql.Append("xsgykhid=" + model.xsgykhid + ",");
            }
            else
            {
                strSql.Append("xsgykhid= null ,");
            }
            if (model.xsuname != null)
            {
                strSql.Append("xsuname='" + model.xsuname + "',");
            }
            else
            {
                strSql.Append("xsuname= null ,");
            }
            if (model.xsrek != null)
            {
                strSql.Append("xsrek='" + model.xsrek + "',");
            }
            else
            {
                strSql.Append("xsrek= null ,");
            }
            if (model.xsadduid != null)
            {
                strSql.Append("xsadduid=" + model.xsadduid + ",");
            }
            else
            {
                strSql.Append("xsadduid= null ,");
            }
            if (model.xsadduname != null)
            {
                strSql.Append("xsadduname='" + model.xsadduname + "',");
            }
            else
            {
                strSql.Append("xsadduname= null ,");
            }
            if (model.xsaddtime != null)
            {
                strSql.Append("xsaddtime='" + model.xsaddtime + "',");
            }
            else
            {
                strSql.Append("xsaddtime= null ,");
            }
            if (model.xsckzt != null)
            {
                strSql.Append("xsckzt=" + model.xsckzt + ",");
            }
            else
            {
                strSql.Append("xsckzt= null ,");
            }
            if (model.xsckadduid != null)
            {
                strSql.Append("xsckadduid=" + model.xsckadduid + ",");
            }
            else
            {
                strSql.Append("xsckadduid= null ,");
            }
            if (model.xsckadduname != null)
            {
                strSql.Append("xsckadduname='" + model.xsckadduname + "',");
            }
            else
            {
                strSql.Append("xsckadduname= null ,");
            }
            if (model.xsckaddtime != null)
            {
                strSql.Append("xsckaddtime='" + model.xsckaddtime + "',");
            }
            else
            {
                strSql.Append("xsckaddtime= null ,");
            }
            if (model.xsckrek != null)
            {
                strSql.Append("xsckrek='" + model.xsckrek + "',");
            }
            else
            {
                strSql.Append("xsckrek= null ,");
            }
            if (model.xscby != null)
            {
                strSql.Append("xscby='" + model.xscby + "',");
            }
            else
            {
                strSql.Append("xscby= null ,");
            }
            if (model.xscbyv != null)
            {
                strSql.Append("xscbyv=" + model.xscbyv + ",");
            }
            else
            {
                strSql.Append("xscbyv= null ,");
            }

			int n = strSql.ToString().LastIndexOf(",");
			strSql.Remove(n, 1);
			strSql.Append(" where xid="+ model.xid+"");
			int rowsAffected=DbHelperSQL.ExecuteSql(strSql.ToString());
			if (rowsAffected > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		/// <summary>
		/// 删除一条数据
		/// </summary>
		public bool Delete(int pkId)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from xishou ");
			strSql.Append(" where xid="+pkId+"" );
			int rowsAffected=DbHelperSQL.ExecuteSql(strSql.ToString());
			if (rowsAffected > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}		
    
        /// <summary>
		/// 批量删除数据
		/// </summary>
		public bool DeleteList(string idlist )
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from xishou ");
			strSql.Append(" where xid in ("+idlist + ")  ");
			int rows=DbHelperSQL.ExecuteSql(strSql.ToString());
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
        

		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Ctl.Model.xishou GetModel(int pkId)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select  top 1  ");
			strSql.Append(" xid,xno,xstime,xspid,xspnum,xspprice,xspsum,xsgykhid,xsuname,xsrek,xsadduid,xsadduname,xsaddtime,xsckzt,xsckadduid,xsckadduname,xsckaddtime,xsckrek,xscby,xscbyv ");
			strSql.Append(" from xishou ");
			strSql.Append(" where xid="+pkId+"" );
			Ctl.Model.xishou model=new Ctl.Model.xishou();
			DataSet ds=DbHelperSQL.Query(strSql.ToString());
			if(ds.Tables[0].Rows.Count>0)
			{
				return DataRowToModel(ds.Tables[0].Rows[0]);
			}
			else
			{
				return null;
			}
		}

		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Ctl.Model.xishou DataRowToModel(DataRow row)
		{
			Ctl.Model.xishou model=new Ctl.Model.xishou();
			if (row != null)
			{
                if (row["xid"] != null && row["xid"].ToString() != "")
                {
                    model.xid = int.Parse(row["xid"].ToString());
                }
                if (row["xno"] != null)
                {
                    model.xno = row["xno"].ToString();
                }
                if (row["xstime"] != null)
                {
                    model.xstime = row["xstime"].ToString();
                }
                if (row["xspid"] != null && row["xspid"].ToString() != "")
                {
                    model.xspid = int.Parse(row["xspid"].ToString());
                }
                if (row["xspnum"] != null && row["xspnum"].ToString() != "")
                {
                    model.xspnum = int.Parse(row["xspnum"].ToString());
                }
                if (row["xspprice"] != null && row["xspprice"].ToString() != "")
                {
                    model.xspprice = int.Parse(row["xspprice"].ToString());
                }
                if (row["xspsum"] != null && row["xspsum"].ToString() != "")
                {
                    model.xspsum = int.Parse(row["xspsum"].ToString());
                }
                if (row["xsgykhid"] != null && row["xsgykhid"].ToString() != "")
                {
                    model.xsgykhid = int.Parse(row["xsgykhid"].ToString());
                }
                if (row["xsuname"] != null)
                {
                    model.xsuname = row["xsuname"].ToString();
                }
                if (row["xsrek"] != null)
                {
                    model.xsrek = row["xsrek"].ToString();
                }
                if (row["xsadduid"] != null && row["xsadduid"].ToString() != "")
                {
                    model.xsadduid = int.Parse(row["xsadduid"].ToString());
                }
                if (row["xsadduname"] != null)
                {
                    model.xsadduname = row["xsadduname"].ToString();
                }
                if (row["xsaddtime"] != null)
                {
                    model.xsaddtime = row["xsaddtime"].ToString();
                }
                if (row["xsckzt"] != null && row["xsckzt"].ToString() != "")
                {
                    model.xsckzt = int.Parse(row["xsckzt"].ToString());
                }
                if (row["xsckadduid"] != null && row["xsckadduid"].ToString() != "")
                {
                    model.xsckadduid = int.Parse(row["xsckadduid"].ToString());
                }
                if (row["xsckadduname"] != null)
                {
                    model.xsckadduname = row["xsckadduname"].ToString();
                }
                if (row["xsckaddtime"] != null)
                {
                    model.xsckaddtime = row["xsckaddtime"].ToString();
                }
                if (row["xsckrek"] != null)
                {
                    model.xsckrek = row["xsckrek"].ToString();
                }
                if (row["xscby"] != null)
                {
                    model.xscby = row["xscby"].ToString();
                }
                if (row["xscbyv"] != null && row["xscbyv"].ToString() != "")
                {
                    model.xscbyv = int.Parse(row["xscbyv"].ToString());
                }

			}
			return model;
		}

		/// <summary>
		/// 获得数据列表
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select xid,xno,xstime,xspid,xspnum,xspprice,xspsum,xsgykhid,xsuname,xsrek,xsadduid,xsadduname,xsaddtime,xsckzt,xsckadduid,xsckadduname,xsckaddtime,xsckrek,xscby,xscbyv ");
			strSql.Append(" FROM xishou ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获得前几行数据
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select ");
			if(Top>0)
			{
				strSql.Append(" top "+Top.ToString());
			}
			strSql.Append(" xid,xno,xstime,xspid,xspnum,xspprice,xspsum,xsgykhid,xsuname,xsrek,xsadduid,xsadduname,xsaddtime,xsckzt,xsckadduid,xsckadduname,xsckaddtime,xsckrek,xscby,xscbyv ");
			strSql.Append(" FROM xishou ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			strSql.Append(" order by " + filedOrder);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获取记录总数
		/// </summary>
		public int GetRecordCount(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) FROM xishou ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			object obj = DbHelperSQL.GetSingle(strSql.ToString());
			if (obj == null)
			{
				return 0;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("SELECT * FROM ( ");
			strSql.Append(" SELECT ROW_NUMBER() OVER (");
			if (!string.IsNullOrEmpty(orderby.Trim()))
			{
				strSql.Append("order by T." + orderby );
			}
			else
			{
				strSql.Append("order by T.xid desc");
			}
			strSql.Append(")AS Row, T.*  from xishou T ");
			if (!string.IsNullOrEmpty(strWhere.Trim()))
			{
				strSql.Append(" WHERE " + strWhere);
			}
			strSql.Append(" ) TT");
			strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/*
		*/

		#endregion  Method
		#region  MethodEx

		#endregion  MethodEx
	}
}

