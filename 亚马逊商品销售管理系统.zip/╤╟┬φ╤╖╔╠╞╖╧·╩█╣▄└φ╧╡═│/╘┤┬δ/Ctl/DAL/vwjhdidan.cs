using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using Maticsoft.DBUtility;

namespace Ctl.DAL
{
	/// <summary>
	/// 数据访问类:vwjhdidan
	/// </summary>
	public partial class vwjhdidan
	{
		public vwjhdidan()
		{}
		#region  Method

		/// <summary>
		/// 得到最大ID
		/// </summary>
		public int GetMaxId()
		{
		    return DbHelperSQL.GetMaxID("jid", "vwjhdidan"); 
		}


		/// <summary>
		/// 是否存在该记录
		/// </summary>
		public bool Exists(int pkId)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) from vwjhdidan");
			strSql.Append(" where jid="+pkId+" ");
			return DbHelperSQL.Exists(strSql.ToString());
		}
        
        
		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Ctl.Model.vwjhdidan GetModel(int pkId)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select  top 1  ");
			strSql.Append(" jid,jno,jctime,jspname,jsptype,jsptname,jspmodel,jspno,jspnum,jspprice,jspsum,jgykhid,jcguname,jcgrek,jcadduid,jcadduname,jcaddtime,jckzt,jckadduid,jckadduname,jckaddtime,jckrek,jcby,jcbyv,kid,kname,kuser,ktel,kaddress,kfax,kemail,kdesc,kaddtime,kadduid,kadduname,kstatus,ktype,krek,kby,kbyv ");
			strSql.Append(" from vwjhdidan ");
			strSql.Append(" where jid="+pkId+"" );
			Ctl.Model.vwjhdidan model=new Ctl.Model.vwjhdidan();
			DataSet ds=DbHelperSQL.Query(strSql.ToString());
			if(ds.Tables[0].Rows.Count>0)
			{
				return DataRowToModel(ds.Tables[0].Rows[0]);
			}
			else
			{
				return null;
			}
		}

		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Ctl.Model.vwjhdidan DataRowToModel(DataRow row)
		{
			Ctl.Model.vwjhdidan model=new Ctl.Model.vwjhdidan();
			if (row != null)
			{
                if (row["jid"] != null && row["jid"].ToString() != "")
                {
                    model.jid = int.Parse(row["jid"].ToString());
                }
                if (row["jno"] != null)
                {
                    model.jno = row["jno"].ToString();
                }
                if (row["jctime"] != null)
                {
                    model.jctime = row["jctime"].ToString();
                }
                if (row["jspname"] != null)
                {
                    model.jspname = row["jspname"].ToString();
                }
                if (row["jsptype"] != null)
                {
                    model.jsptype = row["jsptype"].ToString();
                }
                if (row["jsptname"] != null)
                {
                    model.jsptname = row["jsptname"].ToString();
                }
                if (row["jspmodel"] != null)
                {
                    model.jspmodel = row["jspmodel"].ToString();
                }
                if (row["jspno"] != null)
                {
                    model.jspno = row["jspno"].ToString();
                }
                if (row["jspnum"] != null && row["jspnum"].ToString() != "")
                {
                    model.jspnum = int.Parse(row["jspnum"].ToString());
                }
                if (row["jspprice"] != null && row["jspprice"].ToString() != "")
                {
                    model.jspprice = int.Parse(row["jspprice"].ToString());
                }
                if (row["jspsum"] != null && row["jspsum"].ToString() != "")
                {
                    model.jspsum = int.Parse(row["jspsum"].ToString());
                }
                if (row["jgykhid"] != null && row["jgykhid"].ToString() != "")
                {
                    model.jgykhid = int.Parse(row["jgykhid"].ToString());
                }
                if (row["jcguname"] != null)
                {
                    model.jcguname = row["jcguname"].ToString();
                }
                if (row["jcgrek"] != null)
                {
                    model.jcgrek = row["jcgrek"].ToString();
                }
                if (row["jcadduid"] != null && row["jcadduid"].ToString() != "")
                {
                    model.jcadduid = int.Parse(row["jcadduid"].ToString());
                }
                if (row["jcadduname"] != null)
                {
                    model.jcadduname = row["jcadduname"].ToString();
                }
                if (row["jcaddtime"] != null)
                {
                    model.jcaddtime = row["jcaddtime"].ToString();
                }
                if (row["jckzt"] != null && row["jckzt"].ToString() != "")
                {
                    model.jckzt = int.Parse(row["jckzt"].ToString());
                }
                if (row["jckadduid"] != null && row["jckadduid"].ToString() != "")
                {
                    model.jckadduid = int.Parse(row["jckadduid"].ToString());
                }
                if (row["jckadduname"] != null)
                {
                    model.jckadduname = row["jckadduname"].ToString();
                }
                if (row["jckaddtime"] != null)
                {
                    model.jckaddtime = row["jckaddtime"].ToString();
                }
                if (row["jckrek"] != null)
                {
                    model.jckrek = row["jckrek"].ToString();
                }
                if (row["jcby"] != null)
                {
                    model.jcby = row["jcby"].ToString();
                }
                if (row["jcbyv"] != null && row["jcbyv"].ToString() != "")
                {
                    model.jcbyv = int.Parse(row["jcbyv"].ToString());
                }
                if (row["kid"] != null && row["kid"].ToString() != "")
                {
                    model.kid = int.Parse(row["kid"].ToString());
                }
                if (row["kname"] != null)
                {
                    model.kname = row["kname"].ToString();
                }
                if (row["kuser"] != null)
                {
                    model.kuser = row["kuser"].ToString();
                }
                if (row["ktel"] != null)
                {
                    model.ktel = row["ktel"].ToString();
                }
                if (row["kaddress"] != null)
                {
                    model.kaddress = row["kaddress"].ToString();
                }
                if (row["kfax"] != null)
                {
                    model.kfax = row["kfax"].ToString();
                }
                if (row["kemail"] != null)
                {
                    model.kemail = row["kemail"].ToString();
                }
                if (row["kdesc"] != null)
                {
                    model.kdesc = row["kdesc"].ToString();
                }
                if (row["kaddtime"] != null)
                {
                    model.kaddtime = row["kaddtime"].ToString();
                }
                if (row["kadduid"] != null && row["kadduid"].ToString() != "")
                {
                    model.kadduid = int.Parse(row["kadduid"].ToString());
                }
                if (row["kadduname"] != null)
                {
                    model.kadduname = row["kadduname"].ToString();
                }
                if (row["kstatus"] != null && row["kstatus"].ToString() != "")
                {
                    model.kstatus = int.Parse(row["kstatus"].ToString());
                }
                if (row["ktype"] != null && row["ktype"].ToString() != "")
                {
                    model.ktype = int.Parse(row["ktype"].ToString());
                }
                if (row["krek"] != null)
                {
                    model.krek = row["krek"].ToString();
                }
                if (row["kby"] != null)
                {
                    model.kby = row["kby"].ToString();
                }
                if (row["kbyv"] != null && row["kbyv"].ToString() != "")
                {
                    model.kbyv = int.Parse(row["kbyv"].ToString());
                }

			}
			return model;
		}

		/// <summary>
		/// 获得数据列表
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select jid,jno,jctime,jspname,jsptype,jsptname,jspmodel,jspno,jspnum,jspprice,jspsum,jgykhid,jcguname,jcgrek,jcadduid,jcadduname,jcaddtime,jckzt,jckadduid,jckadduname,jckaddtime,jckrek,jcby,jcbyv,kid,kname,kuser,ktel,kaddress,kfax,kemail,kdesc,kaddtime,kadduid,kadduname,kstatus,ktype,krek,kby,kbyv ");
			strSql.Append(" FROM vwjhdidan ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获得前几行数据
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select ");
			if(Top>0)
			{
				strSql.Append(" top "+Top.ToString());
			}
			strSql.Append(" jid,jno,jctime,jspname,jsptype,jsptname,jspmodel,jspno,jspnum,jspprice,jspsum,jgykhid,jcguname,jcgrek,jcadduid,jcadduname,jcaddtime,jckzt,jckadduid,jckadduname,jckaddtime,jckrek,jcby,jcbyv,kid,kname,kuser,ktel,kaddress,kfax,kemail,kdesc,kaddtime,kadduid,kadduname,kstatus,ktype,krek,kby,kbyv ");
			strSql.Append(" FROM vwjhdidan ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			strSql.Append(" order by " + filedOrder);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获取记录总数
		/// </summary>
		public int GetRecordCount(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) FROM vwjhdidan ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			object obj = DbHelperSQL.GetSingle(strSql.ToString());
			if (obj == null)
			{
				return 0;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("SELECT * FROM ( ");
			strSql.Append(" SELECT ROW_NUMBER() OVER (");
			if (!string.IsNullOrEmpty(orderby.Trim()))
			{
				strSql.Append("order by T." + orderby );
			}
			else
			{
				strSql.Append("order by T.jid desc");
			}
			strSql.Append(")AS Row, T.*  from vwjhdidan T ");
			if (!string.IsNullOrEmpty(strWhere.Trim()))
			{
				strSql.Append(" WHERE " + strWhere);
			}
			strSql.Append(" ) TT");
			strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/*
		*/

		#endregion  Method
		#region  MethodEx

		#endregion  MethodEx
	}
}

