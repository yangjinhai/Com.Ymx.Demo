using System;

namespace Ctl.Model
{
	/// <summary>
	/// xishou:实体类
	/// </summary>
	[Serializable]
	public partial class xishou
	{
		public xishou()
		{}
		#region Model
        private int _xid;
        private string _xno;
        private string _xstime;
        private int _xspid;
        private int _xspnum;
        private int _xspprice;
        private int _xspsum;
        private int _xsgykhid;
        private string _xsuname;
        private string _xsrek;
        private int _xsadduid;
        private string _xsadduname;
        private string _xsaddtime;
        private int _xsckzt;
        private int _xsckadduid;
        private string _xsckadduname;
        private string _xsckaddtime;
        private string _xsckrek;
        private string _xscby;
        private int _xscbyv;


        /// <summary>
        /// ID
        /// </summary>
        public int xid
        {
            set{ _xid=value;}
            get{return _xid;}
        }
        
        /// <summary>
        /// 销售单号
        /// </summary>
        public string xno
        {
            set{ _xno=value;}
            get{return _xno;}
        }
        
        /// <summary>
        /// 销售时间
        /// </summary>
        public string xstime
        {
            set{ _xstime=value;}
            get{return _xstime;}
        }
        
        /// <summary>
        /// 商品ID
        /// </summary>
        public int xspid
        {
            set{ _xspid=value;}
            get{return _xspid;}
        }
        
        /// <summary>
        /// 销售数量
        /// </summary>
        public int xspnum
        {
            set{ _xspnum=value;}
            get{return _xspnum;}
        }
        
        /// <summary>
        /// 销售单价
        /// </summary>
        public int xspprice
        {
            set{ _xspprice=value;}
            get{return _xspprice;}
        }
        
        /// <summary>
        /// 本单总额
        /// </summary>
        public int xspsum
        {
            set{ _xspsum=value;}
            get{return _xspsum;}
        }
        
        /// <summary>
        /// 买家客户ID
        /// </summary>
        public int xsgykhid
        {
            set{ _xsgykhid=value;}
            get{return _xsgykhid;}
        }
        
        /// <summary>
        /// 销售人员
        /// </summary>
        public string xsuname
        {
            set{ _xsuname=value;}
            get{return _xsuname;}
        }
        
        /// <summary>
        /// 订单备注
        /// </summary>
        public string xsrek
        {
            set{ _xsrek=value;}
            get{return _xsrek;}
        }
        
        /// <summary>
        /// 登记人员
        /// </summary>
        public int xsadduid
        {
            set{ _xsadduid=value;}
            get{return _xsadduid;}
        }
        
        /// <summary>
        /// 登记人员
        /// </summary>
        public string xsadduname
        {
            set{ _xsadduname=value;}
            get{return _xsadduname;}
        }
        
        /// <summary>
        /// 登记时间
        /// </summary>
        public string xsaddtime
        {
            set{ _xsaddtime=value;}
            get{return _xsaddtime;}
        }
        
        /// <summary>
        /// 状态(1:待审/2:不予通过/3:审核通过)
        /// </summary>
        public int xsckzt
        {
            set{ _xsckzt=value;}
            get{return _xsckzt;}
        }
        
        /// <summary>
        /// 审核人员
        /// </summary>
        public int xsckadduid
        {
            set{ _xsckadduid=value;}
            get{return _xsckadduid;}
        }
        
        /// <summary>
        /// 审核人员
        /// </summary>
        public string xsckadduname
        {
            set{ _xsckadduname=value;}
            get{return _xsckadduname;}
        }
        
        /// <summary>
        /// 审核时间
        /// </summary>
        public string xsckaddtime
        {
            set{ _xsckaddtime=value;}
            get{return _xsckaddtime;}
        }
        
        /// <summary>
        /// 备注
        /// </summary>
        public string xsckrek
        {
            set{ _xsckrek=value;}
            get{return _xsckrek;}
        }
        
        /// <summary>
        /// 备用
        /// </summary>
        public string xscby
        {
            set{ _xscby=value;}
            get{return _xscby;}
        }
        
        /// <summary>
        /// 备用值
        /// </summary>
        public int xscbyv
        {
            set{ _xscbyv=value;}
            get{return _xscbyv;}
        }
        


		#endregion Model

	}
}

