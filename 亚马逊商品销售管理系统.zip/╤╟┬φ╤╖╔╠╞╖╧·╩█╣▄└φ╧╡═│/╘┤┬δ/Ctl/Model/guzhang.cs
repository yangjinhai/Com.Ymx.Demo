using System;

namespace Ctl.Model
{
	/// <summary>
	/// guzhang:实体类
	/// </summary>
	[Serializable]
	public partial class guzhang
	{
		public guzhang()
		{}
		#region Model
        private int _gid;
        private int _goid;
        private string _gtype;
        private string _gdesc;
        private string _gdate;
        private string _gclfun;
        private string _gstatus;
        private int _gadduid;
        private string _gadduname;
        private string _gaddtime;
        private string _grek;
        private string _gby;
        private int _gbyv;


        /// <summary>
        /// ID
        /// </summary>
        public int gid
        {
            set{ _gid=value;}
            get{return _gid;}
        }
        
        /// <summary>
        /// 销售订单ID
        /// </summary>
        public int goid
        {
            set{ _goid=value;}
            get{return _goid;}
        }
        
        /// <summary>
        /// 故障类型
        /// </summary>
        public string gtype
        {
            set{ _gtype=value;}
            get{return _gtype;}
        }
        
        /// <summary>
        /// 故障说明
        /// </summary>
        public string gdesc
        {
            set{ _gdesc=value;}
            get{return _gdesc;}
        }
        
        /// <summary>
        /// 处理日期
        /// </summary>
        public string gdate
        {
            set{ _gdate=value;}
            get{return _gdate;}
        }
        
        /// <summary>
        /// 处理办法
        /// </summary>
        public string gclfun
        {
            set{ _gclfun=value;}
            get{return _gclfun;}
        }
        
        /// <summary>
        /// 处理状态(处理中/已处理)
        /// </summary>
        public string gstatus
        {
            set{ _gstatus=value;}
            get{return _gstatus;}
        }
        
        /// <summary>
        /// 登记人员
        /// </summary>
        public int gadduid
        {
            set{ _gadduid=value;}
            get{return _gadduid;}
        }
        
        /// <summary>
        /// 登记人员
        /// </summary>
        public string gadduname
        {
            set{ _gadduname=value;}
            get{return _gadduname;}
        }
        
        /// <summary>
        /// 登记时间
        /// </summary>
        public string gaddtime
        {
            set{ _gaddtime=value;}
            get{return _gaddtime;}
        }
        
        /// <summary>
        /// 备注
        /// </summary>
        public string grek
        {
            set{ _grek=value;}
            get{return _grek;}
        }
        
        /// <summary>
        /// 备用
        /// </summary>
        public string gby
        {
            set{ _gby=value;}
            get{return _gby;}
        }
        
        /// <summary>
        /// 备用值
        /// </summary>
        public int gbyv
        {
            set{ _gbyv=value;}
            get{return _gbyv;}
        }
        


		#endregion Model

	}
}

