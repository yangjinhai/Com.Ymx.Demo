using System;

namespace Ctl.Model
{
	/// <summary>
	/// vwxishou:实体类
	/// </summary>
	[Serializable]
	public partial class vwxishou
	{
		public vwxishou()
		{}
		#region Model
        private int _xid;
        private string _xno;
        private string _xstime;
        private int _xspid;
        private int _xspnum;
        private int _xspprice;
        private int _xspsum;
        private int _xsgykhid;
        private string _xsuname;
        private string _xsrek;
        private int _xsadduid;
        private string _xsadduname;
        private string _xsaddtime;
        private int _xsckzt;
        private int _xsckadduid;
        private string _xsckadduname;
        private string _xsckaddtime;
        private string _xsckrek;
        private string _xscby;
        private int _xscbyv;
        private int _pid;
        private string _pname;
        private string _ptype;
        private string _ptname;
        private string _pmodel;
        private string _pno;
        private int _pnum;
        private int _pkhid;
        private string _pdesc;
        private string _prek;
        private string _paddtime;
        private int _padduid;
        private string _padduname;
        private string _pby;
        private int _pbyv;
        private int _kid;
        private string _kname;
        private string _kuser;
        private string _ktel;
        private string _kaddress;
        private string _kfax;
        private string _kemail;
        private string _kdesc;
        private string _kaddtime;
        private int _kadduid;
        private string _kadduname;
        private int _kstatus;
        private int _ktype;
        private string _krek;
        private string _kby;
        private int _kbyv;
        private int _mkid;
        private string _mkname;
        private string _mkuser;
        private string _mktel;
        private string _mkaddress;
        private string _mkfax;
        private string _mkemail;
        private string _mkdesc;
        private string _mkaddtime;
        private int _mkadduid;
        private string _mkadduname;
        private int _mkstatus;
        private int _mktype;
        private string _mkrek;
        private string _mkby;
        private int _mkbyv;


        /// <summary>
        /// -
        /// </summary>
        public int xid
        {
            set{ _xid=value;}
            get{return _xid;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string xno
        {
            set{ _xno=value;}
            get{return _xno;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string xstime
        {
            set{ _xstime=value;}
            get{return _xstime;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int xspid
        {
            set{ _xspid=value;}
            get{return _xspid;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int xspnum
        {
            set{ _xspnum=value;}
            get{return _xspnum;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int xspprice
        {
            set{ _xspprice=value;}
            get{return _xspprice;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int xspsum
        {
            set{ _xspsum=value;}
            get{return _xspsum;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int xsgykhid
        {
            set{ _xsgykhid=value;}
            get{return _xsgykhid;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string xsuname
        {
            set{ _xsuname=value;}
            get{return _xsuname;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string xsrek
        {
            set{ _xsrek=value;}
            get{return _xsrek;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int xsadduid
        {
            set{ _xsadduid=value;}
            get{return _xsadduid;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string xsadduname
        {
            set{ _xsadduname=value;}
            get{return _xsadduname;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string xsaddtime
        {
            set{ _xsaddtime=value;}
            get{return _xsaddtime;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int xsckzt
        {
            set{ _xsckzt=value;}
            get{return _xsckzt;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int xsckadduid
        {
            set{ _xsckadduid=value;}
            get{return _xsckadduid;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string xsckadduname
        {
            set{ _xsckadduname=value;}
            get{return _xsckadduname;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string xsckaddtime
        {
            set{ _xsckaddtime=value;}
            get{return _xsckaddtime;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string xsckrek
        {
            set{ _xsckrek=value;}
            get{return _xsckrek;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string xscby
        {
            set{ _xscby=value;}
            get{return _xscby;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int xscbyv
        {
            set{ _xscbyv=value;}
            get{return _xscbyv;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int pid
        {
            set{ _pid=value;}
            get{return _pid;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string pname
        {
            set{ _pname=value;}
            get{return _pname;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string ptype
        {
            set{ _ptype=value;}
            get{return _ptype;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string ptname
        {
            set{ _ptname=value;}
            get{return _ptname;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string pmodel
        {
            set{ _pmodel=value;}
            get{return _pmodel;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string pno
        {
            set{ _pno=value;}
            get{return _pno;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int pnum
        {
            set{ _pnum=value;}
            get{return _pnum;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int pkhid
        {
            set{ _pkhid=value;}
            get{return _pkhid;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string pdesc
        {
            set{ _pdesc=value;}
            get{return _pdesc;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string prek
        {
            set{ _prek=value;}
            get{return _prek;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string paddtime
        {
            set{ _paddtime=value;}
            get{return _paddtime;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int padduid
        {
            set{ _padduid=value;}
            get{return _padduid;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string padduname
        {
            set{ _padduname=value;}
            get{return _padduname;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string pby
        {
            set{ _pby=value;}
            get{return _pby;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int pbyv
        {
            set{ _pbyv=value;}
            get{return _pbyv;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int kid
        {
            set{ _kid=value;}
            get{return _kid;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string kname
        {
            set{ _kname=value;}
            get{return _kname;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string kuser
        {
            set{ _kuser=value;}
            get{return _kuser;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string ktel
        {
            set{ _ktel=value;}
            get{return _ktel;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string kaddress
        {
            set{ _kaddress=value;}
            get{return _kaddress;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string kfax
        {
            set{ _kfax=value;}
            get{return _kfax;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string kemail
        {
            set{ _kemail=value;}
            get{return _kemail;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string kdesc
        {
            set{ _kdesc=value;}
            get{return _kdesc;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string kaddtime
        {
            set{ _kaddtime=value;}
            get{return _kaddtime;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int kadduid
        {
            set{ _kadduid=value;}
            get{return _kadduid;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string kadduname
        {
            set{ _kadduname=value;}
            get{return _kadduname;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int kstatus
        {
            set{ _kstatus=value;}
            get{return _kstatus;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int ktype
        {
            set{ _ktype=value;}
            get{return _ktype;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string krek
        {
            set{ _krek=value;}
            get{return _krek;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string kby
        {
            set{ _kby=value;}
            get{return _kby;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int kbyv
        {
            set{ _kbyv=value;}
            get{return _kbyv;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int mkid
        {
            set{ _mkid=value;}
            get{return _mkid;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string mkname
        {
            set{ _mkname=value;}
            get{return _mkname;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string mkuser
        {
            set{ _mkuser=value;}
            get{return _mkuser;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string mktel
        {
            set{ _mktel=value;}
            get{return _mktel;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string mkaddress
        {
            set{ _mkaddress=value;}
            get{return _mkaddress;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string mkfax
        {
            set{ _mkfax=value;}
            get{return _mkfax;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string mkemail
        {
            set{ _mkemail=value;}
            get{return _mkemail;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string mkdesc
        {
            set{ _mkdesc=value;}
            get{return _mkdesc;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string mkaddtime
        {
            set{ _mkaddtime=value;}
            get{return _mkaddtime;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int mkadduid
        {
            set{ _mkadduid=value;}
            get{return _mkadduid;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string mkadduname
        {
            set{ _mkadduname=value;}
            get{return _mkadduname;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int mkstatus
        {
            set{ _mkstatus=value;}
            get{return _mkstatus;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int mktype
        {
            set{ _mktype=value;}
            get{return _mktype;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string mkrek
        {
            set{ _mkrek=value;}
            get{return _mkrek;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string mkby
        {
            set{ _mkby=value;}
            get{return _mkby;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int mkbyv
        {
            set{ _mkbyv=value;}
            get{return _mkbyv;}
        }
        


		#endregion Model

	}
}

