using System;

namespace Ctl.Model
{
	/// <summary>
	/// kehu:实体类
	/// </summary>
	[Serializable]
	public partial class kehu
	{
		public kehu()
		{}
		#region Model
        private int _kid;
        private string _kname;
        private string _kuser;
        private string _ktel;
        private string _kaddress;
        private string _kfax;
        private string _kemail;
        private string _kdesc;
        private string _kaddtime;
        private int _kadduid;
        private string _kadduname;
        private int _kstatus;
        private int _ktype;
        private string _krek;
        private string _kby;
        private int _kbyv;


        /// <summary>
        /// ID
        /// </summary>
        public int kid
        {
            set{ _kid=value;}
            get{return _kid;}
        }
        
        /// <summary>
        /// 客户名称
        /// </summary>
        public string kname
        {
            set{ _kname=value;}
            get{return _kname;}
        }
        
        /// <summary>
        /// 联系人
        /// </summary>
        public string kuser
        {
            set{ _kuser=value;}
            get{return _kuser;}
        }
        
        /// <summary>
        /// 联系电话
        /// </summary>
        public string ktel
        {
            set{ _ktel=value;}
            get{return _ktel;}
        }
        
        /// <summary>
        /// 联系地址
        /// </summary>
        public string kaddress
        {
            set{ _kaddress=value;}
            get{return _kaddress;}
        }
        
        /// <summary>
        /// 传真
        /// </summary>
        public string kfax
        {
            set{ _kfax=value;}
            get{return _kfax;}
        }
        
        /// <summary>
        /// 邮箱
        /// </summary>
        public string kemail
        {
            set{ _kemail=value;}
            get{return _kemail;}
        }
        
        /// <summary>
        /// 简介
        /// </summary>
        public string kdesc
        {
            set{ _kdesc=value;}
            get{return _kdesc;}
        }
        
        /// <summary>
        /// 创建时间
        /// </summary>
        public string kaddtime
        {
            set{ _kaddtime=value;}
            get{return _kaddtime;}
        }
        
        /// <summary>
        /// 创建人
        /// </summary>
        public int kadduid
        {
            set{ _kadduid=value;}
            get{return _kadduid;}
        }
        
        /// <summary>
        /// 创建人
        /// </summary>
        public string kadduname
        {
            set{ _kadduname=value;}
            get{return _kadduname;}
        }
        
        /// <summary>
        /// 状态
        /// </summary>
        public int kstatus
        {
            set{ _kstatus=value;}
            get{return _kstatus;}
        }
        
        /// <summary>
        /// 类型(1:供应商/2:买家)
        /// </summary>
        public int ktype
        {
            set{ _ktype=value;}
            get{return _ktype;}
        }
        
        /// <summary>
        /// 备注
        /// </summary>
        public string krek
        {
            set{ _krek=value;}
            get{return _krek;}
        }
        
        /// <summary>
        /// 备用
        /// </summary>
        public string kby
        {
            set{ _kby=value;}
            get{return _kby;}
        }
        
        /// <summary>
        /// 备用值
        /// </summary>
        public int kbyv
        {
            set{ _kbyv=value;}
            get{return _kbyv;}
        }
        


		#endregion Model

	}
}

