using System;

namespace Ctl.Model
{
	/// <summary>
	/// userinfo:实体类
	/// </summary>
	[Serializable]
	public partial class userinfo
	{
		public userinfo()
		{}
		#region Model
        private int _uid;
        private string _ulog;
        private string _upwd;
        private string _uname;
        private string _usex;
        private string _udept;
        private string _upost;
        private string _uidentid;
        private string _utel;
        private string _uemail;
        private string _uaddress;
        private int _urole;
        private string _uaddtime;
        private string _urek;
        private string _uby;
        private int _ubyv;


        /// <summary>
        /// ID
        /// </summary>
        public int uid
        {
            set{ _uid=value;}
            get{return _uid;}
        }
        
        /// <summary>
        /// 工号
        /// </summary>
        public string ulog
        {
            set{ _ulog=value;}
            get{return _ulog;}
        }
        
        /// <summary>
        /// 密码
        /// </summary>
        public string upwd
        {
            set{ _upwd=value;}
            get{return _upwd;}
        }
        
        /// <summary>
        /// 姓名
        /// </summary>
        public string uname
        {
            set{ _uname=value;}
            get{return _uname;}
        }
        
        /// <summary>
        /// 性别
        /// </summary>
        public string usex
        {
            set{ _usex=value;}
            get{return _usex;}
        }
        
        /// <summary>
        /// 部门
        /// </summary>
        public string udept
        {
            set{ _udept=value;}
            get{return _udept;}
        }
        
        /// <summary>
        /// 职务
        /// </summary>
        public string upost
        {
            set{ _upost=value;}
            get{return _upost;}
        }
        
        /// <summary>
        /// 身份证号
        /// </summary>
        public string uidentid
        {
            set{ _uidentid=value;}
            get{return _uidentid;}
        }
        
        /// <summary>
        /// 联系电话
        /// </summary>
        public string utel
        {
            set{ _utel=value;}
            get{return _utel;}
        }
        
        /// <summary>
        /// 电子邮箱
        /// </summary>
        public string uemail
        {
            set{ _uemail=value;}
            get{return _uemail;}
        }
        
        /// <summary>
        /// 居住地址
        /// </summary>
        public string uaddress
        {
            set{ _uaddress=value;}
            get{return _uaddress;}
        }
        
        /// <summary>
        /// 角色(1:采购员/2:库管员/3:销售员/9:管理员)
        /// </summary>
        public int urole
        {
            set{ _urole=value;}
            get{return _urole;}
        }
        
        /// <summary>
        /// 注册时间
        /// </summary>
        public string uaddtime
        {
            set{ _uaddtime=value;}
            get{return _uaddtime;}
        }
        
        /// <summary>
        /// 备注
        /// </summary>
        public string urek
        {
            set{ _urek=value;}
            get{return _urek;}
        }
        
        /// <summary>
        /// 备用
        /// </summary>
        public string uby
        {
            set{ _uby=value;}
            get{return _uby;}
        }
        
        /// <summary>
        /// 备用值
        /// </summary>
        public int ubyv
        {
            set{ _ubyv=value;}
            get{return _ubyv;}
        }
        


		#endregion Model

	}
}

