using System;

namespace Ctl.Model
{
	/// <summary>
	/// vwjhdidan:实体类
	/// </summary>
	[Serializable]
	public partial class vwjhdidan
	{
		public vwjhdidan()
		{}
		#region Model
        private int _jid;
        private string _jno;
        private string _jctime;
        private string _jspname;
        private string _jsptype;
        private string _jsptname;
        private string _jspmodel;
        private string _jspno;
        private int _jspnum;
        private int _jspprice;
        private int _jspsum;
        private int _jgykhid;
        private string _jcguname;
        private string _jcgrek;
        private int _jcadduid;
        private string _jcadduname;
        private string _jcaddtime;
        private int _jckzt;
        private int _jckadduid;
        private string _jckadduname;
        private string _jckaddtime;
        private string _jckrek;
        private string _jcby;
        private int _jcbyv;
        private int _kid;
        private string _kname;
        private string _kuser;
        private string _ktel;
        private string _kaddress;
        private string _kfax;
        private string _kemail;
        private string _kdesc;
        private string _kaddtime;
        private int _kadduid;
        private string _kadduname;
        private int _kstatus;
        private int _ktype;
        private string _krek;
        private string _kby;
        private int _kbyv;


        /// <summary>
        /// -
        /// </summary>
        public int jid
        {
            set{ _jid=value;}
            get{return _jid;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string jno
        {
            set{ _jno=value;}
            get{return _jno;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string jctime
        {
            set{ _jctime=value;}
            get{return _jctime;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string jspname
        {
            set{ _jspname=value;}
            get{return _jspname;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string jsptype
        {
            set{ _jsptype=value;}
            get{return _jsptype;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string jsptname
        {
            set{ _jsptname=value;}
            get{return _jsptname;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string jspmodel
        {
            set{ _jspmodel=value;}
            get{return _jspmodel;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string jspno
        {
            set{ _jspno=value;}
            get{return _jspno;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int jspnum
        {
            set{ _jspnum=value;}
            get{return _jspnum;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int jspprice
        {
            set{ _jspprice=value;}
            get{return _jspprice;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int jspsum
        {
            set{ _jspsum=value;}
            get{return _jspsum;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int jgykhid
        {
            set{ _jgykhid=value;}
            get{return _jgykhid;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string jcguname
        {
            set{ _jcguname=value;}
            get{return _jcguname;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string jcgrek
        {
            set{ _jcgrek=value;}
            get{return _jcgrek;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int jcadduid
        {
            set{ _jcadduid=value;}
            get{return _jcadduid;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string jcadduname
        {
            set{ _jcadduname=value;}
            get{return _jcadduname;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string jcaddtime
        {
            set{ _jcaddtime=value;}
            get{return _jcaddtime;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int jckzt
        {
            set{ _jckzt=value;}
            get{return _jckzt;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int jckadduid
        {
            set{ _jckadduid=value;}
            get{return _jckadduid;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string jckadduname
        {
            set{ _jckadduname=value;}
            get{return _jckadduname;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string jckaddtime
        {
            set{ _jckaddtime=value;}
            get{return _jckaddtime;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string jckrek
        {
            set{ _jckrek=value;}
            get{return _jckrek;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string jcby
        {
            set{ _jcby=value;}
            get{return _jcby;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int jcbyv
        {
            set{ _jcbyv=value;}
            get{return _jcbyv;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int kid
        {
            set{ _kid=value;}
            get{return _kid;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string kname
        {
            set{ _kname=value;}
            get{return _kname;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string kuser
        {
            set{ _kuser=value;}
            get{return _kuser;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string ktel
        {
            set{ _ktel=value;}
            get{return _ktel;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string kaddress
        {
            set{ _kaddress=value;}
            get{return _kaddress;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string kfax
        {
            set{ _kfax=value;}
            get{return _kfax;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string kemail
        {
            set{ _kemail=value;}
            get{return _kemail;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string kdesc
        {
            set{ _kdesc=value;}
            get{return _kdesc;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string kaddtime
        {
            set{ _kaddtime=value;}
            get{return _kaddtime;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int kadduid
        {
            set{ _kadduid=value;}
            get{return _kadduid;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string kadduname
        {
            set{ _kadduname=value;}
            get{return _kadduname;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int kstatus
        {
            set{ _kstatus=value;}
            get{return _kstatus;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int ktype
        {
            set{ _ktype=value;}
            get{return _ktype;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string krek
        {
            set{ _krek=value;}
            get{return _krek;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string kby
        {
            set{ _kby=value;}
            get{return _kby;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int kbyv
        {
            set{ _kbyv=value;}
            get{return _kbyv;}
        }
        


		#endregion Model

	}
}

