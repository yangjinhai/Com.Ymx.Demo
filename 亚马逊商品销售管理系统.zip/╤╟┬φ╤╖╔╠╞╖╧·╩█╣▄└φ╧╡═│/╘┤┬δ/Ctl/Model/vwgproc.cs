using System;

namespace Ctl.Model
{
	/// <summary>
	/// vwgproc:实体类
	/// </summary>
	[Serializable]
	public partial class vwgproc
	{
		public vwgproc()
		{}
		#region Model
        private int _pid;
        private string _pname;
        private string _ptype;
        private string _ptname;
        private string _pmodel;
        private string _pno;
        private int _pnum;
        private int _pkhid;
        private string _pdesc;
        private string _prek;
        private string _paddtime;
        private int _padduid;
        private string _padduname;
        private string _pby;
        private int _pbyv;
        private int _kid;
        private string _kname;
        private string _kuser;
        private string _ktel;
        private string _kaddress;
        private string _kfax;
        private string _kemail;
        private string _kdesc;
        private string _kaddtime;
        private int _kadduid;
        private string _kadduname;
        private int _kstatus;
        private int _ktype;
        private string _krek;
        private string _kby;
        private int _kbyv;


        /// <summary>
        /// -
        /// </summary>
        public int pid
        {
            set{ _pid=value;}
            get{return _pid;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string pname
        {
            set{ _pname=value;}
            get{return _pname;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string ptype
        {
            set{ _ptype=value;}
            get{return _ptype;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string ptname
        {
            set{ _ptname=value;}
            get{return _ptname;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string pmodel
        {
            set{ _pmodel=value;}
            get{return _pmodel;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string pno
        {
            set{ _pno=value;}
            get{return _pno;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int pnum
        {
            set{ _pnum=value;}
            get{return _pnum;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int pkhid
        {
            set{ _pkhid=value;}
            get{return _pkhid;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string pdesc
        {
            set{ _pdesc=value;}
            get{return _pdesc;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string prek
        {
            set{ _prek=value;}
            get{return _prek;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string paddtime
        {
            set{ _paddtime=value;}
            get{return _paddtime;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int padduid
        {
            set{ _padduid=value;}
            get{return _padduid;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string padduname
        {
            set{ _padduname=value;}
            get{return _padduname;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string pby
        {
            set{ _pby=value;}
            get{return _pby;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int pbyv
        {
            set{ _pbyv=value;}
            get{return _pbyv;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int kid
        {
            set{ _kid=value;}
            get{return _kid;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string kname
        {
            set{ _kname=value;}
            get{return _kname;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string kuser
        {
            set{ _kuser=value;}
            get{return _kuser;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string ktel
        {
            set{ _ktel=value;}
            get{return _ktel;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string kaddress
        {
            set{ _kaddress=value;}
            get{return _kaddress;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string kfax
        {
            set{ _kfax=value;}
            get{return _kfax;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string kemail
        {
            set{ _kemail=value;}
            get{return _kemail;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string kdesc
        {
            set{ _kdesc=value;}
            get{return _kdesc;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string kaddtime
        {
            set{ _kaddtime=value;}
            get{return _kaddtime;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int kadduid
        {
            set{ _kadduid=value;}
            get{return _kadduid;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string kadduname
        {
            set{ _kadduname=value;}
            get{return _kadduname;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int kstatus
        {
            set{ _kstatus=value;}
            get{return _kstatus;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int ktype
        {
            set{ _ktype=value;}
            get{return _ktype;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string krek
        {
            set{ _krek=value;}
            get{return _krek;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public string kby
        {
            set{ _kby=value;}
            get{return _kby;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int kbyv
        {
            set{ _kbyv=value;}
            get{return _kbyv;}
        }
        


		#endregion Model

	}
}

