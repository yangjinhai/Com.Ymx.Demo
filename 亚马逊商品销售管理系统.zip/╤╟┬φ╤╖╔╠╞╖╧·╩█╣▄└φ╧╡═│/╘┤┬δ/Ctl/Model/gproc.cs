using System;

namespace Ctl.Model
{
	/// <summary>
	/// gproc:实体类
	/// </summary>
	[Serializable]
	public partial class gproc
	{
		public gproc()
		{}
		#region Model
        private int _pid;
        private string _pname;
        private string _ptype;
        private string _ptname;
        private string _pmodel;
        private string _pno;
        private int _pnum;
        private int _pkhid;
        private string _pdesc;
        private string _prek;
        private string _paddtime;
        private int _padduid;
        private string _padduname;
        private string _pby;
        private int _pbyv;


        /// <summary>
        /// ID
        /// </summary>
        public int pid
        {
            set{ _pid=value;}
            get{return _pid;}
        }
        
        /// <summary>
        /// 商品名称
        /// </summary>
        public string pname
        {
            set{ _pname=value;}
            get{return _pname;}
        }
        
        /// <summary>
        /// 商品属性
        /// </summary>
        public string ptype
        {
            set{ _ptype=value;}
            get{return _ptype;}
        }
        
        /// <summary>
        /// 商品类型
        /// </summary>
        public string ptname
        {
            set{ _ptname=value;}
            get{return _ptname;}
        }
        
        /// <summary>
        /// 型号规格
        /// </summary>
        public string pmodel
        {
            set{ _pmodel=value;}
            get{return _pmodel;}
        }
        
        /// <summary>
        /// 商品批次号
        /// </summary>
        public string pno
        {
            set{ _pno=value;}
            get{return _pno;}
        }
        
        /// <summary>
        /// 库存量
        /// </summary>
        public int pnum
        {
            set{ _pnum=value;}
            get{return _pnum;}
        }
        
        /// <summary>
        /// 供应商
        /// </summary>
        public int pkhid
        {
            set{ _pkhid=value;}
            get{return _pkhid;}
        }
        
        /// <summary>
        /// 商品简介
        /// </summary>
        public string pdesc
        {
            set{ _pdesc=value;}
            get{return _pdesc;}
        }
        
        /// <summary>
        /// 备注说明
        /// </summary>
        public string prek
        {
            set{ _prek=value;}
            get{return _prek;}
        }
        
        /// <summary>
        /// 入库时间
        /// </summary>
        public string paddtime
        {
            set{ _paddtime=value;}
            get{return _paddtime;}
        }
        
        /// <summary>
        /// 登记人员
        /// </summary>
        public int padduid
        {
            set{ _padduid=value;}
            get{return _padduid;}
        }
        
        /// <summary>
        /// 登记人员
        /// </summary>
        public string padduname
        {
            set{ _padduname=value;}
            get{return _padduname;}
        }
        
        /// <summary>
        /// 备用
        /// </summary>
        public string pby
        {
            set{ _pby=value;}
            get{return _pby;}
        }
        
        /// <summary>
        /// 备用值
        /// </summary>
        public int pbyv
        {
            set{ _pbyv=value;}
            get{return _pbyv;}
        }
        


		#endregion Model

	}
}

