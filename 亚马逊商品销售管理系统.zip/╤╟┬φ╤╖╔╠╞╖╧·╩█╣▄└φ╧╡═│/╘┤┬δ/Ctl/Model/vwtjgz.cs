using System;

namespace Ctl.Model
{
	/// <summary>
	/// vwtjgz:实体类
	/// </summary>
	[Serializable]
	public partial class vwtjgz
	{
		public vwtjgz()
		{}
		#region Model
        private string _rq;
        private int _sl;
        private int _je;


        /// <summary>
        /// -
        /// </summary>
        public string rq
        {
            set{ _rq=value;}
            get{return _rq;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int sl
        {
            set{ _sl=value;}
            get{return _sl;}
        }
        
        /// <summary>
        /// -
        /// </summary>
        public int je
        {
            set{ _je=value;}
            get{return _je;}
        }
        


		#endregion Model

	}
}

