using System;

namespace Ctl.Model
{
	/// <summary>
	/// jhdidan:实体类
	/// </summary>
	[Serializable]
	public partial class jhdidan
	{
		public jhdidan()
		{}
		#region Model
        private int _jid;
        private string _jno;
        private string _jctime;
        private string _jspname;
        private string _jsptype;
        private string _jsptname;
        private string _jspmodel;
        private string _jspno;
        private int _jspnum;
        private int _jspprice;
        private int _jspsum;
        private int _jgykhid;
        private string _jcguname;
        private string _jcgrek;
        private int _jcadduid;
        private string _jcadduname;
        private string _jcaddtime;
        private int _jckzt;
        private int _jckadduid;
        private string _jckadduname;
        private string _jckaddtime;
        private string _jckrek;
        private string _jcby;
        private int _jcbyv;


        /// <summary>
        /// ID
        /// </summary>
        public int jid
        {
            set{ _jid=value;}
            get{return _jid;}
        }
        
        /// <summary>
        /// 采购单号
        /// </summary>
        public string jno
        {
            set{ _jno=value;}
            get{return _jno;}
        }
        
        /// <summary>
        /// 采购时间
        /// </summary>
        public string jctime
        {
            set{ _jctime=value;}
            get{return _jctime;}
        }
        
        /// <summary>
        /// 商品名称
        /// </summary>
        public string jspname
        {
            set{ _jspname=value;}
            get{return _jspname;}
        }
        
        /// <summary>
        /// 商品属性
        /// </summary>
        public string jsptype
        {
            set{ _jsptype=value;}
            get{return _jsptype;}
        }
        
        /// <summary>
        /// 商品类型
        /// </summary>
        public string jsptname
        {
            set{ _jsptname=value;}
            get{return _jsptname;}
        }
        
        /// <summary>
        /// 型号规格
        /// </summary>
        public string jspmodel
        {
            set{ _jspmodel=value;}
            get{return _jspmodel;}
        }
        
        /// <summary>
        /// 商品批次号
        /// </summary>
        public string jspno
        {
            set{ _jspno=value;}
            get{return _jspno;}
        }
        
        /// <summary>
        /// 采购数量
        /// </summary>
        public int jspnum
        {
            set{ _jspnum=value;}
            get{return _jspnum;}
        }
        
        /// <summary>
        /// 采购单价
        /// </summary>
        public int jspprice
        {
            set{ _jspprice=value;}
            get{return _jspprice;}
        }
        
        /// <summary>
        /// 采购总额
        /// </summary>
        public int jspsum
        {
            set{ _jspsum=value;}
            get{return _jspsum;}
        }
        
        /// <summary>
        /// 供应商
        /// </summary>
        public int jgykhid
        {
            set{ _jgykhid=value;}
            get{return _jgykhid;}
        }
        
        /// <summary>
        /// 采购人员
        /// </summary>
        public string jcguname
        {
            set{ _jcguname=value;}
            get{return _jcguname;}
        }
        
        /// <summary>
        /// 订单备注
        /// </summary>
        public string jcgrek
        {
            set{ _jcgrek=value;}
            get{return _jcgrek;}
        }
        
        /// <summary>
        /// 登记人员
        /// </summary>
        public int jcadduid
        {
            set{ _jcadduid=value;}
            get{return _jcadduid;}
        }
        
        /// <summary>
        /// 登记人员
        /// </summary>
        public string jcadduname
        {
            set{ _jcadduname=value;}
            get{return _jcadduname;}
        }
        
        /// <summary>
        /// 登记时间
        /// </summary>
        public string jcaddtime
        {
            set{ _jcaddtime=value;}
            get{return _jcaddtime;}
        }
        
        /// <summary>
        /// 状态(1:待审/2:不予通过/3:审核通过)
        /// </summary>
        public int jckzt
        {
            set{ _jckzt=value;}
            get{return _jckzt;}
        }
        
        /// <summary>
        /// 审核人员
        /// </summary>
        public int jckadduid
        {
            set{ _jckadduid=value;}
            get{return _jckadduid;}
        }
        
        /// <summary>
        /// 审核人员
        /// </summary>
        public string jckadduname
        {
            set{ _jckadduname=value;}
            get{return _jckadduname;}
        }
        
        /// <summary>
        /// 审核时间
        /// </summary>
        public string jckaddtime
        {
            set{ _jckaddtime=value;}
            get{return _jckaddtime;}
        }
        
        /// <summary>
        /// 备注
        /// </summary>
        public string jckrek
        {
            set{ _jckrek=value;}
            get{return _jckrek;}
        }
        
        /// <summary>
        /// 备用
        /// </summary>
        public string jcby
        {
            set{ _jcby=value;}
            get{return _jcby;}
        }
        
        /// <summary>
        /// 备用值
        /// </summary>
        public int jcbyv
        {
            set{ _jcbyv=value;}
            get{return _jcbyv;}
        }
        


		#endregion Model

	}
}

